class Line
{
    String content;
    int start,end;
    int type;
    public Line(String str,int s,int e,int t)
    {
        content = new String(str);
        start = s;
        end = e;
        type = t;
    }
    static final int LINE = 1;
    static final int CIRCLE = 2;
    static final int OVAL = 3;

}

