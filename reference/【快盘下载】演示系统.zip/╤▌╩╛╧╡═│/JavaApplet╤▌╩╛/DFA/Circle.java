class Circle
{
    String   index;
    int x,y;
    boolean end;
    public Circle(String str,int px,int py)
    {
        index = new String(str);
        x = px;
        y = py;
    }

}
