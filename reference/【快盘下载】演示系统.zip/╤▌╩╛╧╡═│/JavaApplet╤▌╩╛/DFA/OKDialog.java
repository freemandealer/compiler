import java.awt.*;

//
// OKDialog - Custom dialog that presents a message and waits for
// you to click on the OK button.
//
// Example use:
//     Dialog ok = new OKDialog(parentFrame, "Click OK to continue");
//     ok.show();     // Other input will be blocked until OK is pressed
// As a shortcut, you can use the static createOKDialog that will
// create its own frame and activate itself:
//     OKDialog.createOKDialog("Click OK to continue");
//

public class OKDialog extends Dialog
{
     protected Button okButton;
     protected static Frame createdFrame;

     public OKDialog(Frame parent, String message)
     {
          super(parent, true);     // Must call the parent's constructor

// This Dialog box uses the GridBagLayout to provide a pretty good layout.

          GridBagLayout gridbag = new GridBagLayout();
          GridBagConstraints constraints = new GridBagConstraints();

// Create the OK button and the message to display
          okButton = new Button("OK");
          Label messageLabel = new Label(message);

          setLayout(gridbag);

// The message should not fill, it should be centered within this area, with
// some extra padding.  The gridwidth of REMAINDER means this is the only
// thing on its row, and the gridheight of RELATIVE means there should only
// be one thing below it.
          constraints.fill = GridBagConstraints.NONE;
          constraints.anchor = GridBagConstraints.CENTER;
          constraints.ipadx = 20;
          constraints.ipady = 20;
          constraints.weightx = 1.0;
          constraints.weighty = 1.0;
          constraints.gridwidth = GridBagConstraints.REMAINDER;
          constraints.gridheight = GridBagConstraints.RELATIVE;

          gridbag.setConstraints(messageLabel, constraints);
          add(messageLabel);

// The button has no padding, no weight, takes up minimal width, and
// Is the last thing in its column.

          constraints.ipadx = 0;
          constraints.ipady = 0;
          constraints.weightx = 0.0;
          constraints.weighty = 0.0;
          constraints.gridwidth = 1;
          constraints.gridheight = GridBagConstraints.REMAINDER;

          gridbag.setConstraints(okButton, constraints);
          add(okButton);

// Pack is a special window method that makes the window take up the minimum
// space necessary to contain its components.

          pack();

     }

// The action method just waits for the OK button to be clicked and
// when it is it hides the dialog, causing the show() method to return
// back to whoever activated this dialog.

     public boolean action(Event evt, Object whichAction)
     {
          if (evt.target == okButton)
          {
               hide();
               if (createdFrame != null)
               {
                    createdFrame.hide();
               }
          }
          return true;
     }

// Shortcut to create a frame automatically, the frame is a static variable
// so all dialogs in an applet or application can use the same frame.

     public static void createOKDialog(String dialogString)
     {
// If the frame hasn't been created yet, create it
          if (createdFrame == null)
          {
               createdFrame = new Frame("Dialog");
          }
// Create the dialog now
          OKDialog okDialog = new OKDialog(createdFrame, dialogString);

// Shrink the frame to just fit the dialog
          createdFrame.resize(okDialog.size().width,
               okDialog.size().height);

// Show the dialog
          okDialog.show();

     }
}
