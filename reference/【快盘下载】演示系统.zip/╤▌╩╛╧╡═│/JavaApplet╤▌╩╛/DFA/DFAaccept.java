public class DFAaccept 
{
    mapExpr mp[];
	Integer [] set;
	public DFAaccept(String expr)
		throws InputException 
	{   
		MinDFA min;
		try
		{
		    min = new MinDFA (expr);
		}
		catch (InputException e)
		{
		   throw e;
		}
	    mp = min.getResult ();
		set = min.getMpEnd ();
		
	}
	
	private int moveq(int q,char ch)
	{
		for(int i=0;i<mp.length;i++)
			if(mp[i].qstart == q)
				if(mp[i].letter == ch)
				return mp[i].qend;
		return -1;
	}

    public boolean accept(String s)
	{
		int start = 0;
		for(int i = 0;i<s.length();i++)
		{
			start = moveq( start,s.charAt (i));
			
			if(start == -1)
				return false;
		}
		if(contain(set,start)) return true;
		return false;
	}
	private boolean contain(Integer[] set,int n)
    {
         for(int i =0; i<set.length;i++)
         if(set[i].intValue ()==n)return true;
		 return false;
	}

}				
	