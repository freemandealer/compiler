import java.awt.*;
//import java.applet.*;
import java.util.*;
//import Tree; 

class TreeCanvas extends Canvas
{
    boolean update = false;
    Circle []  cs;
    Line [] ls;
    public  TreeCanvas()
    {
        
    }
    public void  clear()
    {
        update = false;
        repaint();
    }
    
    public void newtree(mapExpr[] mp,Integer[] n)
    {
        Tree t ;
        t = new Tree(mp);
        cs = t.getcs();
        ls = t.getls();
        for(int i=0;i<cs.length;i++)
        {
            for(int j=0;j<n.length;j++)
            if(n[j].intValue()==Integer.parseInt(cs[i].index))
            cs[i].end = true;
        }
		setsize();
		
        update = true;
        
    }
	public void  setsize()
	{
		Rectangle r;
		int xmax,ymax;
		xmax = 0;
		ymax = 0;
		r = this.getBounds();
		for(int i =0;i<cs.length;i++)
		{
			if(xmax<cs[i].x)xmax=cs[i].x;
			if(ymax<cs[i].y)ymax=cs[i].y;
		}
		setBounds(r.x,r.y,xmax+100,ymax+100);
	}
		
    public void paint(Graphics g)
    {
        if(update)
        {
            drawline(g);
            drawcircle(g);
            drawstr(g);
			drawarrow(g);
			
        }
    }
	public void drawarrow(Graphics g)
	{   
		int r =26;
        int x,y,x1,y1;
        for(int i = 0;i<ls.length;i++)
        {
            x = cs[ls[i].start].x;
            y = cs[ls[i].start].y;
            x1 = cs[ls[i].end].x;
            y1 = cs[ls[i].end].y;
            if(ls[i].type == Line.LINE)
            {
				Point p1 = new Point(x,y);
				Point  p2 = new Point(x1,y1);
				
			    Point[] p =	getLineArrow(p1,p2,r/2);
				Polygon arrow = new Polygon ();
				arrow.addPoint(p[0].x,p[0].y);
				arrow.addPoint(p[1].x,p[1].y);
				arrow.addPoint(p[2].x,p[2].y);
			    g.fillPolygon (arrow);
			
            }
            if(ls[i].type == Line.CIRCLE)
            {
                Point p3;
                p3 = getp3(x,y,x1,y1);
                Point p1 = new Point(x,y);
				Point  p2 = new Point(x1,y1);
				Point[] p = getArrow(p1,p2,p3,r/2);
				Polygon arrow = new Polygon ();
				arrow.addPoint(p[0].x,p[0].y);
				arrow.addPoint(p[1].x,p[1].y);
				arrow.addPoint(p[2].x,p[2].y);
				g.fillPolygon (arrow);
					
            }
            if(ls[i].type == Line.OVAL)
            {
                //sx = x;
                //sy = y-r/2-2;
                //g.drawString(ls[i].content,sx,sy-1);
            }

        }
	
	}
    public void drawstr(Graphics g)
    {
        int r =26;
        int x,y,x1,y1,sx,sy;
        for(int i = 0;i<ls.length;i++)
        {
            x = cs[ls[i].start].x;
            y = cs[ls[i].start].y;
            x1 = cs[ls[i].end].x;
            y1 = cs[ls[i].end].y;
            if(ls[i].type == Line.LINE)
            {
                sx = (x+x1)/2;
                sy = (y+y1)/2;
				
				int l = ls[i].content.length();
                StringBuffer str = new StringBuffer() ;
				
				for(int j =0;j<l;j++)
				{
					str.append (ls[i].content.charAt (j));
					if( j<l-1)str.append('|');
					
				}	
				l = str.length ();
				String s = new String(str);
				g.drawString(s,sx-l*3,sy-2);
            }
            if(ls[i].type == Line.CIRCLE)
            {
                Point p;
                p = getp3(x,y,x1,y1);
                sx = p.x;
                sy = p.y;
                g.drawString(ls[i].content,sx+2,sy);
            }
            if(ls[i].type == Line.OVAL)
            {
                sx = x;
                sy = y-r/2-2;
                g.drawString(ls[i].content,sx,sy-1);
            }

        }
    }
    public void drawline(Graphics g)
    {
        int r = 26;
        int x,y,x1,y1,sx,sy;
        
        for(int i = 0;i<ls.length;i++)
        {
            
            x = cs[ls[i].start].x;
            y = cs[ls[i].start].y;
            x1 = cs[ls[i].end].x;
            y1 = cs[ls[i].end].y;
            if(ls[i].type == Line.LINE)
            {
                g.drawLine(x,y,x1,y1);
            }
            if(ls[i].type == Line.CIRCLE)
            {
                drawarc(g, x,y,x1,y1);
             }
            if(ls[i].type == Line.OVAL)
            {
            }

        }
    }
    public void drawcircle(Graphics g)
    {  
        int r = 26;
        
        for(int i= 0; i<cs.length;i++)
        {
            int x = cs[i].x - r/2;
            int y = cs[i].y - r/2;
            g.setColor(Color.white);
            g.fillOval(x,y,r,r);
            g.setColor(Color.black);
            g.drawOval(x,y,r,r);
            if(cs[i].end) g.drawOval(x+2,y+2,r-4,r-4);
            if(cs[i].index.length()==1)
              g.drawString(cs[i].index,x+10,y+15);
            if(cs[i].index.length()==2)
              g.drawString(cs[i].index,x+8,y+15);
              
        }
    }
    public Point getp3(int x1,int y1,int x2,int y2)
    {
        Point p3;
        int  a = 5 ;
        int k,x0,y0,d;
        int x,y;

        x0 = (x1+x2)/2;
        y0 = (y1+y2)/2;
        d = ((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2))/a/a;
        if(y1==y2)
           p3 = new Point(x0,y1+(x2-x1)/a);
        else
        if(x1==x2)
           p3 = new Point(x1+(y2-y1)/a,y0);
        else
        {
            k = (x1-x2)/(y2-y1);
            int da =(int) Math.sqrt(d/(1+k*k));
            if(y1<y2)
               x = x0 - da;
            else x = x0 + da;
            y = y0 + k*(x - x0);
            p3 = new Point(x,y);
        }
        return p3;
    }
    public void drawarc(Graphics g,int x1,int y1,int x2,int y2)
    {
        Point p1,p2,p3;
        p1 = new Point(x1,y1);
        p2 = new Point(x2,y2);
        p3 = getp3(x1,y1,x2,y2);
        arc(g,p1,p2,p3);
    }
    public void arc(Graphics g,Point p1,Point p2,Point p3)
    {
      int x0,y0;
      int angle1,angle2;
      int arcAngle,startAngle;
      int r;
      int x,y;
      float t1;
  	  Point p = clinePoint(p1,p2,p3);
	  x0 = p.x;
	  y0 = p.y;
	  r = clineR(p1,p2,p3);
      x = x0 - r;
      y = y0 - r;
      angle1 = getAngle(x0,y0,p1);
      angle2 = getAngle(x0,y0,p2);
      arcAngle = Math.abs(angle1-angle2);
      startAngle = Math.min(angle1,angle2);
      if(arcAngle>180)
      {
        arcAngle = 360 - arcAngle;
        startAngle =Math.max(angle1,angle2);
      }

      g.drawArc(x,y,2*r,2*r,startAngle,arcAngle);

    }
    public int  getAngle(int x,int y,Point p)
    {
        int dx,dy;
        double a1;
        int a;
        dx = Math.abs(p.x - x);
        dy = Math.abs(p.y -y );
        if (dx == 0)
          if(y - p.y >= 0)return  90;
          else return 270;

        a1 = Math.atan((double)dy/dx);
        a = (int)(a1*180/Math.PI);
        if(p.x - x>0)
           if(y - p.y>=0) return a;
           else return 360 - a;
        else if(y - p.y>= 0) return 180 - a;
             else return 180 + a;
    }
	public Point[] circlesPoints(Point p1,int r1,Point p2,int r2)
	{ 
		float A = r2*r2 - r1*r1 + p1.x*p1.x - p2.x*p2.x 
				 + p1.y*p1.y - p2.y*p2.y ;
		float B = A/( 2*(p1.x - p2.x) );//if p1.x == p2.x ERROR
		float C = (float)(p1.y - p2.y)/(float)(p1.x - p2.x);
		float a = C*C +1;
		float b = 2*p1.x*C - 2*B*C - 2*p1.y;
		float c = B*B - 2*p1.x*B + p1.x*p1.x + p1.y*p1.y - r1*r1;
		float d = (float) Math.sqrt(b*b - 4*a*c);
		int  y1 =(int)( (-b+d)/(2*a) );
		int  y2 = (int)( (-b-d)/(2*a) );
		int  x1 = (int)(B - C*y1);
		int  x2 = (int)( B - C*y2);
		Point [] p = new Point [2];
		p[0] = new Point(x1,y1);
		p[1] = new Point(x2,y2);
		return p;
	}
	public Point clinePoint(Point p1,Point p2,Point p3)
	{
	  int x0,y0;
      float t1;
      t1 =(float)((float) (p3.y-p2.y)/(float)(p2.x-p3.x)
                  -(float)(p1.y-p3.y)/(float)(p3.x-p1.x) );
      y0 =(int)(( (float)(p3.y*p3.y-p1.y*p1.y)/(float)(2*p3.x-2*p1.x)
          - (float)(p2.y*p2.y-p3.y*p3.y)/(float)(2*p2.x-2*p3.x)
          + (float)(p1.x-p2.x)/2 ) /t1);

      x0 = (int)( (float)(p1.x+p3.x)/2+(float)(p1.y-p3.y)*y0/(float)(p3.x-p1.x)
           +(float)(p3.y*p3.y-p1.y*p1.y)/(float)(2*p3.x-2*p1.x) );
      return new Point (x0,y0);
		
	}
	public int clineR(Point p1,Point p2,Point p3)
	{
	  int x0,y0;
      int r;
      Point p = clinePoint(p1,p2,p3);
	  x0 = p.x;
	  y0 = p.y;
	  r =(int) Math.sqrt((p1.x - x0)*(p1.x-x0)
                         +(p1.y - y0)*(p1.y-y0));
     
	  return r;
		
	}
	public Point circlesPoint(Point p1,Point p2,Point p3,Point p4,int r)
	{
		Point p0 = clinePoint(p1,p2,p3);
		int angle1 = getAngle(p0.x,p0.y,p1);
		int angle2 = getAngle(p0.x,p0.y,p2);
		int r0 = clineR(p1,p2,p3); 
	    Point [] p = circlesPoints(p0,r0,p4,r);
		int angle3 = getAngle(p0.x,p0.y,p[0]);
	    int angle4 = getAngle(p0.x,p0.y,p[1]);
	
		int arcAngle = Math.abs(angle1-angle2);
        int startAngle = Math.min(angle1,angle2);
        
		if(arcAngle>180)
        {
          arcAngle = 360 - arcAngle;
          startAngle =Math.max(angle1,angle2);
        }
		if(startAngle+arcAngle <= 360)
			if(startAngle<angle3 && angle3<startAngle + arcAngle)
				return p[0];
		    else return p[1];
		else 
		{
			if(startAngle < angle3 || angle3 < startAngle+arcAngle-360)
			   return p[0];
			else return p[1];
		}

		
	}
	//ֱ�� l : y = a +k(x - b)�Ͼ���p0��Ϊd������
	public Point [] getPoints(int a ,int b,float k,Point p0,int d)
	{
		float A = 1 + k*k;
		float B = 2*(k*(a - k*b - p0.y) - p0.x );
		float C = p0.x*p0.x +(a - k*b-p0.y)*(a - k*b-p0.y) - d*d;
		float T = (float)Math.sqrt (B*B - 4*A*C);
		float x1 = ((-B + T)/(2*A));
		float x2 = ((-B - T)/(2*A));
		int y1 = (int)(a + k*(x1 - b));
		int y2 = (int)(a + k*(x2 - b));
		Point [] p = new Point[2];
		p[0] = new Point((int)x1,y1);
		p[1] = new Point((int)x2,y2);
		return p;
		
	}
	public Point [] getArrow(Point p1,Point p2,Point p3,int r)
	{
	//	r = r+2;
		Point p0 = clinePoint(p1,p2,p3);
		int   r0 = clineR(p1,p2,p3); 
	    
		Point pt1 = circlesPoint(p1,p2,p3,p2,r);
		float k1,k2;
		int d = 10;
		Point[]  ps1 = circlesPoints(p0,r0,pt1,d);
		Point pt2;
		if( contain(p2,r,ps1[0]) ) pt2 = ps1[1];
		else pt2 = ps1[0];
		
		k1 = (float)(pt1.y - pt2.y)/(float)(pt1.x - pt2.x);
		k2 = -1/k1;
		int d1 =4;
		Point [] ps = getPoints(pt2.y,pt2.x,k2,pt2,d1);
        
		Point[] p = new Point[3];
		p[0] = pt1;
		p[1] = ps[0];
		p[2] = ps[1];
		
		
		return p;
		
		
	}
	Point [] getLineArrow(Point p1,Point p2,int r)
	{
		int d = 10;
		int d1 = 4;
		Point p[] = new Point[3];
		if( p1.y == p2.y)
		{
			if(p1.x<p2.x)
			{
			   p[0] =  new Point(p2.x - r,p2.y);
			   p[1] = new Point(p[0].x - d,p[0].y+d1);
			   p[2] = new Point(p[0].x - d,p[0].y-d1);
			   
			}
			else
			{
				p[0] =  new Point(p2.x+r,p2.y);
				p[1] = new Point(p[0].x+d,p[0].y+d1);
				p[2] = new Point(p[0].x+d,p[0].y-d1);
			}
		
		}
		else
		{
			float k = (float)(p2.y-p1.y)/(float)(p2.x-p1.x);
			Point [] ps = getPoints(p2.y,p2.x,k,p2,r);
			int x1 = Math.min(p1.x,p2.x);
			int x2 = Math.max(p1.x,p2.x);
			if(x1<ps[0].x && ps[0].x<x2) p[0] = ps[0];
			else p[0] = ps[1];
			Point [] ps1 = getPoints(p2.y,p2.x,k,p2,r+d);
			Point pt;
			if(x1<ps1[0].x && ps1[0].x<x2) pt = ps1[0];
			else pt = ps1[1];
			Point [] ps2 = getPoints(pt.y,pt.x,-1/k,pt,d1);
			p[1] = ps2[0];
			p[2] = ps2[1];
			
		}
			
	    return p;
	}
	public boolean contain(Point p0,int r,Point p)
	{
		int d = (p.x-p0.x)*(p.x-p0.x) + (p.y - p0.y)*(p.y - p0.y);
		if(r*r >= d) return true;
		else return false;
	}
	

}


