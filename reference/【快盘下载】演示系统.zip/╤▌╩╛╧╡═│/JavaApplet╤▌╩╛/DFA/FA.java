//import mapExpr;

interface FA
{
    public mapExpr[] getResult();
	public int getMpStart();
	public Integer[] getMpEnd();
	static final char [] charmenu =
	{
	 'a','b','c','d','e','f','g','h','i','j','k','l','m','n',
	 'o','p','q','r','s','t','u','v','w','x','y','z'
	};
	static final char [] controlmenu =
	{
	    '$','|','(',')','*'
	};
	
}
