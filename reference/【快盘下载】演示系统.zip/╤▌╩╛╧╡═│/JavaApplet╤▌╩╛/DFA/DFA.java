import java.util.*;
//import NFA;
class DFA extends NFA implements FA
{
	private mapExpr[] NFAmp;
	private mapExpr[] DFAmp;
    private Vector v;
	private int end;
	public int stateNum()
	{
		return v.size();
	}
	private Vector nextState(int start,char ch)
	{
		Vector v = new Vector(20,20);
		for(int i=0;i<NFAmp.length; i++)
		    if(NFAmp[i].qstart == start)
				if(NFAmp[i].letter == ch)
				v.addElement(new Integer(NFAmp[i].qend));
		return v;
	}
	private Vector closure(Vector v)
	{
		Vector set = new Vector(20,20);
		Stack s = new Stack();
		Enumeration vectEnum = v.elements();

		while(vectEnum.hasMoreElements())
		{
			Integer qnum =(Integer) vectEnum.nextElement();
			set.addElement(qnum);
			s.push(qnum);
		}

		while(!s.empty())
		{
			int q = ((Integer)s.pop()).intValue();
			Vector vNext = nextState(q,'^');
			for(int i=0; i<vNext.size();i++)
				if( !set.contains(vNext.elementAt(i)) )
			{
				set.addElement(vNext.elementAt(i));
				s.push(vNext.elementAt(i));
			}
		}

		return set;
	}

	private Vector move(Vector vStart,char ch)
	{
		Vector vEnd = new Vector(20,20);
		for (int i = 0;i < vStart.size();i++)
		{
			Integer qnum = (Integer)vStart.elementAt(i);
			Vector v = nextState(qnum.intValue(),ch);
			for(int j = 0;j < v.size();j++)
				if( !vEnd.contains(v.elementAt(j)) )
				vEnd.addElement(v.elementAt(j));
		}
		return vEnd;
	}
	private boolean contain(Vector v1,Vector v2)
	{
		for (int i=0;i<v1.size();i++)
		if(equal((Vector)v1.elementAt(i),v2))
		   return true;
		return false;
	}


    private Vector create(Vector v)
	{
		Vector set = new Vector(20,20);
		Stack s = new Stack();
		s.push(v);
		set.addElement(v);
		while(!s.empty())
		{
			Vector vs =(Vector) s.pop();

		    //for(int i = 'a';i<='z';i++)
			for(int i = 0;i<FA.charmenu.length;i++)
			{
			   Vector ve = closure(move(vs,FA.charmenu[i]));
			   if(!ve.isEmpty())
				   if(!contain(set,ve))
			   {
				   set.addElement(ve);
				   if(!equal(ve,vs)&&s.search(ve)==-1)
					   s.push(ve);

			   }
			}
		}
		return set;
	}
	public int getMpStart()
	{
		return 0;
	}
    public Integer[] getMpEnd()
	{
        Vector result = new Vector(20,20);
		Integer [] r;
	    Integer e = new Integer(end);
		for(int i=0;i<v.size();i++)
		{
			Vector v1 = (Vector)v.elementAt(i);
			if(v1.contains(e))
				result.addElement(new Integer(i));
		}
		r = new Integer[result.size()];
		result.copyInto(r);
		return r;
	}

    public mapExpr[] getResult()
	{
		Vector v =getmp();
		mapExpr [] result = new mapExpr[v.size()];
 		v.copyInto(result);
		return result;
	}


	private Vector getmp()
	{
		mapExpr mp;
		Vector result = new Vector(20,20);
		for(int i=0;i<v.size();i++)
		{
			Vector vs = (Vector)v.elementAt(i);
			//for(int j='a';j<='z';j++)
			for(int j = 0;j<FA.charmenu.length;j++)
			{
			   Vector ve = closure(move(vs,FA.charmenu[j]));
			   if(!ve.isEmpty())
			   {
				    int e = getIndex(v,ve);//v.indexOf(ve);
			        mp = new mapExpr();
			        mp.qstart = i;
			        mp.qend = e;
			        mp.letter = FA.charmenu[j];
			        result.addElement(mp);
			   }
			}
		}
		return result;
	}
	private boolean equal(Vector v1,Vector v2)
	{
	   if(v1.size()!=v2.size())return false;
		for(int i= 0;i<v1.size();i++)
		{
			Integer n1=(Integer) v1.elementAt(i);
            Integer n2= (Integer)v2.elementAt(i);
			int q1 = n1.intValue();
            int q2 = n2.intValue();
			if(q1!=q2) return false;
		}
		return true;
	}


    private int getIndex(Vector v,Vector v2)
	{
		for(int i= 0;i<v.size();i++)
		{
			Vector t =(Vector) v.elementAt(i);
			if( equal(t,v2))return i;
		}
		return -1;
	}

	public DFA(String input)
	throws InputException
	
	{
		//NFA nfa = new super.NFA(input);
		super(input);
		NFAmp = super.getResult();
		Integer[]  n;
		n = super.getMpEnd();
		end = n[0].intValue();
		Vector v0 = new Vector(20,20);
		v0.addElement(new Integer(0));
		v = closure(v0);
		v = create(v);
		

	}
}


