/*		
		setLayout(null);
		setSize(632,274);
		scrollPane1 = new java.awt.ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
		scrollPane1.setBounds(0,12,384,252);
		add(scrollPane1);
		canvas1 = new TreeCanvas();
		scrollPane1.add(canvas1);
		
		button1 = new java.awt.Button();
		button1.setActionCommand("button");
		button1.setLabel("����ַ���");
		button1.setBounds(516,240,108,24);
		button1.setBackground(new Color(12632256));
		add(button1);
		textField1 = new java.awt.TextField();
		textField1.setBounds(516,216,108,24);
		add(textField1);
		button2 = new java.awt.Button();
		button2.setActionCommand("button");
		button2.setLabel("�����Զ���");
		button2.setBounds(516,156,108,24);
		button2.setBackground(new Color(12632256));
		add(button2);
		textField2 = new java.awt.TextField();
		textField2.setBounds(516,132,108,24);
		add(textField2);
		panel1 = new java.awt.Panel();
		panel1.setLayout(null);
		panel1.setBounds(516,12,108,84);
		add(panel1);
		Group1 = new CheckboxGroup();
		radioButton1 = new java.awt.Checkbox("NFA", Group1,true);
		radioButton1.setBounds(24,24,60,12);
		panel1.add(radioButton1);
		radioButton2 = new java.awt.Checkbox("DFA", Group1, false);
		radioButton2.setBounds(24,48,60,12);
		panel1.add(radioButton2);
		radioButton3 = new java.awt.Checkbox("MINDFA", Group1, false);
		radioButton3.setBounds(24,72,72,12);
		panel1.add(radioButton3);
		label1 = new java.awt.Label("�Զ�������");
		label1.setBounds(24,0,60,24);
		panel1.add(label1);
		list1 = new java.awt.List(0,false);
		add(list1);
		list1.setBounds(396,12,108,252);
		label2 = new java.awt.Label("�������������ʽ");
		label2.setBounds(516,108,108,24);
		add(label2);
		label3 = new java.awt.Label("����������ַ���");
		label3.setBounds(516,192,108,24);
		add(label3);
		//}}
	
		//{{REGISTER_LISTENERS
		SymAction lSymAction = new SymAction();
		button1.addActionListener(lSymAction);
		button2.addActionListener(lSymAction);
		SymItem lSymItem = new SymItem();
		radioButton1.addItemListener(lSymItem);
		radioButton2.addItemListener(lSymItem);
		radioButton3.addItemListener(lSymItem);
	
	
		//}}
*/