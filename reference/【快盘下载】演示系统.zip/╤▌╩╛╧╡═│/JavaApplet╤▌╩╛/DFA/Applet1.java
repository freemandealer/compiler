/*
	A basic extension of the java.applet.Applet class
 */

import java.awt.*;
import java.applet.*;

public class Applet1 extends Applet
{
	public void init()
	{
		GridBagLayout layout=new GridBagLayout();
		GridBagConstraints c=new GridBagConstraints();
		setLayout(layout);
		
		
		
        Group1 = new CheckboxGroup();
		c.fill = GridBagConstraints.BOTH;
		c.weightx=1.0;
		c.weighty=0.0;
		c.insets=new Insets(2,2,2,2);
		
		label1 = new java.awt.Label("�Զ�������");
		//label1.setBounds(24,0,60,24);
		layout.setConstraints(label1,c);
		add(label1);
				
		radioButton1 = new java.awt.Checkbox("NFA", Group1,true);
		//radioButton1.setBounds(24,24,60,12);
		layout.setConstraints(radioButton1,c);
		add(radioButton1);
		
		radioButton2 = new java.awt.Checkbox("DFA", Group1, false);
		//radioButton2.setBounds(24,48,60,12);
		layout.setConstraints(radioButton2,c);
		add(radioButton2);
		
		c.gridwidth = GridBagConstraints.REMAINDER; //end row
		radioButton3 = new java.awt.Checkbox("MINDFA", Group1, false);
		//radioButton3.setBounds(24,72,72,12);
		layout.setConstraints(radioButton3,c);
		add(radioButton3);
		
		
		c.weightx=0.0;
		c.gridwidth=1;
		c.weighty=0.0;
		c.insets=new Insets(2,2,2,2);
		
		label2 = new java.awt.Label("�������������ʽ");
		//label2.setBounds(516,108,108,24);
		layout.setConstraints(label2,c);
		add(label2);
		
		c.weightx=1.0;
		c.gridwidth = GridBagConstraints.RELATIVE; //next-to-last in row
		textField2 = new java.awt.TextField();
		//textField2.setBounds(516,132,108,24);
		layout.setConstraints(textField2,c);
		add(textField2);
		
		c.weightx=0.0			;
		c.gridwidth = GridBagConstraints.REMAINDER; //end row
		c.insets=new Insets(2,8,2,8);
		button2 = new java.awt.Button();
		button2.setActionCommand("button");
		button2.setLabel("�����Զ���");
		//button2.setBounds(516,156,108,24);
		button2.setBackground(new Color(12632256));
		layout.setConstraints(button2,c);
		add(button2);
		
		//panel1 = new java.awt.Panel();
		//panel1.setLayout(null);
		//panel1.setBounds(516,12,108,84);
		//add(panel1);		
		
		c.weightx=0.0;
		c.gridwidth=1;
		c.weighty=0.0;
		c.insets=new Insets(2,2,2,2);
		label3 = new java.awt.Label("����������ַ���");
		//label3.setBounds(516,192,108,24);
		layout.setConstraints(label3,c);
		add(label3);
		
		c.weightx=1.0;
		c.gridwidth = GridBagConstraints.RELATIVE; //next-to-last in row
		textField1 = new java.awt.TextField();
		layout.setConstraints(textField1,c);
		add(textField1);
		
		c.weightx=0.0;
		c.gridwidth = GridBagConstraints.REMAINDER; //end row
		c.insets=new Insets(2,8,2,8);
		button1 = new java.awt.Button();
		button1.setActionCommand("button");
		button1.setLabel("����ַ���");
		//button1.setBounds(516,240,108,24);
		button1.setBackground(new Color(12632256));
		layout.setConstraints(button1,c);
		add(button1);
		
		c.weighty=1.0;
		c.weightx=0.0;
		c.insets=new Insets(2,2,2,2);
		//c.gridheight = GridBagConstraints.REMAINDER;
		c.gridwidth = GridBagConstraints.RELATIVE; //next-to-last in row
		scrollPane1 = new java.awt.ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
		//scrollPane1.setBounds(0,12,384,252);
		layout.setConstraints(scrollPane1,c);
		add(scrollPane1);
		
		canvas1 = new TreeCanvas();
		scrollPane1.add(canvas1);
		
		//c.gridheight = GridBagConstraints.REMAINDER;
		c.weightx=0.0;
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.insets=new Insets(2,8,2,8);
		list1 = new java.awt.List(0,false);
		layout.setConstraints(list1,c);
		add(list1);
		//list1.setBounds(396,12,108,252);
		
		//}}
	
		//{{REGISTER_LISTENERS
		SymAction lSymAction = new SymAction();
		button1.addActionListener(lSymAction);
		button2.addActionListener(lSymAction);
		SymItem lSymItem = new SymItem();
		radioButton1.addItemListener(lSymItem);
		radioButton2.addItemListener(lSymItem);
		radioButton3.addItemListener(lSymItem);
	
	
		//}}
	}
	
	//{{DECLARE_CONTROLS
	java.awt.ScrollPane scrollPane1;
	java.awt.Button button1;
	java.awt.TextField textField1;
	java.awt.Button button2;
	java.awt.TextField textField2;
	java.awt.Panel panel1;
	java.awt.Checkbox radioButton1;
	CheckboxGroup Group1;
	java.awt.Checkbox radioButton2;
	java.awt.Checkbox radioButton3;
	java.awt.Label label1;
	java.awt.List list1;
	java.awt.Label label2;
	java.awt.Label label3;
	//}}
	int FAtype ;
	final int TNFA = 0;
	final int TDFA = 1;
	final int TMINDFA = 2;
	TreeCanvas canvas1;


	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == button2)
				button2_Action(event);
			if (object == button1)
				button1_Action(event);
			
		}
	}
	void button1_Action(java.awt.event.ActionEvent event)
	{
		String input = textField2.getText ();
		String s = textField1.getText ();
		
		DFAaccept da ;
		try
		{
			da = new DFAaccept (input);
			if(da.accept(s))OKDialog.createOKDialog("ACCEPT");
		    else OKDialog.createOKDialog("NOT ACCEPT");

		}
		catch(InputException e)
		{
			OKDialog.createOKDialog("NOT Build FA");
		}
		

	}

	void button2_Action(java.awt.event.ActionEvent event)
	{
		mapExpr[] mp;
		Integer end[];
	    String input = textField2.getText();
		///////////////////////////////////////////////////
		if( FAtype == TNFA)
		{
			try
		    {
		        NFA nfa = new NFA(input);
		        mp = nfa.getResult();
				end = nfa.getMpEnd ();
				printmp(mp,end);
		        canvas1.newtree(mp,end);	
			    canvas1.repaint();
		   	}
			catch(InputException e)
		    {    
				canvas1.clear();
		  
		        OKDialog.createOKDialog(e.getMessage());
		
		    }
		}
	    if( FAtype == TDFA)
		{
			try
		    {
		        DFA dfa = new DFA(input);
		        mp = dfa.getResult();
				end = dfa.getMpEnd ();
				printmp(mp,end);
				canvas1.newtree(mp,end);	
			    canvas1.repaint();
		     	}
			catch(InputException e)
		    {   
				canvas1.clear();
		  
		        OKDialog.createOKDialog(e.getMessage());
		
		    }
		}
		if( FAtype == TMINDFA)
		{
			try
		    {
		        MinDFA min = new MinDFA(input);
		        mp = min.getResult();
				end = min.getMpEnd ();
				printmp(mp,end);
	            canvas1.newtree(mp,end);	
			    canvas1.repaint();
		   	}
			catch(InputException e)
		    {     
				canvas1.clear();
		  
		        OKDialog.createOKDialog(e.getMessage());
		
		    }	
		}

	}
	public void printmp(mapExpr[] mp,Integer[] end)
	{
		list1.clear();
		for(int i = 0;i < mp.length;i++)
			list1.addItem("("+mp[i].qstart
			+" , "+ mp[i].letter+ ")"+
			"-->"+mp[i].qend);
		
		list1.addItem("Start q:"+0);
		
		for(int i=0;i<end.length;i++)
		list1.addItem("End q:"+end[i]);
		
	}

	class SymItem implements java.awt.event.ItemListener
	{
		public void itemStateChanged(java.awt.event.ItemEvent event)
		{
			Object object = event.getSource();
			if (object == radioButton1)
				radioButton1_ItemStateChanged(event);
			if (object == radioButton2)
				radioButton2_ItemStateChanged(event);
			if (object == radioButton3)
				radioButton3_ItemStateChanged(event);
		}
	}

	void radioButton1_ItemStateChanged(java.awt.event.ItemEvent event)
	{
		FAtype = TNFA;
	}
    void radioButton2_ItemStateChanged(java.awt.event.ItemEvent event)
	{
		FAtype = TDFA;

	}
    void radioButton3_ItemStateChanged(java.awt.event.ItemEvent event)
	{
		FAtype = TMINDFA;

	}

}
