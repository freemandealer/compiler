import java.util.*;
//import DFA;
class MinDFA extends DFA implements FA
{
	int equ[][];
	mapExpr [] DFAmp;
	mapExpr[] m ;
	boolean end[];
	Vector ve;
	int size;
	public MinDFA(String input)
	throws InputException
	
	{
	    super(input);
		DFAmp = super.getResult();
		size = super.stateNum();
		equ = new int[size][size];
		end = new boolean[size];
		Integer[] e = super.getMpEnd();
		for(int i=0;i<size;i++)
		    end[i] = false;
		for(int i=0;i<e.length;i++)
			end[e[i].intValue()]= true;
		InitEqu();
	}
	int move(int q,char ch)
	{
		for(int i=0;i<DFAmp.length;i++)
			if(DFAmp[i].qstart == q)
				if(DFAmp[i].letter == ch)
				return DFAmp[i].qend;
		return -1;
	}

	int equal(int q1,int q2)
	{
		if(equ[q1][q2]!=0) return equ[q1][q2];
		boolean f=true;
		//for(int i='a';i<='z';i++)
		for(int i = 0;i<FA.charmenu.length;i++)
		{
			int b1=move(q1,FA.charmenu[i]);
			int b2=move(q2,FA.charmenu[i]);
			if(!(b1 == b2&&b1==-1)) f= false;
		}
		if(f) return 1;

		//for(int i='a';i<='z';i++)
		for(int i = 0;i<FA.charmenu.length;i++)
			{
			int e1=move(q1,FA.charmenu[i]);
			int e2=move(q2,FA.charmenu[i]);
			if(e1!=-1&&e2!=-1)
			{
			   if( equ[e1][e2] == -1 ) return -1;
			   //if( equ[e1][e2] == 0) return
			}
			else if(e1 != e2) return -1;


		}

		f = true;
		//for(int i='a';i<='z';i++)
		for(int i = 0;i<FA.charmenu.length;i++)
		{
			int a1=move(q1,FA.charmenu[i]);
			int a2=move(q2,FA.charmenu[i]);
			if(a1!=-1&&a2!=-1)
			if(!(equ[a1][a2] == 1)) f= false;
		}
		if(f) return 1;

		return 0;
	}
	void InitEqu()
	{
		boolean change;

		for(int i=0;i<size;i++)
		    for(int j=0;j<size;j++)
		{
		    if(i==j) equ[i][j] = 1;
			else if(end[i] != end[j])
				  equ[i][j] = -1;
			     else  equ[i][j]= 0;
		}


		do
		{
			change = false;

		    for(int i=0;i<size;i++)
			   for(int j=0;j<size;j++)
			{
			    if(equal(i,j)!=equ[i][j])
				{
				   change = true ;
				   equ[i][j] = equal(i,j);
				}
			}
		}while(change);
	}
	boolean contain(Vector v,mapExpr m)
	{   mapExpr t ;
		for(int i=0;i<v.size();i++)
		{
			t = (mapExpr)v.elementAt(i);
			if(t.qstart == m.qstart)
				if(t.letter ==  m.letter)
				if(t.qend == m.qend) return true;
		}
		return false;
	}
	public mapExpr [] getResult()
	{
		Vector v = new Vector(20,20);
        for(int i=0;i<size;i++)
		   for(int j=0;j<size;j++)
		if(equ[i][j] != -1) modify(i,j);
       // return DFAmp;


		for(int i=0;i<DFAmp.length;i++)
			if(!contain(v,DFAmp[i]) )
				v.addElement(DFAmp[i]);
		m = new mapExpr[v.size()];
		v.copyInto(m);
		Vector vs = getState();
		ve = new Vector(20,20);
		for(int i= 0;i<m.length;i++)
		{
			Integer qs = new Integer(m[i].qstart);
			Integer qe = new Integer(m[i].qend);
			int s = vs.indexOf(qs);
			int e = vs.indexOf(qe);
			m[i].qstart = s;
			m[i].qend = e;
		    if( end[qe.intValue()]==true )
			   if(!ve.contains(new Integer(e )))
				  ve.addElement(new Integer(e ) );
			if(end[qs.intValue()]==true)
			   if(!ve.contains(new Integer(s)) )
				   ve.addElement(new Integer(s) );
		}

		return m;
	}
	public Integer [] getMpEnd()
	{
		int size = ve.size();
		Integer[] end= new Integer[size];
		ve.copyInto(end);
		return end;
	}
	public int getMpStart()
	{
		return 0;
	}

	private Vector getState()
	{
		Vector vs= new Vector(20,20);
		for(int i = 0;i<m.length;i++)
		{
			Integer s = new Integer(m[i].qstart);
            Integer e = new Integer(m[i].qend);
			if(!vs.contains(s))vs.addElement(s);
            if(!vs.contains(e))vs.addElement(e);
		}
		return  vs;
	}

	private void modify(int a,int b)
	{
		int m;
		if(a>b) m= b;
		else m = a;
		for(int i=0;i<DFAmp.length;i++)
		{
			if(DFAmp[i].qstart==a)
				DFAmp[i].qstart=m;
			if(DFAmp[i].qend==b)
				DFAmp[i].qend = m;
		}

	}

}


