import java.applet.*;
import java.awt.*;

class fagraph
{
	int kind;
	String text;
	int first,second;
	int width,height;
	int up,down;
	public fagraph()
	{
		kind=0;
		text="";
		first=0;
		second=0;
		width=3;
		height=1;
		up=0;
		down=0;
	}
	public void fainit(int kind1,String text1,int first1,int second1,
		int width1,int height1,int up1,int down1)
	{
		kind=kind1;
		text=text1;
		first=first1;
		second=second1;
		width=width1;
		height=height1;
		up=up1;
		down=down1;
	}
}

public class rtofa extends java.applet.Applet
{
	TextField tr=new TextField("",30);
	Button butspacenfa=new Button("include space nfa");
	Font f1=new Font("TimesRoman",Font.PLAIN,16);
	Font f2=new Font("TimesRoman",Font.PLAIN,14);
	Font f3=new Font("TimesRoman",Font.PLAIN,36);
	int maxlength=30;
	int ox,oy;
	int singlewidth,singleheight,singleround;
	int digitstack[]=new int[maxlength+2];
	int dtop=0;
	int optionstack[]=new int[maxlength+2];
	int otop=0;
	fagraph fa[]=new fagraph[maxlength*2];
	int totalfa=0;
	String s="";
	int slength;
	int sp=0;
	String sfronthalf,sbehindhalf,sbak;
	int errorkind;
	int i,j,k;
	char ch;
	public void init()
	{
		resize(1280,1024);
		setLayout(new FlowLayout(FlowLayout.LEFT));
		add(tr);
		add(butspacenfa);
		singlewidth=50;
		singleheight=30;
		singleround=30;
		ox=100;
		oy=100;
		otop=0;
		optionstack[otop]=0;
		errorkind=0;
		i=0;
		while (i<maxlength*2) 
		{
			fa[i]=new fagraph();
			i++;
		}
	}
	public void createfa()
	{
		slength=s.length();
		sp=0;
		while ((sp<slength)&&(errorkind==0))
		{
			ch=s.charAt(sp);
			switch (ch)
			{
			case '$':
				while ((optionstack[otop]!=0)&&(errorkind==0))
				{
					switch (optionstack[otop])
					{
					case 1:
						break;
					case 2:
						if (dtop<=1) errorkind=3;
						if (errorkind==0)
						{
							totalfa++;
							fa[totalfa].kind=2;
							fa[totalfa].text="";
							fa[totalfa].first=digitstack[dtop-1];
							fa[totalfa].second=digitstack[dtop];
							fa[totalfa].width=fa[digitstack[dtop-1]].width+
								fa[digitstack[dtop]].width+1;
							if (fa[digitstack[dtop-1]].up>
								fa[digitstack[dtop]].up)
								j=fa[digitstack[dtop-1]].up;
							else
								j=fa[digitstack[dtop]].up;
							if (fa[digitstack[dtop-1]].down>
								fa[digitstack[dtop]].down)
								k=fa[digitstack[dtop-1]].down;
							else
								k=fa[digitstack[dtop]].down;
							fa[totalfa].height=j+k+1;
							fa[totalfa].up=j;
							fa[totalfa].down=k;
							dtop--;
							digitstack[dtop]=totalfa;
						}
						break;
					case 3:
						if (dtop<=1) errorkind=3;
						if (errorkind==0)
						{
							totalfa++;
							fa[totalfa].kind=3;
							fa[totalfa].text="";
							fa[totalfa].first=digitstack[dtop-1];
							fa[totalfa].second=digitstack[dtop];
							if (fa[digitstack[dtop-1]].width>
								fa[digitstack[dtop]].width)
							{
								j=fa[digitstack[dtop-1]].width;
								k=fa[digitstack[dtop]].width;
							}
							else
							{
								j=fa[digitstack[dtop]].width;
								k=fa[digitstack[dtop-1]].width;
							}
							fa[totalfa].width=j+4;
							fa[totalfa].height=fa[digitstack[dtop-1]].height+
								fa[digitstack[dtop]].height+1;
							fa[totalfa].up=fa[digitstack[dtop-1]].height;
							fa[totalfa].down=fa[digitstack[dtop]].height;
							dtop--;
							digitstack[dtop]=totalfa;
						}
						break;
					case 4:
						errorkind=4;
						break;
					case 5:
						break;
					default:
						break;
					}
					if (errorkind==0) otop--;
				}
				break;
			case '*':
				if (dtop<=0) errorkind=3;
				if (errorkind==0)
				{
					totalfa++;
					fa[totalfa].kind=1;
					fa[totalfa].text="";
					fa[totalfa].first=digitstack[dtop];
					fa[totalfa].second=0;
					fa[totalfa].width=fa[digitstack[dtop]].width+4;
					fa[totalfa].height=fa[digitstack[dtop]].height+2;
					fa[totalfa].up=fa[digitstack[dtop]].up+1;
					fa[totalfa].down=fa[digitstack[dtop]].down+1;
					digitstack[dtop]=totalfa;
				}
				break;
			case '.':
				if (optionstack[otop]==2)
				{
					if (dtop<=1) errorkind=3;
					if (errorkind==0)
					{
						totalfa++;
						fa[totalfa].kind=2;
						fa[totalfa].text="";
						fa[totalfa].first=digitstack[dtop-1];
						fa[totalfa].second=digitstack[dtop];
						fa[totalfa].width=fa[digitstack[dtop-1]].width+
							fa[digitstack[dtop]].width+1;
						if (fa[digitstack[dtop-1]].up>
							fa[digitstack[dtop]].up)
							j=fa[digitstack[dtop-1]].up;
						else
							j=fa[digitstack[dtop]].up;
						if (fa[digitstack[dtop-1]].down>
							fa[digitstack[dtop]].down)
							k=fa[digitstack[dtop-1]].down;
						else
							k=fa[digitstack[dtop]].down;
						fa[totalfa].height=j+k+1;
						fa[totalfa].up=j;
						fa[totalfa].down=k;
						dtop--;
						digitstack[dtop]=totalfa;
						otop--;
					}
				}
				if (errorkind==0)
				{
					otop++;
					optionstack[otop]=2;
				}
				break;
			case '|':
				if (optionstack[otop]==2)
				{
					if (dtop<=1) errorkind=3;
					if (errorkind==0)
					{
						totalfa++;
						fa[totalfa].kind=2;
						fa[totalfa].text="";
						fa[totalfa].first=digitstack[dtop-1];
						fa[totalfa].second=digitstack[dtop];
						fa[totalfa].width=fa[digitstack[dtop-1]].width+
							fa[digitstack[dtop]].width+1;
						if (fa[digitstack[dtop-1]].up>
							fa[digitstack[dtop]].up)
							j=fa[digitstack[dtop-1]].up;
						else
							j=fa[digitstack[dtop]].up;
						if (fa[digitstack[dtop-1]].down>
							fa[digitstack[dtop]].down)
							k=fa[digitstack[dtop-1]].down;
						else
							k=fa[digitstack[dtop]].down;
						fa[totalfa].height=j+k+1;
						fa[totalfa].up=j;
						fa[totalfa].down=k;
						dtop--;
						digitstack[dtop]=totalfa;
						otop--;
					}
				}
				if ((optionstack[otop]==3)&&(errorkind==0))
				{
					if (dtop<=1) errorkind=3;
					if (errorkind==0)
					{
						totalfa++;
						fa[totalfa].kind=3;
						fa[totalfa].text="";
						fa[totalfa].first=digitstack[dtop-1];
						fa[totalfa].second=digitstack[dtop];
						if (fa[digitstack[dtop-1]].width>
							fa[digitstack[dtop]].width)
						{
							j=fa[digitstack[dtop-1]].width;
							k=fa[digitstack[dtop]].width;
						}
						else
						{
							j=fa[digitstack[dtop]].width;
							k=fa[digitstack[dtop-1]].width;
						}
						fa[totalfa].width=j+4;
						fa[totalfa].height=fa[digitstack[dtop-1]].height+
							fa[digitstack[dtop]].height+1;
						fa[totalfa].up=fa[digitstack[dtop-1]].height;
						fa[totalfa].down=fa[digitstack[dtop]].height;
						dtop--;
						digitstack[dtop]=totalfa;
						otop--;
					}
				}
				if (errorkind==0)
				{
					otop++;
					optionstack[otop]=3;
				}
				break;
			case '(':
				otop++;
				optionstack[otop]=4;
				break;
			case ')':
				if (optionstack[otop]==2)
				{
					if (dtop<=1) errorkind=3;
					if (errorkind==0)
					{
						totalfa++;
						fa[totalfa].kind=2;
						fa[totalfa].text="";
						fa[totalfa].first=digitstack[dtop-1];
						fa[totalfa].second=digitstack[dtop];
						fa[totalfa].width=fa[digitstack[dtop-1]].width+
							fa[digitstack[dtop]].width+1;
						if (fa[digitstack[dtop-1]].up>
							fa[digitstack[dtop]].up)
							j=fa[digitstack[dtop-1]].up;
						else
							j=fa[digitstack[dtop]].up;
						if (fa[digitstack[dtop-1]].down>
							fa[digitstack[dtop]].down)
							k=fa[digitstack[dtop-1]].down;
						else
							k=fa[digitstack[dtop]].down;
						fa[totalfa].height=j+k+1;
						fa[totalfa].up=j;
						fa[totalfa].down=k;
						dtop--;
						digitstack[dtop]=totalfa;
						otop--;
					}
				}
				if ((optionstack[otop]==3)&&(errorkind==0))
				{
					if (dtop<=1) errorkind=3;
					if (errorkind==0)
					{
						totalfa++;
						fa[totalfa].kind=3;
						fa[totalfa].text="";
						fa[totalfa].first=digitstack[dtop-1];
						fa[totalfa].second=digitstack[dtop];
						if (fa[digitstack[dtop-1]].width>
							fa[digitstack[dtop]].width)
						{
							j=fa[digitstack[dtop-1]].width;
							k=fa[digitstack[dtop]].width;
						}
						else
						{
							j=fa[digitstack[dtop]].width;
							k=fa[digitstack[dtop-1]].width;
						}
						fa[totalfa].width=j+4;
						fa[totalfa].height=fa[digitstack[dtop-1]].height+
							fa[digitstack[dtop]].height+1;
						fa[totalfa].up=fa[digitstack[dtop-1]].height;
						fa[totalfa].down=fa[digitstack[dtop]].height;
						dtop--;
						digitstack[dtop]=totalfa;
						otop--;
					}
				}
				if (errorkind==0)
				{
					if (optionstack[otop]==4) otop--;
					else errorkind=4;
				}
				break;
			default:
				totalfa++;
				fa[totalfa].kind=0;
				fa[totalfa].text="";
				fa[totalfa].text=fa[totalfa].text+ch;
				fa[totalfa].first=0;
				fa[totalfa].second=0;
				fa[totalfa].width=3;
				fa[totalfa].height=1;
				fa[totalfa].up=0;
				fa[totalfa].down=0;
				dtop++;
				digitstack[dtop]=totalfa;
				break;
			}
			sp++;
		}
		return;
	}
	public boolean action(Event evt,Object arg)
	{
		if(evt.target instanceof Button)
		{
			if (arg=="include space nfa")
			{
				totalfa=0;
				dtop=0;
				otop=0;
				optionstack[otop]=0;
				s=tr.getText();
				slength=s.length();
				if (slength>maxlength) errorkind=1;
				if (errorkind==0)
				{
					i=0;
					while ((i<slength)&&(errorkind==0))
					{
						ch=s.charAt(i);
						if ((('0'<=ch)&&(ch<='9'))||(ch=='^')||(ch=='(')||
							(ch==')')||(ch=='*')||(ch=='|'))
							errorkind=errorkind;
						else
							errorkind=2;
						i++;
					}
				}
				if (errorkind==0)
				{
					s=s+'$';
					slength=s.length();
					sbak="";
					i=0;
					while (i<slength)
					{
						ch=s.charAt(i);
						sbak=sbak+ch;
						switch (ch)
						{
						case '$':
							break;
						case '*':
							if (s.charAt(i+1)=='(') sbak=sbak+'.';
							if (s.charAt(i+1)=='^') sbak=sbak+'.';
							if (('0'<=s.charAt(i+1))&&(s.charAt(i+1)<='9')) sbak=sbak+'.';
							break;
						case '|':
							break;
						case '(':
							break;
						case ')':
							if (s.charAt(i+1)=='(') sbak=sbak+'.';
							if (s.charAt(i+1)=='^') sbak=sbak+'.';
							if (('0'<=s.charAt(i+1))&&(s.charAt(i+1)<='9')) sbak=sbak+'.';
							break;
						default:
							if (s.charAt(i+1)=='(') sbak=sbak+'.';
							if (s.charAt(i+1)=='^') sbak=sbak+'.';
							if (('0'<=s.charAt(i+1))&&(s.charAt(i+1)<='9')) sbak=sbak+'.';
							break;
						}
						i++;
					}
					s=sbak;
					createfa();
				}
			}
		}
	repaint();
	return true;
	}
	public void paintdrawarrow1(Graphics g,int fromox,int fromoy,int toox,int tooy)
	{
		int largewidth,largeheight;
		int smallwidth,smallheight;
		int fromox1,fromoy1,toox1,tooy1;
		double larged;
		double alpha,alpha1,alpha2;
		largewidth=toox-fromox;
		largeheight=fromoy-tooy;
		larged=Math.sqrt(largewidth*largewidth+largeheight*largeheight);
		Long changetempwidth=new Long(Math.round((singleround/2)*largewidth/larged));
		smallwidth=changetempwidth.intValue();
		Long changetempheight=new Long(Math.round((singleround/2)*largeheight/larged));
		smallheight=changetempheight.intValue();
		fromox1=fromox+singleround/2+smallwidth;
		fromoy1=fromoy+singleround/2-smallheight;
		toox1=toox+singleround/2-smallwidth;
		tooy1=tooy+singleround/2+smallheight;
		g.drawLine(fromox1,fromoy1,toox1,tooy1);
		alpha=Math.atan(1.0*largeheight/largewidth);
		alpha=Math.PI+alpha;
		alpha1=alpha-Math.PI/7;
		alpha2=alpha+Math.PI/7;
		Long alpha1width=new Long(Math.round(Math.cos(alpha1)*7));
		Long alpha1height=new Long(Math.round(Math.sin(alpha1)*7));
		g.drawLine(toox1,tooy1,toox1+alpha1width.intValue(),tooy1-alpha1height.intValue());
		Long alpha2width=new Long(Math.round(Math.cos(alpha2)*7));
		Long alpha2height=new Long(Math.round(Math.sin(alpha2)*7));
		g.drawLine(toox1,tooy1,toox1+alpha2width.intValue(),tooy1-alpha2height.intValue());
		g.drawString("^",(fromox1+toox1)/2,(fromoy1+tooy1)/2);
	}
	public void paintdrawarrow2(Graphics g,int fromox,int fromoy,int toox,int tooy)
	{
		int largewidth,largeheight;
		int smallwidth,smallheight;
		int fromox1,fromoy1,toox1,tooy1;
		double larged;
		double alpha,alpha1,alpha2;
		largewidth=toox-fromox;
		largeheight=tooy-fromoy;
		larged=Math.sqrt(largewidth*largewidth+largeheight*largeheight);
		Long changetempwidth=new Long(Math.round((singleround/2)*largewidth/larged));
		smallwidth=changetempwidth.intValue();
		Long changetempheight=new Long(Math.round((singleround/2)*largeheight/larged));
		smallheight=changetempheight.intValue();
		fromox1=fromox+singleround/2+smallwidth;
		fromoy1=fromoy+singleround/2+smallheight;
		toox1=toox+singleround/2-smallwidth;
		tooy1=tooy+singleround/2-smallheight;
		g.drawLine(fromox1,fromoy1,toox1,tooy1);
		alpha=Math.atan(1.0*largeheight/largewidth);
		alpha=2*Math.PI-alpha;
		alpha1=alpha-Math.PI/7;
		alpha2=alpha+Math.PI/7;
		Long alpha1width=new Long(Math.round(Math.cos(alpha1)*7));
		Long alpha1height=new Long(Math.round(Math.sin(alpha1)*7));
		g.drawLine(toox1,tooy1,toox1-alpha1width.intValue(),tooy1+alpha1height.intValue());
		Long alpha2width=new Long(Math.round(Math.cos(alpha2)*7));
		Long alpha2height=new Long(Math.round(Math.sin(alpha2)*7));
		g.drawLine(toox1,tooy1,toox1-alpha2width.intValue(),tooy1+alpha2height.intValue());
		g.drawString("^",(fromox1+toox1)/2,(fromoy1+tooy1)/2);
	}
	public void paintdrawarrow3(Graphics g,int fromox,int fromoy,int toox,int tooy)
	{
		int largewidth,largeheight;
		int smallwidth,smallheight;
		int fromox1,fromoy1,toox1,tooy1;
		double larged;
		double alpha,alpha1,alpha2;
		largewidth=toox-fromox;
		largeheight=tooy-fromoy;
		larged=Math.sqrt(largewidth*largewidth+largeheight*largeheight);
		Long changetempwidth=new Long(Math.round((singleround/2)*largewidth/larged));
		smallwidth=changetempwidth.intValue();
		Long changetempheight=new Long(Math.round((singleround/2)*largeheight/larged));
		smallheight=changetempheight.intValue();
		fromox1=fromox+singleround/2+smallwidth;
		fromoy1=fromoy+singleround/2+smallheight;
		toox1=toox+singleround/2-smallwidth;
		tooy1=tooy+singleround/2-smallheight;
		g.drawLine(fromox1,fromoy1,toox1,tooy1);
		alpha=Math.atan(1.0*largeheight/largewidth);
		alpha=2*Math.PI-alpha;
		alpha1=alpha-Math.PI/7;
		alpha2=alpha+Math.PI/7;
		Long alpha1width=new Long(Math.round(Math.cos(alpha1)*7));
		Long alpha1height=new Long(Math.round(Math.sin(alpha1)*7));
		g.drawLine(toox1,tooy1,toox1-alpha1width.intValue(),tooy1+alpha1height.intValue());
		Long alpha2width=new Long(Math.round(Math.cos(alpha2)*7));
		Long alpha2height=new Long(Math.round(Math.sin(alpha2)*7));
		g.drawLine(toox1,tooy1,toox1-alpha2width.intValue(),tooy1+alpha2height.intValue());
		g.drawString("^",(fromox1+toox1)/2,(fromoy1+tooy1)/2);
	}
	public void paintdrawarrow4(Graphics g,int fromox,int fromoy,int toox,int tooy)
	{
		int largewidth,largeheight;
		int smallwidth,smallheight;
		int fromox1,fromoy1,toox1,tooy1;
		double larged;
		double alpha,alpha1,alpha2;
		largewidth=toox-fromox;
		largeheight=fromoy-tooy;
		larged=Math.sqrt(largewidth*largewidth+largeheight*largeheight);
		Long changetempwidth=new Long(Math.round((singleround/2)*largewidth/larged));
		smallwidth=changetempwidth.intValue();
		Long changetempheight=new Long(Math.round((singleround/2)*largeheight/larged));
		smallheight=changetempheight.intValue();
		fromox1=fromox+singleround/2+smallwidth;
		fromoy1=fromoy+singleround/2-smallheight;
		toox1=toox+singleround/2-smallwidth;
		tooy1=tooy+singleround/2+smallheight;
		g.drawLine(fromox1,fromoy1,toox1,tooy1);
		alpha=Math.atan(1.0*largeheight/largewidth);
		alpha=Math.PI+alpha;
		alpha1=alpha-Math.PI/7;
		alpha2=alpha+Math.PI/7;
		Long alpha1width=new Long(Math.round(Math.cos(alpha1)*7));
		Long alpha1height=new Long(Math.round(Math.sin(alpha1)*7));
		g.drawLine(toox1,tooy1,toox1+alpha1width.intValue(),tooy1-alpha1height.intValue());
		Long alpha2width=new Long(Math.round(Math.cos(alpha2)*7));
		Long alpha2height=new Long(Math.round(Math.sin(alpha2)*7));
		g.drawLine(toox1,tooy1,toox1+alpha2width.intValue(),tooy1-alpha2height.intValue());
		g.drawString("^",(fromox1+toox1)/2,(fromoy1+tooy1)/2);
	}
	public void paintdrawfa(Graphics g,int fanumber,int widththan,
		int startox,int startoy)
	{
		int iup,jdown;
		g.setColor(Color.blue);
		int fakind;
		fakind=fa[fanumber].kind;
		switch (fakind)
		{
		case 0:
			g.drawArc(startox,startoy,singleround,singleround,0,360);
			g.drawArc(startox+widththan*2
				,startoy,singleround,singleround,0,360);
			g.drawLine(startox+singleround,startoy+singleround/2,
				startox+widththan*2,startoy+singleround/2);
			g.drawLine(startox+widththan*2,startoy+singleround/2,
				startox+widththan*2-5,startoy+singleround/2-3);
			g.drawLine(startox+widththan*2,startoy+singleround/2,
				startox+widththan*2-5,startoy+singleround/2+3);
			g.drawString(fa[fanumber].text,startox+widththan+singleround/2-3,
				startoy+singleround/2-2);
			break;
		case 1:
			g.drawArc(startox,startoy,singleround,singleround,0,360);
			g.drawLine(startox+singleround,startoy+singleround/2,
				startox+widththan*2,startoy+singleround/2);
			g.drawLine(startox+widththan*2,startoy+singleround/2,
				startox+widththan*2-5,startoy+singleround/2-3);
			g.drawLine(startox+widththan*2,startoy+singleround/2,
				startox+widththan*2-5,startoy+singleround/2+3);
			g.drawString("^",startox+widththan+singleround/2-3,
				startoy+singleround/2-2);
			paintdrawfa(g,fa[fanumber].first,widththan,
				startox+widththan*2,startoy);
			g.drawArc(startox+widththan*(fa[fanumber].width-1)
				,startoy,singleround,singleround,0,360);
			g.drawLine(startox+widththan*(fa[fanumber].width-3)+singleround,startoy+singleround/2,
				startox+widththan*(fa[fanumber].width-1),startoy+singleround/2);
			g.drawLine(startox+widththan*(fa[fanumber].width-1),startoy+singleround/2,
				startox+widththan*(fa[fanumber].width-1)-5,startoy+singleround/2-3);
			g.drawLine(startox+widththan*(fa[fanumber].width-1),startoy+singleround/2,
				startox+widththan*(fa[fanumber].width-1)-5,startoy+singleround/2+3);
			g.drawString("^",startox+widththan*(fa[fanumber].width-2)+singleround/2-3,
				startoy+singleround/2-2);
			g.drawLine(startox+widththan*(fa[fanumber].width-3)+singleround/2,
				startoy,
				startox+widththan*(fa[fanumber].width-3)+singleround/2,
				startoy-singleheight*(fa[fanumber].up-1));
			g.drawArc(startox+widththan*(fa[fanumber].width-3)-singleround/2,
				startoy-singleheight*(fa[fanumber].up-1)-singleround/2,singleround,singleround,0,90);
			g.drawLine(startox+widththan*(fa[fanumber].width-3),
				startoy-singleheight*(fa[fanumber].up-1)-singleround/2,
				startox+widththan*2+singleround,
				startoy-singleheight*(fa[fanumber].up-1)-singleround/2);
			g.drawArc(startox+widththan*2+singleround/2,
				startoy-singleheight*(fa[fanumber].up-1)-singleround/2,
				singleround,singleround,90,90);
			g.drawLine(startox+widththan*2+singleround/2,
				startoy-singleheight*(fa[fanumber].up-1),
				startox+widththan*2+singleround/2,
				startoy);
			if (fa[fanumber].up==1)
			{
				g.drawLine(startox+widththan*2+singleround/2,startoy,
					startox+widththan*2+singleround/2-2,startoy-5);
				g.drawLine(startox+widththan*2+singleround/2,startoy,
					startox+widththan*2+singleround/2+5,startoy-4);
			}
			else
			{
				g.drawLine(startox+widththan*2+singleround/2,startoy,
					startox+widththan*2+singleround/2-3,startoy-5);
				g.drawLine(startox+widththan*2+singleround/2,startoy,
					startox+widththan*2+singleround/2+3,startoy-5);
			}
			g.drawString("^",startox+widththan*(fa[fanumber].width-1)/2+singleround/2-3,
				startoy-singleheight*(fa[fanumber].up-1)-singleround/2-2);
			g.drawLine(startox+singleround/2,
				startoy+singleround,
				startox+singleround/2,
				startoy+singleheight*fa[fanumber].down);
			g.drawArc(startox+singleround/2,
				startoy+singleheight*fa[fanumber].down-singleround/2,
				singleround,singleround,180,90);
			g.drawLine(startox+singleround,
				startoy+singleheight*fa[fanumber].down+singleround/2,
				startox+widththan*(fa[fanumber].width-1),
				startoy+singleheight*fa[fanumber].down+singleround/2);
			g.drawArc(startox+widththan*(fa[fanumber].width-1)-singleround/2,
				startoy+singleheight*fa[fanumber].down-singleround/2,
				singleround,singleround,270,90);
			g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
				startoy+singleheight*fa[fanumber].down,
				startox+widththan*(fa[fanumber].width-1)+singleround/2,
				startoy+singleround);
			if (fa[fanumber].down==1)
			{
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2-4,
					startoy+singleround+4);
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2+3,
					startoy+singleround+5);
			}
			else
			{
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2-3,
					startoy+singleround+5);
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2+3,
					startoy+singleround+5);
			}
			g.drawString("^",startox+widththan*(fa[fanumber].width-1)/2+singleround/2-3,
				startoy+singleheight*fa[fanumber].down+singleround/2-2);
			break;
		case 2:
			paintdrawfa(g,fa[fanumber].first,widththan,
				startox,startoy);
			g.drawLine(startox+widththan*(fa[fa[fanumber].first].width-1)+singleround,
				startoy+singleround/2,
				startox+widththan*(fa[fa[fanumber].first].width+1),
				startoy+singleround/2);
			g.drawLine(startox+widththan*(fa[fa[fanumber].first].width+1),
				startoy+singleround/2,
				startox+widththan*(fa[fa[fanumber].first].width+1)-5,
				startoy+singleround/2-3);
			g.drawLine(startox+widththan*(fa[fa[fanumber].first].width+1),
				startoy+singleround/2,
				startox+widththan*(fa[fa[fanumber].first].width+1)-5,
				startoy+singleround/2+3);
			g.drawString("^",startox+widththan*fa[fa[fanumber].first].width+singleround/2-3,
				startoy+singleround/2-2);
			paintdrawfa(g,fa[fanumber].second,widththan,
				startox+widththan*(fa[fa[fanumber].first].width+1),startoy);
			break;
		case 3:
			iup=fa[fa[fanumber].first].width;
			jdown=fa[fa[fanumber].second].width;
			if (iup<jdown)
			{
				iup=widththan*(jdown+2)/(iup+2);
				jdown=widththan;
			}
			else
			{
				jdown=widththan*(iup+2)/(jdown+2);
				iup=widththan;
			}
			g.drawArc(startox,startoy,singleround,singleround,0,360);
			paintdrawarrow1(g,startox,startoy,startox+iup*2,
				startoy-singleheight*(fa[fa[fanumber].first].down+1));
			paintdrawarrow2(g,startox,startoy,startox+jdown*2,
				startoy+singleheight*(fa[fa[fanumber].second].up+1));
			paintdrawfa(g,fa[fanumber].first,iup,
				startox+iup*2,startoy-singleheight*(fa[fa[fanumber].first].down+1));
			paintdrawfa(g,fa[fanumber].second,jdown,
				startox+jdown*2,startoy+singleheight*(fa[fa[fanumber].second].up+1));
			g.drawArc(startox+widththan*(fa[fanumber].width-1)
				,startoy,singleround,singleround,0,360);
			paintdrawarrow3(g,startox+iup*(fa[fa[fanumber].first].width+1),
				startoy-singleheight*(fa[fa[fanumber].first].down+1),
				startox+widththan*(fa[fanumber].width-1),startoy);
/*			g.drawLine(startox+iup*(fa[fa[fanumber].first].width+1)+singleround,
				startoy-singleheight*(fa[fa[fanumber].first].down+1)+singleround/2,
				startox+widththan*(fa[fanumber].width-1),
				startoy-singleheight*(fa[fa[fanumber].first].down+1)+singleround/2);
			g.drawArc(startox+widththan*(fa[fanumber].width-1)-singleround/2,
				startoy-singleheight*(fa[fa[fanumber].first].down+1)+singleround/2,
				singleround,singleround,0,90);
			if (fa[fa[fanumber].first].down==0)
			{
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy-singleheight*(fa[fa[fanumber].first].down+1)+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2-4,
					startoy-singleheight*(fa[fa[fanumber].first].down+1)+singleround-3);
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy-singleheight*(fa[fa[fanumber].first].down+1)+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2+3,
					startoy-singleheight*(fa[fa[fanumber].first].down+1)+singleround-5);
			}
			else
			{
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy-singleheight*(fa[fa[fanumber].first].down+1)+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy);
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy,
					startox+widththan*(fa[fanumber].width-1)+singleround/2-3,
					startoy-5);
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy,
					startox+widththan*(fa[fanumber].width-1)+singleround/2+3,
					startoy-5);
			}
			g.drawString("^",startox+iup*(fa[fa[fanumber].first].width+1)/2+widththan*(fa[fanumber].width-1)/2+singleround/2-3,
				startoy-singleheight*(fa[fa[fanumber].first].down+1)+singleround/2-2);
*/
			paintdrawarrow4(g,startox+jdown*(fa[fa[fanumber].second].width+1),
				startoy+singleheight*(fa[fa[fanumber].second].up+1),
				startox+widththan*(fa[fanumber].width-1),startoy);
/*
			g.drawLine(startox+jdown*(fa[fa[fanumber].second].width+1)+singleround,
				startoy+singleheight*(fa[fa[fanumber].second].up+1)+singleround/2,
				startox+widththan*(fa[fanumber].width-1),
				startoy+singleheight*(fa[fa[fanumber].second].up+1)+singleround/2);
			g.drawArc(startox+widththan*(fa[fanumber].width-1)-singleround/2,
				startoy+singleheight*(fa[fa[fanumber].second].up+1)-singleround/2,
				singleround,singleround,270,90);
			if (fa[fa[fanumber].second].up==0)
			{
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2-4,
					startoy+singleround+4);
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2+3,
					startoy+singleround+5);
			}
			else
			{
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy+singleheight*(fa[fa[fanumber].second].up+1),
					startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy+singleround);
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2-3,
					startoy+singleround+5);
				g.drawLine(startox+widththan*(fa[fanumber].width-1)+singleround/2,
					startoy+singleround,
					startox+widththan*(fa[fanumber].width-1)+singleround/2+3,
					startoy+singleround+5);
			}
			g.drawString("^",startox+jdown*(fa[fa[fanumber].second].width+1)/2+widththan*(fa[fanumber].width-1)/2+singleround/2-3,
				startoy+singleheight*(fa[fa[fanumber].second].up+1)+singleround/2-2);
*/
			break;
		default:
			break;
		}
	}
	public void paint(Graphics g)
	{
		switch (errorkind)
		{
		case 0:
			g.drawString("right",10,100);
			errorkind=0;
			break;
		case 1:
			g.drawString("too long",10,100);
			errorkind=0;
			break;
		case 2:
			g.drawString("unknown char",10,100);
			errorkind=0;
			break;
		case 3:
			g.drawString("express error",10,100);
			errorkind=0;
			break;
		case 4:
			g.drawString("left does not match right",10,100);
			errorkind=0;
			break;
		default:
			break;
		}
		g.drawString(s,10,200);
		g.drawString(String.valueOf(totalfa),10,220);
		if (totalfa==0)
		{
			g.drawString("space",10,230);
		}
		else
		{
			paintdrawfa(g,totalfa,singlewidth,ox,oy+fa[totalfa].up*singleheight);
		}
	}
}
