import java.awt.*;
import java.awt.event.*;

public class Tfuhaod extends Dialog implements ActionListener
{
	TextField Edit1;
	Label Label1;
	TextField Edit2;
	Label Label2;
	
	Button OKBtn;
	Button CancelBtn;
	Button HelpBtn;

	AnalyzerFrame m_Frame;
	Tfuhaod(AnalyzerFrame frame)
	{
		super(frame,"��ʼ����",true);
		m_Frame=frame;
		create();

	}
	
	public void create()
	{
		setLayout(null);
		setBounds(100,100,300,100);
		
		Label1=new Label("����");
		Label1.setBounds(5,40,30,20);
		Label1.setVisible(false);
		
		Edit1=new TextField(null);
		Edit1.setBounds(10+30,40,30,20);
		Edit1.setVisible(false);
		
		Label2=new Label("����");
		Label2.setBounds(15+60,40,30,20);
		Label2.setVisible(false);
		
		Edit2=new TextField(null);
		Edit2.setBounds(20+90,40,100,20);
		Edit2.setVisible(false);
			
		OKBtn=new Button("ȷ��");
		OKBtn.setBounds(30,70,36,20);
		OKBtn.setVisible(false);
		OKBtn.addActionListener(this);
		
		CancelBtn=new Button("ȡ��");
		CancelBtn.setBounds(100,70,36,20);
		CancelBtn.setVisible(false);
		CancelBtn.addActionListener(this);
		
		HelpBtn=new Button("����");
		HelpBtn.setBounds(170,70,36,20);
		HelpBtn.setVisible(false);
		HelpBtn.addActionListener(this);
	}
	
	public void OKBtnClick()
	{
		int i,j;
		if((Edit1.getText()=="")||(Edit2.getText()==""))
		{
			m_Frame.application.messagebox("����ȫ��Ϣ!","����!",m_Frame.mb_ok);
			Edit1.requestFocus();
			return;
		}
		try
		{
			Integer temp_Int=new Integer(Edit1.getText());
			i=temp_Int.intValue();
		}
		catch(NumberFormatException e)
		{
			m_Frame.application.messagebox("�������Ϊ����!","����!",m_Frame.mb_ok);
			Edit1.requestFocus();
			return;
		}
		j=1;
		while((j<=m_Frame.form1.fzjnum)&&(m_Frame.form1.fzjfuhao[j].name!=Edit2.getText()))
		{
			j++;
		}
		if(j<=m_Frame.form1.fzjnum)
		{
			m_Frame.application.messagebox("�벻Ҫ����ս��������!","����!",m_Frame.mb_ok);
			Edit1.requestFocus();
			return;
		}
		while((j<=m_Frame.form1.zjnum)&&(m_Frame.form1.zjfuhao[j].index!=i)&&(m_Frame.form1.zjfuhao[j].name!=Edit2.getText()))
		{
			j++;
		}
		if(j>m_Frame.form1.zjnum)
		{
			setVisible(false);
		}
		else
		{
			if(m_Frame.form1.zjfuhao[j].index==i)
			{
				m_Frame.application.messagebox("�����ظ�!","����",m_Frame.mb_ok);
				Edit1.requestFocus();
			}
			else
			{
				m_Frame.application.messagebox("�ս���ظ�!","����",m_Frame.mb_ok);
				Edit1.requestFocus();
			}
			return;
		}																  
	}
	public void FormActivate()
	{
		Edit1.setText(null);
		Edit2.setText(null);
		Edit1.requestFocus();
	}
	
	public  void actionPerformed( ActionEvent e ) 
	{
		if(e.getSource().equals(OKBtn))
		{
			OKBtnClick();
			setVisible(false);
		}
		else
		{
			if(e.getSource().equals(CancelBtn))
			{
				setVisible(false);
			}
			else
			{
				if(e.getSource().equals(HelpBtn))
				{
					setVisible(false);
				}
			}
		}
	}

}
