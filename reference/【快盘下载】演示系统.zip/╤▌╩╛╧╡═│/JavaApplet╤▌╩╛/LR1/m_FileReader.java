import java.io.*;
import java.applet.*;
import java.awt.*;

class m_FileReader extends FileReader
{
	m_FileReader(String fileName) throws IOException
	{
		super(fileName);
	}
	public String readLine() throws IOException 
	{
		String m_Line=null;
		char m_Character;
		m_Line=new String();
		m_Character=(char)read();

		if ((int)m_Character==65535){ return null;}
		if(m_Character==13){m_Line+=m_Character;return m_Line;}
		do
		{
			m_Line+=m_Character;
			m_Character=(char)read();
		}
		while(((int)m_Character!=65535)&&((int)m_Character!=13));
		if((int)m_Character==13)
		{
			m_Character=(char)read();
			if(m_Character==10){m_Line+=m_Character;}
		}
		return m_Line;
	}
}
