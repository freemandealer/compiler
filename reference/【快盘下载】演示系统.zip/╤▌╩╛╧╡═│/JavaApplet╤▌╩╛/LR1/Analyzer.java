import java.awt.*;

public class Analyzer
{
 AnalyzerFrame   m_Frame		=null;
 
 int m_Width;
 int m_Height;
 
 List lst;

 public Analyzer(AnalyzerFrame frame,int width,int height)
 {
   m_Frame=frame;
   m_Width=width;
   m_Height=height;
   Create();
   setVisible(false);
   

 
 }
 public void Create()
 {
/* lst = new List(4, false);
 lst.add("Mercury");
 lst.add("Venus");
 lst.add("Earth");
 lst.add("JavaSoft");
 lst.add("Mars");
 lst.add("Jupiter");
 lst.add("Saturn");
 lst.add("Uranus");
 lst.add("Neptune");
 lst.add("Pluto");
 lst.setBounds(30,100,100,30);
 m_Frame.add(lst);*/
 }
 public void setVisible(boolean flag)
 {
	 if(flag)
	 {
		 m_Frame.application.messagebox("Hi                  Boy","test",m_Frame.mb_okcancel);
		 String title[];
		 title=new String[3];
		 title[0]="test";
		 title[1]="ok";
		 title[2]="hi";
		 int w[];
		 w=new int[3];
		 w[0]=80;
		 w[1]=100;
		 w[2]=40;
		 StringGrid grid1=new StringGrid(3,title,w,300,200);
		 m_Frame.add(grid1);
		 grid1.setBounds(50,100,300,200);
	//	 grid1.setBackground(Color.blue);
		 grid1.cells(2,2,"adf");
		 grid1.cells(1,2,"afdffdfdfdfdfdfsdfafdfdfsfdfa");
		 grid1.cells(0,2,"a");
		 grid1.setVisible(true);

		 grid1.repaint();
	 }
	/* lst.setVisible(flag);*/

 }
}
