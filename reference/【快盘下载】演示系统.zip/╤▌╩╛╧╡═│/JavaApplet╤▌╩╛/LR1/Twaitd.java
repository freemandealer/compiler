import java.awt.*;
import java.awt.event.*;

public class Twaitd extends Dialog 
{
	AnalyzerFrame m_Frame;
	Label Label1;
	Panel Panel1;

	Twaitd(AnalyzerFrame frame)
	{
		super(frame,"����",true);
		m_Frame=frame;
		create();
	}
	public void create()
	{
		setLayout(null);
		setBounds(100,100,300,100);

		Label1=new Label("����First����Follow��");
		Label1.setBounds(10,40,150,20);
		Label1.setVisible(false);
		
		Panel1=new Panel(null);
		Panel1.setBounds(10,70,250,20);
		Panel1.setVisible(false);
	}
		
}
