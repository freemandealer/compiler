import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class ErrorDlg extends Dialog implements ActionListener
{
	int m_Mode;
	AnalyzerFrame m_Frame;
	Label m_Label_message;
	Button m_OkBtn;
	Button m_CancelBtn;
	ErrorDlg(AnalyzerFrame frame)
	{
		super(frame);		
		m_Label_message=new Label();
		add(m_Label_message);
		m_Label_message.setVisible(false);
		
		m_OkBtn=new Button("ȷ��");
		add(m_OkBtn);
		m_OkBtn.setVisible(false);
		m_OkBtn.addActionListener(this);
		
		m_CancelBtn=new Button("ȡ��");
		add(m_CancelBtn);
		m_CancelBtn.setVisible(false);
		m_CancelBtn.addActionListener(this);
		
		this.setModal(true);
		m_Frame=frame;
		this.setLayout(null);
		
	}
	public int messagebox(String message,String title,int mode)
	{
		int width;
		this.setTitle(title);
		m_Label_message.setText(message);
		width=message.length()*6+12;
		if (width<100)
		{
			width=100;
		}
		m_Label_message.setBounds(10,30,width,20);
		width+=20;
		m_Label_message.setVisible(true);
		this.setBounds(100,100,width,80);
		
		switch(mode)
		{
		case m_Frame.mb_ok:
			{
				m_OkBtn.setVisible(true);
				m_OkBtn.setBounds(width/2-15,50,30,20);
				m_CancelBtn.setVisible(false);
				break;
			}
		case m_Frame.mb_okcancel:
			{
				m_CancelBtn.setVisible(true);
				m_CancelBtn.setBounds(3*width/5,50,30,20);

				m_OkBtn.setVisible(true);
				m_OkBtn.setBounds(2*width/5-30,50,30,20);
				break;
			}
		}
		this.show();
		return m_Mode;
	}

	public  boolean handleEvent( Event e ) 
	{
		if (e.id==Event.WINDOW_DESTROY)
		{
			this.hide();
			return true;
		}
		return super.handleEvent(e);	
	}
	public void actionPerformed( ActionEvent e ) 
	{
		if(e.getSource().equals(m_OkBtn))
		{
			this.hide();
			m_Mode=m_Frame.mb_ok;
			
			
		}
		if(e.getSource().equals(m_CancelBtn))
		{
			this.hide();
			m_Mode=m_Frame.mb_cancel;
		}
	}
}
