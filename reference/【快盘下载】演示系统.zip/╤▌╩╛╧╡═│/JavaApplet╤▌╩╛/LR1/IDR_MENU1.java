import java.awt.*;
import java.io.*;

public class IDR_MENU1 {
 AnalyzerFrame   m_Frame        = null;
 boolean m_fInitialized = false;

 // MenuBar definitions
 MenuBar mb;

 // Menu and Menu item definitions
 Menu m1;                  // File
 MenuItem ID_FILE_NEW;     //New
 MenuItem ID_FILE_OPEN;    // Open 
 MenuItem ID_FILE_SAVE;    //Save
 MenuItem ID_FILE_SAVE_AS; //Save As
 MenuItem ID_FILE_CLOSE;   // Close
 MenuItem ID_FILE_OPEN_LR1;//OPEN_LR1
 MenuItem ID_FILE_SAVE_LR1;//SAVE_LR1
 MenuItem ID_FILE_SAVE_AS_LR1;//SAVE_AS_LR1
 MenuItem ID_FILE_SAVE_TREE;//SAVE_TREE
 MenuItem m4;              // Separator
 MenuItem ID_FILE_EXIT;    // Exit

 Menu m_View;
 CheckboxMenuItem ID_VIEW_FORMULA;
 CheckboxMenuItem ID_VIEW_FIRST_FOLLOW_SET;
 CheckboxMenuItem ID_VIEW_STATUS_SET;
 CheckboxMenuItem ID_VIEW_ANALYSIS_DIAGRAM;
 CheckboxMenuItem ID_VIEW_ANALYZER;
 
 Menu m6;                  // Help
 MenuItem ID_HELP_MANUAL;     // Manual
 MenuItem ID_HELP_ABOUT;    // ABOUT
 
 // Constructor
 public IDR_MENU1 (AnalyzerFrame frame) {
  m_Frame = frame;
 }

 // Initialization.
 public boolean CreateMenu() {
  // Can only init controls once
  if (m_fInitialized || m_Frame == null)
   return false;

  // Create menubar and attach to the frame
  mb = new MenuBar();
  m_Frame.setMenuBar(mb);

  // Create menus and menu items and assign to menubar

  // Create File menu
  m1 = new Menu("�ļ�");
  mb.add(m1);
   ID_FILE_NEW = new MenuItem("New");
   m1.add(ID_FILE_NEW);
   
   ID_FILE_OPEN = new MenuItem("Open �ķ�");
   m1.add(ID_FILE_OPEN);

   ID_FILE_SAVE = new MenuItem("Save �ķ�");
   m1.add(ID_FILE_SAVE);
   ID_FILE_SAVE_AS=new MenuItem("Save as �ķ�");
   m1.add(ID_FILE_SAVE_AS); //Save As
   ID_FILE_OPEN_LR1=new MenuItem("Open LR1 �ķ�");
   m1.add(ID_FILE_OPEN_LR1);//OPEN_LR1
   ID_FILE_SAVE_LR1=new MenuItem("Save LR1 �ķ�");
   m1.add(ID_FILE_SAVE_LR1);//SAVE_LR1
   ID_FILE_SAVE_AS_LR1=new MenuItem("Save As LR1 �ķ�");
   m1.add(ID_FILE_SAVE_AS_LR1);//SAVE_AS_LR1
   ID_FILE_SAVE_TREE=new MenuItem("Save �ķ���");
   m1.add(ID_FILE_SAVE_TREE);//SAVE_TREE
   m4 = new MenuItem("-");
   m1.add(m4);
   ID_FILE_EXIT = new MenuItem("Exit");
   m1.add(ID_FILE_EXIT);
   
   m_View=new Menu("�鿴");
   mb.add(m_View);
   ID_VIEW_FORMULA=new CheckboxMenuItem("����ʽ");
   m_View.add(ID_VIEW_FORMULA);
   ID_VIEW_FORMULA.addItemListener(m_Frame);
   
   ID_VIEW_FIRST_FOLLOW_SET=new CheckboxMenuItem("First Follow ��");
   m_View.add(ID_VIEW_FIRST_FOLLOW_SET);
   ID_VIEW_FIRST_FOLLOW_SET.addItemListener(m_Frame);
	 
   ID_VIEW_STATUS_SET=new CheckboxMenuItem("״̬��");
   m_View.add(ID_VIEW_STATUS_SET);
   ID_VIEW_STATUS_SET.addItemListener(m_Frame);
  
   
   ID_VIEW_ANALYSIS_DIAGRAM=new CheckboxMenuItem("������");
   m_View.add(ID_VIEW_ANALYSIS_DIAGRAM);
   ID_VIEW_ANALYSIS_DIAGRAM.addItemListener(m_Frame);
   

   ID_VIEW_ANALYZER=new CheckboxMenuItem("������");
   m_View.add(ID_VIEW_ANALYZER);
   ID_VIEW_ANALYZER.addItemListener(m_Frame);
   
	   
  // Create Edit menu
  m6 = new Menu("����");
  mb.add(m6);
   ID_HELP_MANUAL = new MenuItem("ʹ��˵��");
   m6.add(ID_HELP_MANUAL);
   ID_HELP_ABOUT = new MenuItem("����LR1�ķ���������ʾ����");
   m6.add(ID_HELP_ABOUT);

  m_fInitialized = true;
  return true;
 }
 
 public void DeleteMenu()
 {
   m1.removeAll();
   m6.removeAll();
   m_View.removeAll();
   mb.remove(m_View);
   mb.remove(m1);
   mb.remove(m6);
   mb.removeNotify();
   m_Frame.remove(mb);
 }
}
