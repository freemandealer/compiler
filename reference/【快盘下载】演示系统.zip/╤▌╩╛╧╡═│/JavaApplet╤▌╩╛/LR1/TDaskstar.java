import java.awt.*;
import java.awt.event.*;

public class TDaskstar extends Dialog implements ActionListener
{
	TextField Edit1;
	Label Label1;
	Button OKBtn;
	Button CancelBtn;
	Button HelpBtn;

	AnalyzerFrame m_Frame;
	TDaskstar(AnalyzerFrame frame)
	{
		super(frame,"��ʼ����",true);
		m_Frame=frame;
		create();

	}
	
	public void create()
	{
		setLayout(null);
		setBounds(100,100,300,100);
		
		Label1=new Label("��ʼ���ź���");
		Label1.setBounds(5,40,100,20);
		Label1.setVisible(false);
		
		Edit1=new TextField(null);
		Edit1.setBounds(10+100,40,100,20);
		Edit1.setVisible(false);
		
		OKBtn=new Button("ȷ��");
		OKBtn.setBounds(30,70,36,20);
		OKBtn.setVisible(false);
		OKBtn.addActionListener(this);
		
		CancelBtn=new Button("ȡ��");
		CancelBtn.setBounds(100,70,36,20);
		CancelBtn.setVisible(false);
		CancelBtn.addActionListener(this);
		
		HelpBtn=new Button("����");
		HelpBtn.setBounds(170,70,36,20);
		HelpBtn.setVisible(false);
		HelpBtn.addActionListener(this);
	}
	
	public void OKBtnClick()
	{
		int i,j;
		Edit1.requestFocus();
		try
		{
			Integer temp_Int=new Integer(Edit1.getText());
			i=temp_Int.intValue();
		}
		catch(NumberFormatException e)
		{
			m_Frame.application.messagebox("����������","����!",m_Frame.mb_ok);
			return;
		}
		j=1;
		while((j<=m_Frame.form1.fzjnum)&&(m_Frame.form1.fzjfuhao[j].index!=i))
		{
			j++;
		}
		if(j>m_Frame.form1.fzjnum)
		{
			m_Frame.application.messagebox("���������еķ��ս���ź���!","����!",m_Frame.mb_ok);
		}
		else
		{
			this.setVisible(false);
		}
																		  
	}
	public void FormActivate()
	{
		Edit1.requestFocus();
	}
	
	public  void actionPerformed( ActionEvent e ) 
	{
		if(e.getSource().equals(OKBtn))
		{
			OKBtnClick();
			setVisible(false);
		}
		else
		{
			if(e.getSource().equals(CancelBtn))
			{
				setVisible(false);
			}
			else
			{
				if(e.getSource().equals(HelpBtn))
				{
					setVisible(false);
				}
			}
		}
	}
}
