import java.awt.event.*;
import java.applet.*;
import java.awt.*;


public class lr1 extends Applet implements ActionListener
{
 // Button and Frame components
 Button   makeAnalyzerButton = new Button(" lr1 �ķ�������������");
 AnalyzerFrame theFrame;
 int m_Width=640;
 int m_Height=430;

 int count = 0;

 // Initialize applet and create button
 public void init() {
  resize(m_Width,m_Height);
  makeAnalyzerButton.setEnabled(true);
  add(makeAnalyzerButton);
  makeAnalyzerButton.addActionListener(this);
 }

 // Display instructions in applet window
 public void paint(Graphics g) {
  g.drawString("Click button to begin the demo of lr1 �ķ�������������", 10, 50);
 }

 // Respond to applet button selection
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==makeAnalyzerButton){
         theFrame = new AnalyzerFrame(makeAnalyzerButton, 
          "lr1 �ķ�������������",m_Width,m_Height);
          // Make frame visible
         theFrame.show();
         // Disable button so it can't be reselected
         // until window is closed (hidden)
         makeAnalyzerButton.setEnabled(false);
         // Signal that we've handled this event
		}
	}
}
