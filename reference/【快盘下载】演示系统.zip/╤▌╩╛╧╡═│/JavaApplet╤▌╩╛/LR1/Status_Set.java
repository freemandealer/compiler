import java.awt.*;

public class Status_Set
{
 AnalyzerFrame   m_Frame		= null;
 
 TextArea m_Text_Status			=null;
 TextArea m_Text_Item			=null;

 Label m_Label_Status			=null;
 Label m_Label_Item				=null;
 
 int m_Width;
 int m_Height;

 public Status_Set(AnalyzerFrame frame,int width,int height)
 {
   m_Frame=frame;
   m_Width=width;
   m_Height=height;
   Create();
   setVisible(false);
 }
 public void Create()
 {
	 m_Label_Status=new Label("״̬");
	 m_Label_Status.setBounds(5,60-15,36,15);
	 m_Frame.add(m_Label_Status);
	 
	 m_Text_Status=new TextArea(null);
	 m_Text_Status.setBounds(5,60,(m_Width-10)/5,(m_Height-100)-20);
	 m_Frame.add(m_Text_Status);

	 m_Label_Item=new Label("��Ŀ");
	 m_Label_Item.setBounds(5+(m_Width-10)/5,60-15,36,15);
	 m_Frame.add(m_Label_Item);
	 
	 m_Text_Item=new TextArea(null);
	 m_Text_Item.setBounds(5+(m_Width-10)/5,60,4*(m_Width-10)/5,(m_Height-100)-20);
	 m_Frame.add(m_Text_Item);

	 
 }
 public void setVisible(boolean flag)
 {
	 m_Label_Status.setVisible(flag);
	 m_Text_Status.setVisible(flag);
	 m_Label_Item.setVisible(flag);
	 m_Text_Item.setVisible(flag);

 }
}
