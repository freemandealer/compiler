import java.awt.*;

public class Formula
{
 Frame   m_Frame        = null;
 StringGrid StringGrid1=null;
 StringGrid StringGrid2=null;
 StringGrid StringGrid3=null;
 Label m_Label_Not_End_Symbol=null;
 Label m_Label_End_Symbol=null;
 Label m_Label_Produce_Formula=null;
 
 Label m_Label_Number;
 TextField m_Text_Number;
 Button m_Button_Refresh;
 
 Button m_Button_Add1;
 Button m_Button_Delete1;
 
 Button m_Button_Add2;
 Button m_Button_Modify;
 Button m_Button_Delete2;
 Button m_Button_Caculate;

 
 int m_Width;
 int m_Height;

 public Formula(Frame frame,int width,int height)
 {
   m_Frame=frame;
   m_Width=width;
   m_Height=height;
   Create();
   setVisible(false);
 }
 public void Create()
 {
	 m_Label_Not_End_Symbol=new Label("���ս��");
	 m_Label_Not_End_Symbol.setBounds(5,60-15,48,15);
	 m_Frame.add(m_Label_Not_End_Symbol);
	 
	 String s[];
	 s=new String[2];
	 s[0]="����";
	 s[1]="���ս����";
	 int i[];
	 i=new int[2];
	 i[0]=30;
	 i[1]=(m_Width-10)/3-30-2;
		 
	 StringGrid1=new StringGrid(2,s,i,(m_Width-10)/3,(m_Height-100)/2-20);
	 StringGrid1.setBounds(5,60,(m_Width-10)/3,(m_Height-100)/2-20);
	 m_Frame.add(StringGrid1);
	 
	 m_Label_Number=new Label("��Ŀ");
	 m_Label_Number.setBounds(50,60+(m_Height-100)/2-20+2,12*2,20);
	 m_Frame.add(m_Label_Number);
	 
	 m_Text_Number=new TextField("0");
	 m_Text_Number.setBounds(50+12*3,60+(m_Height-100)/2-20+2,12*3,20);
	 m_Frame.add(m_Text_Number);

	 m_Button_Refresh=new Button("ˢ��");
	 m_Button_Refresh.setBounds(50+12*8,60+(m_Height-100)/2-20+2,12*3,20);
	 m_Frame.add(m_Button_Refresh);
	 m_Button_Refresh.setEnabled(true);
	//////////////////////////////////////////////////////// 
	 m_Label_End_Symbol=new Label("�ս��" );
	 m_Label_End_Symbol.setBounds(5,60+(m_Height-100)/2+20-15,12*3,15);
	 m_Frame.add(m_Label_End_Symbol);
	 
	 s[0]="����";
	 s[1]="�ս����";
	 i[0]=30;
	 i[1]=(m_Width-10)/3-30-2;
	 StringGrid3=new StringGrid(2,s,i,(m_Width-10)/3,(m_Height-100)/2-20);
	 StringGrid3.setBounds(5,60+(m_Height-100)/2+20,(m_Width-10)/3,(m_Height-100)/2-20);
	 m_Frame.add(StringGrid3);
	 
	 m_Button_Add1=new Button("����");
	 m_Button_Add1.setBounds(50,60+(m_Height-100)+2,12*3,20);
	 m_Frame.add(m_Button_Add1);
	 
	 m_Button_Delete1=new Button("ɾ��");
	 m_Button_Delete1.setBounds(50+12*8,60+(m_Height-100)+2,12*3,20);
	 m_Frame.add(m_Button_Delete1);
	 
     ///////////////////////////////	 
	 m_Label_Produce_Formula=new Label("����ʽ");
	 m_Label_Produce_Formula.setBounds(10+(m_Width-10)/3,60-15,12*4,15);
	 m_Frame.add(m_Label_Produce_Formula);

	 s[0]="����";
	 s[1]="����ʽ";
	 i[0]=30;
	 i[1]=2*(m_Width-10)/3-30-2-5;
	 StringGrid2=new StringGrid(2,s,i,2*(m_Width-10)/3-5,(m_Height-80)-20);
	 StringGrid2.setBounds(10+(m_Width-10)/3,60,2*(m_Width-10)/3-5,(m_Height-80)-20);
	 m_Frame.add(StringGrid2);
	 
	 m_Button_Add2=new Button("����");
	 m_Button_Add2.setBounds(50+10+(m_Width-10)/3,60+(m_Height-100)+2,12*3,20);
	 m_Frame.add(m_Button_Add2);
	 
	 m_Button_Modify=new Button("�޸�");
	 m_Button_Modify.setBounds(50+12*8+10+(m_Width-10)/3,60+(m_Height-100)+2,12*3,20);
	 m_Frame.add(m_Button_Modify);
	 
	 m_Button_Delete2=new Button("ɾ��");
	 m_Button_Delete2.setBounds(50+12*16+10+(m_Width-10)/3,60+(m_Height-100)+2,12*3,20);
	 m_Frame.add(m_Button_Delete2);
	 
	 m_Button_Caculate=new Button("����");
	 m_Button_Caculate.setBounds(50+12*24+10+(m_Width-10)/3,60+(m_Height-100)+2,12*3,20);
	 m_Frame.add(m_Button_Caculate); 
 }
 public void setVisible(boolean flag)
 {

	 StringGrid2.setVisible(flag);
	 StringGrid2.repaint();
	 
	 StringGrid3.setVisible(flag);
	 StringGrid3.repaint();
	 m_Label_Not_End_Symbol.setVisible(flag);
	 m_Label_End_Symbol.setVisible(flag);
	 m_Label_Produce_Formula.setVisible(flag);
	 
	 m_Label_Number.setVisible(flag);
	 m_Text_Number.setVisible(flag);
	 m_Button_Refresh.setVisible(flag);
	 
	 m_Button_Add1.setVisible(flag);
	 m_Button_Delete1.setVisible(flag);
	 
	 m_Button_Add2.setVisible(flag);
	 m_Button_Modify.setVisible(flag);
	 m_Button_Delete2.setVisible(flag);
	 m_Button_Caculate.setVisible(flag);
	 StringGrid1.setVisible(flag);
	 StringGrid1.repaint();	 
 }
}
