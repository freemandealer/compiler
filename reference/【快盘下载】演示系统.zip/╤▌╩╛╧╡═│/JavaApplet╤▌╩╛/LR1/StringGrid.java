import java.awt.*;
public class StringGrid extends Panel 
{
	Button cols[];
	int rowcount;
	String cells[];
	static int Max_rowcount=100;
	int m_cols_width[];
	TextArea m_TextArea;
	
	int m_cols_num;
	
	StringGrid(int cols_num,String cols_title[],int cols_width[],int w,int h)
	{
		super();
		setLayout(null);
		setSize(w,Max_rowcount*20+20);
		cols=new Button[cols_num];
		cells=new String[cols_num*Max_rowcount];
		m_cols_num=cols_num;
		m_cols_width=new int[cols_num];
		for(int i=0;i<cols_num;i++)
		{
			m_cols_width[i]=cols_width[i];
		}
		
 		int i;
		int j;
		int m_x=0;
		int m_y=0;
		int width=0;
		int height=20;
		rowcount=10;
		for(i=0;i<m_cols_num;i++)
		{
			m_x+=width+1;
			cols[i]=new Button(cols_title[i]);
			cols[i].setBounds(m_x,m_y,cols_width[i],height);
			cols[i].setVisible(true);
			add(cols[i]);
			width=cols_width[i];
		}	
		for(j=0;j<Max_rowcount;j++)
		{
			width=0;
			m_x=0;
			m_y+=height+1;
			for(i=0;i<m_cols_num;i++)
			{
				int index=i+j*m_cols_num;
				m_x+=width+1;
				cells[index]=new String("null");
				width=cols_width[i];
			}
		}
		m_TextArea=new TextArea();
		m_TextArea.setBounds(0,21,w,h-21);
		add(m_TextArea);
	}
	public void paint(Graphics g) 
	{
	}
	public void show_TextArea()
	{
		int i,j;
		String temp=new String();
		m_TextArea.setText(null);
		for(j=0;j<rowcount;j++)
		{
			temp="";
			for(i=0;i<m_cols_num;i++)
			{
				temp+=cells[i+j*m_cols_num];
				temp+=' ';
			}
			char t=13;
			temp+=t;
			t=10;
			temp+=t;
			m_TextArea.append(temp);
		}
		m_TextArea.setVisible(true);
		repaint();
	}
	public void cells(int i,int j,String text)
	{
		String temp=new String();
		int x;
		x=m_cols_width[i]/6;
		text.trim();
		if (text.length()>x)
		{
			int k;
			temp="";
			for(k=0;k<x;k++)
			{
				temp+=text.charAt(k);
			}
		}
		else
		{
			int k;
			temp=text;
			for(k=0;k<x-text.length();k++)
			{
				temp+=' ';
			}
		}
		cells[i+j*m_cols_num]=temp;
	}
	public void setVisible(boolean flag)
	{
		if(flag==true)
		{
			show_TextArea();
		}
		super.setVisible(flag);
	}
}
