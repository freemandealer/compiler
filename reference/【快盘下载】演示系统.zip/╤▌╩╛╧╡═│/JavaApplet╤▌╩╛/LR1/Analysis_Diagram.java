import java.awt.*;

public class Analysis_Diagram
{
 AnalyzerFrame   m_Frame		=null;
 
 TextArea m_Text_Number3		=null;
 ScrollPane m_Pane_End_Symbol3	=null;
 ScrollPane m_Pane_Not_End_Symbol3 =null;

 Label m_Label_Number3			=null;
 Label m_Label_End_Symbol3		=null;
 Label m_Label_Not_End_Symbol3  =null;
 
 Label m_Label_Status3			=null;
 TextField m_Field_Status3		=null;
 
 Label m_Label_Symbol3			=null;
 TextField m_Field_Symbol3		=null;
 
 Label m_Label_Action3			=null;
 TextField m_Field_Action3		=null;
 
 Label m_Label_Formula3			=null;
 TextField m_Field_Formula3		=null;
 
 int m_Width;
 int m_Height;

 public Analysis_Diagram(AnalyzerFrame frame,int width,int height)
 {
   m_Frame=frame;
   m_Width=width;
   m_Height=height;
   Create();
   setVisible(false);
 }
 public void Create()
 {
	 m_Label_Number3=new Label("״̬");
	 m_Label_Number3.setBounds(5,60-15,36,15);
	 m_Frame.add(m_Label_Number3);
	 
	 m_Text_Number3=new TextArea(null);
	 m_Text_Number3.setBounds(5,60,(m_Width-10)/10,(m_Height-100)-20);
	 m_Frame.add(m_Text_Number3);

	 m_Label_End_Symbol3=new Label("�ս��");
	 m_Label_End_Symbol3.setBounds(5+(m_Width-10)/10,60-15,36,15);
	 m_Frame.add(m_Label_End_Symbol3);
	 
	 m_Pane_End_Symbol3=new ScrollPane();
	 m_Pane_End_Symbol3.setBounds(5+(m_Width-10)/10,60,4*(m_Width-10)/10,(m_Height-100)-20);
	 m_Frame.add(m_Pane_End_Symbol3);
	 

	 m_Label_Not_End_Symbol3=new Label("���ս��");
	 m_Label_Not_End_Symbol3.setBounds(5+5*(m_Width-10)/10,60-15,36,15);
	 m_Frame.add(m_Label_Not_End_Symbol3);
	 
	 m_Pane_Not_End_Symbol3=new ScrollPane();
	 m_Pane_Not_End_Symbol3.setBounds(5+5*(m_Width-10)/10,60,5*(m_Width-10)/10,(m_Height-100)-20);
	 m_Frame.add(m_Pane_Not_End_Symbol3);

	 m_Label_Status3=new Label("״̬");
	 m_Label_Status3.setBounds(5+m_Width/8,m_Height-40,36,15);
	 m_Frame.add(m_Label_Status3);
	 
	 m_Field_Status3=new TextField();
	 m_Field_Status3.setBounds(5+m_Width/8+36,m_Height-40,36,15);
	 m_Frame.add(m_Field_Status3);

	 m_Label_Symbol3=new Label("����");
	 m_Label_Symbol3.setBounds(5+3*m_Width/8,m_Height-40,36,15);
	 m_Frame.add(m_Label_Symbol3);
	 
	 m_Field_Symbol3=new TextField();
	 m_Field_Symbol3.setBounds(5+3*m_Width/8+36,m_Height-40,3*m_Width/16,15);
	 m_Frame.add(m_Field_Symbol3);

	 m_Label_Action3=new Label("����");
	 m_Label_Action3.setBounds(5+3*m_Width/4,m_Height-40,36,15);
	 m_Frame.add(m_Label_Action3);
	 
	 m_Field_Action3=new TextField();
	 m_Field_Action3.setBounds(5+3*m_Width/4+36,m_Height-40,36,15);
	 m_Frame.add(m_Field_Action3);

	 m_Label_Formula3=new Label("���ò���ʽ");
	 m_Label_Formula3.setBounds(5+m_Width/4,m_Height-20,72,15);
	 m_Frame.add(m_Label_Formula3);
	 
	 m_Field_Formula3=new TextField();
	 m_Field_Formula3.setBounds(5+3*m_Width/8,m_Height-20,3*m_Width/8,15);
	 m_Frame.add(m_Field_Formula3);
 }
 public void setVisible(boolean flag)
 {
	 m_Text_Number3.setVisible(flag);
	 m_Pane_End_Symbol3.setVisible(flag);
	 m_Pane_Not_End_Symbol3.setVisible(flag);
	 
	 m_Label_Number3.setVisible(flag);
	 m_Label_End_Symbol3.setVisible(flag);
	 m_Label_Not_End_Symbol3.setVisible(flag);
	 
	 m_Label_Status3.setVisible(flag);
	 m_Field_Status3.setVisible(flag);
	 
	 m_Label_Symbol3.setVisible(flag);
	 m_Field_Symbol3.setVisible(flag);
	 
	 m_Label_Action3.setVisible(flag);
	 m_Field_Action3.setVisible(flag);
	 
	 m_Label_Formula3.setVisible(flag);
	 m_Field_Formula3.setVisible(flag);
 }
}
