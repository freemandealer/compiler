import java.awt.*;

public class First_Follow_Set
{
 AnalyzerFrame   m_Frame			= null;
 
 TextArea m_Text_Not_End_Symbol		=null;
 TextArea m_Text_First_Set			=null;
 TextArea m_Text_Follow_Set			=null;

 Label m_Label_Not_End_Symbol		=null;
 Label m_Label_First_Set			=null;
 Label m_Label_Follow_Set			=null;
 
 int m_Width;
 int m_Height;

 public First_Follow_Set(AnalyzerFrame frame,int width,int height)
 {
   m_Frame=frame;
   m_Width=width;
   m_Height=height;
   Create();
   setVisible(false);
 }
 public void Create()
 {
	 m_Label_Not_End_Symbol=new Label("���ս��");
	 m_Label_Not_End_Symbol.setBounds(5,60-15,48,15);
	 m_Frame.add(m_Label_Not_End_Symbol);
	 
	 m_Text_Not_End_Symbol=new TextArea(null);
	 m_Text_Not_End_Symbol.setBounds(5,60,(m_Width-10)/5,(m_Height-100)-20);
	 m_Frame.add(m_Text_Not_End_Symbol);
	 
	 m_Label_First_Set=new Label("First ��");
	 m_Label_First_Set.setBounds(5+(m_Width-10)/5,60-15,48,15);
	 m_Frame.add(m_Label_First_Set);
	 
	 m_Text_First_Set=new TextArea(null);
	 m_Text_First_Set.setBounds(5+(m_Width-10)/5,60,2*(m_Width-10)/5,(m_Height-100)-20);
	 m_Frame.add(m_Text_First_Set);

	 m_Label_Follow_Set=new Label("Follow ��");
	 m_Label_Follow_Set.setBounds(5+3*(m_Width-10)/5,60-15,60,15);
	 m_Frame.add(m_Label_Follow_Set);
	 
	 m_Text_Follow_Set=new TextArea(null);
	 m_Text_Follow_Set.setBounds(5+3*(m_Width-10)/5,60,2*(m_Width-10)/5,(m_Height-100)-20);
	 m_Frame.add(m_Text_Follow_Set);

	 
 }
 public void setVisible(boolean flag)
 {
	 m_Label_Not_End_Symbol.setVisible(flag);
	 m_Text_Not_End_Symbol.setVisible(flag);
	 m_Label_First_Set.setVisible(flag);
	 m_Text_First_Set.setVisible(flag);
	 m_Label_Follow_Set.setVisible(flag);
	 m_Text_Follow_Set.setVisible(flag);

	 
 }
}
