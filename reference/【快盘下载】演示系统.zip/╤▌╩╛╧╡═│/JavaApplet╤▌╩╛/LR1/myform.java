import java.applet.*;
import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.awt.Toolkit;

class myform_run
{
	String s;
	boolean run;
}
public class myform
{
	AnalyzerFrame m_Frame;
	FileDialog openDlg;
	
	rword zjfuhao[];//100
	int zjnum;
	rword fzjfuhao[];//200
	int fzjnum;
	cansenjh ccss;
	int startnum;
	String filename;
	String pathname;
	
	lr1stateset slr1state;
	boolean cansave;
	boolean ifrun;
	String fxs;
	int nowpoint;
	int usenum;
	boolean iftreesave;
	
	
	public myform(AnalyzerFrame frame)
	{
		m_Frame=frame;
		zjfuhao=new rword[101];
		fzjfuhao=new rword[201];
	}
	public void Button1Click()
	{
	}
	public void FormCreate()
	{
	}
	public void BitBtn1Click()
	{
	}
	public void BitBtn5Click()
	{
	}
	public void BitBtn6Click()
	{
	}
	public void addfzjfuhao(String s)
	{
	}
	public void adddisplay(String s)
	{
	}
	public void deletedisplay(int d)
	{
	}
	public void BitBtn2Click()
	{
	}
	public boolean findzjfuhao(int f)
	{
		boolean findzjfuhao;
		findzjfuhao=false;
		return findzjfuhao;
	}
	public void BitBtn4Click()
	{
	}
	public void BitBtn7Click()
	{
	}
	public void New1Click()
	{
	}
	public void deleteall()
	{
	}
	public void Save1Click()
	{
	}
	public void saveas()
	{
	}
	public boolean saveall(boolean w)
	{
		boolean saveall;
		saveall=false;
		return saveall;
	}
	public void Saveas1Click()
	{
	}
	public void Open1Click()
	{
		int i,j,k;
		boolean res;
		//Opendialog1.Filter:='WF files(*.WF)|*.WF';
		zjnum=0;
		fzjnum=0;
		deleteall();
 /* stringgrid1.cells[0,1]:='';
  stringgrid1.cells[1,1]:='';

  stringgrid2.cells[0,1]:='';
  stringgrid2.cells[1,1]:='';*/
		zjnum=0;
		
 		openDlg= new FileDialog(m_Frame);
		openDlg.show();
		filename = openDlg.getFile();
		pathname=openDlg.getDirectory();
		
        if (filename!=null) 
		{
			openDlg.dispose();
			m_Frame.setTitle("LR1�ķ�������������"+"-"+filename);
			res=openf();
		
			k=ccss.count;
			ccss.count=0;
			for (i=1;i<=k;i++)
			{
				//m_Frame.Dprod.edit1.text:=stringGrid2.cells[1,i];
				m_Frame.Dprod.anaysis();
				if (m_Frame.Dprod.addnum>0)
				{
					j=1;
					while(j<=m_Frame.Dprod.addnum)
					{
						addfzjfuhao(m_Frame.Dprod.addfuhao[j]);
						j=j+1;
					}
				}
				//ccss.add(m_Frame.Dprod.edit1.text);
			}
			if (! res)
			{
              //application.Messagebox("����ȷ���ļ�!", "����", mb_Ok);
			}
		}
		/*  stringgrid5.colcount:=zjnum;
		stringgrid5.rowcount:=slr1state.count+1;
		stringgrid6.rowcount:=fzjnum;
		stringgrid6.colcount:=slr1state.count+1;*/
		cansave=false;
	}
	public boolean openf()
	{
		boolean openf;
		String temp,temp1;
		boolean ifend;
        m_FileReader  reader = null;
		try
		{
			reader = new m_FileReader(pathname+filename);
		}
		catch(IOException e)
		{
			openf=false;
			m_Frame.application.messagebox("�ļ�������!","��ֹ",m_Frame.mb_ok);
			return openf;
		}
		try
		{
			reader.reset();
		}
		catch(IOException e)
		{
			m_Frame.application.messagebox("�ļ��򲻿�!","��ֹ",m_Frame.mb_ok);
			openf=false;
			return openf;
		}
		try
		{
			temp = reader.readLine();
		}
		catch(IOException e)
		{
			m_Frame.application.messagebox("�ļ���ʽ����!","��ֹ",m_Frame.mb_ok);
			try
			{
				reader.close();
			}
			catch(IOException e1)
			{
			}
			openf=false;
			return openf;
		}
		while((temp != null)&&(!temp.equals("[�ķ�]"))) 
		{
			if(!temp.equals("[�ķ�]"))
			{
				try
				{
					temp1=reader.readLine();
				}
				catch(IOException e)
				{
					m_Frame.application.messagebox("�ļ���ʽ����!","��ֹ",m_Frame.mb_ok);
					try
					{
						reader.close();
					}
					catch(IOException e1){}
					openf=false;
					return openf;				
				}
				try
				{
					Integer temp_Int=new Integer(temp);
					zjfuhao[zjnum+1].index=temp_Int.intValue();
				}
				catch(NumberFormatException e)
				{
					m_Frame.application.messagebox("�ļ���ʽ����!","��ֹ",m_Frame.mb_ok);
					try
					{
						reader.close();
					}
					catch(IOException e1){}
					openf=false;
					return openf;				
				}
				zjnum++;
				zjfuhao[zjnum].name=temp1;
//				stringgrid3.rowcount=zjnum+1;
//				stringgrid3.cells[0,zjnum]:=temp;
//				stringgrid3.cells[1,zjnum]:=temp1;
			}
			try
			{
				temp = reader.readLine();
			}
			catch(IOException e)
			{
				m_Frame.application.messagebox("�ļ���ʽ����!","��ֹ",m_Frame.mb_ok);
				try
				{
					reader.close();
				}
				catch(IOException e1){}
				openf=false;
				return openf;
			}			
		}
		try
		{
			temp = reader.readLine();
		}
		catch(IOException e)
		{
			m_Frame.application.messagebox("�ļ���ʽ����!","��ֹ",m_Frame.mb_ok);
			try
			{
				reader.close();
			}
			catch(IOException e1){}
			openf=false;
			return openf;
		}
		while(temp!=null)
		{
			ccss.count=ccss.count+1;
			//stringgrid2.rowcount=ccss.count+1;
			//stringgrid2.cells[0,ccss.count]=inttostr(ccss.count);
			//stringgrid2.cells[1.ccss.count]=temp;
			try
			{
				temp = reader.readLine();
			}
			catch(IOException e)
			{
				m_Frame.application.messagebox("�ļ���ʽ����!","��ֹ",m_Frame.mb_ok);
				try
				{
					reader.close();
				}
				catch(IOException e1){}
				openf=false;
				return openf;
			}
		}
		try
		{
			reader.close();
		}
		catch(IOException e)
		{
		}
		openf=true;
		return openf;
	}
	public void BitBtn3Click()
	{
	}
	public String fzjhave()
	{
		String fzjhave;
		fzjhave="";
		return fzjhave;
	}
	public void prepare()
	{
	}
	public void compute()
	{
	}
	public void setview()
	{
	}
	public void StringGrid5DrawCell()
	{
	}
	public void StringGrid5MouseMove()
	{
	}
	public void savefxas()
	{
	}
	public boolean savefxall(boolean w)
	{
		boolean savefxall;
		savefxall=false;
		
		return savefxall;
	}
	public void Save2Click()
	{
	}
	public void Saveas2Click()
	{
	}
	public boolean openfxf()
	{
		boolean openfxf;
		openfxf=false;
		return openfxf;
	}
	public void Open2Click()
	{
	}
	public int findindex(String name)
	{
		int findindex;
		int i;
		i=1;
		while((i<=fzjnum)&&(fzjfuhao[i].name!=name))
		{
			i++;
		}
		if(i<=fzjnum)
		{
			findindex=fzjfuhao[i].index;
			return findindex;
		}
		i=1;
		while((i<=zjnum)&&(zjfuhao[i].name!=name))
		{
			i++;
		}
		if(i<=zjnum)
		{
			findindex=zjfuhao[i].index;
		}
		else
		{
			findindex=-1;
		}
		return findindex;
	}
	public String findname(int index)
	{
		int i;
		String findname=null;
		i=1;
		while((i<=fzjnum)&&(fzjfuhao[i].index!=index))
		{
			i++;
		}
		if(i<=fzjnum)
		{
			findname=fzjfuhao[i].name;
			return findname;
		}
		i=1;
		while((i<=zjnum)&&(zjfuhao[i].index!=index))
		{
			i++;
		}
		if(i<=zjnum)
		{
			findname=zjfuhao[i].name;
		}
		return findname;
	}
	public void StringGrid6DrawCell()
	{
	}
	public void StringGrid6MouseMove()
	{
	}
	public void Exit1Click()
	{
	}
	public void RadioGroup1Click()
	{
	}
	public void MyStack1MouseMove()
	{
	}
	public void Open3Click()
	{
	}
	public void Save3Click()
	{
	}
	public void Save4Click()
	{
	}
	public void BitBtn8Click()
	{
	}
	public void BitBtn9Click()
	{
	}
	public void BiSwitch1On()
	{
	}
	public void BiSwitcht1Off()
	{
	}
	public void BitBtn10Click()
	{
	}
	public void steprun()
	{
	}
	public myform_run run(String s)
	{
		myform_run return_val;
		return_val=new myform_run();
		boolean run;
		run=false;
		
		return_val.s=s;
		return_val.run=run;
		return return_val;
	}
	public int getstate()
	{
		int getstate;
		getstate=-1;
		return getstate;
	}
	public void runprepare()
	{
	}
	public void addshift(int index)
	{
	}
	public void addreduce(item f)
	{
	}
	public void Timer1Timer()
	{
	}
	public void OutlineMouseMove()
	{
	}
	
}