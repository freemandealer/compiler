import java.awt.event.*;
import java.awt.*;
class lr1state_newstate
{
	boolean newstate;
	int m;
}
class state_newstate
{
	boolean newstate;
	int m;
}
class item_nextposition
{
	boolean nextposition;
	sword r;
	public void item_nextpositon()
	{
		r=new sword();
		nextposition=false;
	}

}

class rword
{
	int index;
	String name;
	boolean res;
	rword()
	{
	  name=new String();
	}
};
class sword
{
	int index;
	boolean res;
}
class action
{
	int nextfuhao;
	int act;
}
class treeitem
{
	int fnum;
	int unum;
}
class ptreeitem extends treeitem
{
}
class pointer
{
	int ptr;
}
class pointrec
{
	pointer p;
	pointrec link;
	public void init(pointer sp)
	{
		p=sp;
		link=null;
	}
	public pointer getpoint()
	{
		return p;
	}
	public void done()
	{
	}
	public boolean ifequal(pointer sp)
	{
		return (p==sp);
	}
}
class mfuhao
{
	int index;
	boolean res;
	mfuhao link;
	
	public void init(int nindex)
	{
		res=false;
		index=nindex;
		link=null;
	}
	public void setflag(boolean f)
	{
		res=f;
	}
	public void done()
	{
	}
}
class fensensi
{
	mfuhao wordlist=null;
	mfuhao now=null;
	fensensi link;
	myform form1;
	
	public void init(String cansi,myform my_form)
	{
		int i,j;
		String temp;
		form1=my_form;
		link=null;
		wordlist=null;
		i=0;
		temp="";
		while (i<cansi.length())
		{
			if (cansi.charAt(i)==' ')
			{
				if(temp!="")
				{
					if(wordlist==null)
					{
						j=form1.findindex(temp);
						if(j==-1)
						{
							now=null;
							return;
						}
						wordlist=new mfuhao();
						wordlist.init(j);
						now=wordlist;
					}
					else
					{
						j=form1.findindex(temp);
						if(j==-1)
						{
							now=null;
							return;
						}
						now.link=new mfuhao();
						now.link.init(j);
						now=now.link;
					}
					temp="";
				}
			}
			else
			{
				temp+=cansi.charAt(i);
			}
			i++;
		}
		if(temp!="")
		{
			if(wordlist==null)
			{
				j=form1.findindex(temp);
				if(j==-1)
				{
					now=null;
					return;
				}
				wordlist=new mfuhao();
				wordlist.init(j);
				now=wordlist;
			}
			else
			{
				j=form1.findindex(temp);
				if(j==-1)
				{
					now=null;
					return;
				}
				now.link=new mfuhao();
				now.link.init(j);
				now=now.link;
			}
		}
	
	}
	public void init2(int nindex,myform my_form)
	{
		form1=my_form;
		wordlist=new mfuhao();
		wordlist.init(nindex);
		now=wordlist;
		link=null;
	}
	public void init3(fensensi p,myform my_form)
	{
		form1=my_form;
		p.setsi();
		wordlist=new mfuhao();
		wordlist.init(p.get().index);
		now=wordlist;
		while (!p.next())
		{
			now.link=new mfuhao();
			now.link.init(p.get().index);
			now=now.link;
		}
	}
	public void done()
	{
		mfuhao temp;
		now=wordlist;
		while (now.link!=null)
		{
			temp=now.link;
			now.done();
			now=temp;
		}
	}
	public void setsi()
	{
		now=wordlist;
	}
	public sword get()
	{
		sword get;
		get=new sword();
		get.index=now.index;
		get.res=now.res;
		return get;
	}
	public boolean next()
	{
		boolean next;
		if(now.link==null)
		{
			next=true;
		}
		else
		{
			now=now.link;
			next=false;
		}
		return next;
	}
	public boolean pre()
	{
		boolean pre;
		mfuhao temp;
		temp=wordlist;
		if(temp==now)
		{
			pre=true;
		}
		else
		{
			while(temp.link!=now)
			{
				temp=temp.link;
			}
			now=temp;
			pre=false;
		}
		return pre;
	}
	public boolean ifeof()
	{
		boolean ifeof;
		if (now.link==null)
		{
			ifeof=true;
		}
		else
		{
			ifeof=false;			
		}
		return ifeof;
	}
	public void setflag(boolean f)
	{
		now.setflag(f);
	}
	public boolean add(int index)
	{
		boolean add;
		if (wordlist.link==null)
		{
			wordlist.link=new mfuhao();
			wordlist.init(index);
			now=wordlist;
			add=true;
		}
		else
		{
			now=wordlist.link;
			while((now.link!=null)&&(now.index!=index))
			{
				now=now.link;
			}
			if (now.index!=index)
			{
				while(now.link!=null)
				{
					now=now.link;
				}
				now.link=new mfuhao();
				now.link.init(index);
				add=true;
			}
			else
			{
				add=false;
			}
			
		}
		return add;
	}
	public boolean ifhave(int index)
	{
		boolean  ifhave;
		if((wordlist==null)||(wordlist.link==null))
		{
			ifhave=false;
			return ifhave;
		}
		now=wordlist.link;
		while((now.link!=null)&&(now.index!=index))
		{
			now=now.link;
		}
		ifhave=(now.index==index);
		return ifhave;
	}
	public void clear()
	{
		mfuhao temp;
		now=wordlist;
		while(now.link!=null)
		{
			temp=now;
			now=now.link;
			temp.done();
		}
		now.done();
		wordlist=null;
		now=null;
	}
	public void emtry()
	{
		mfuhao temp;
		now=wordlist.link;
		if(now!=null)
		{
			while(now.link!=null)
			{
				temp=now.link;
				now.done();
				now=temp;
			}
			now.done();			
		}
		now=wordlist;
		now.link=null;
	}
	public String getcanssi()
	{
		String getcanssi;
		String temp;
		String temp1;
		temp="";
		now=wordlist;
		while(now.link!=null)
		{
			temp1=form1.findname(now.index);
			temp=temp+" "+temp1;
			now=now.link;			
		}
		temp1=form1.findname(now.index);
		temp=temp+' '+temp1;
		getcanssi=temp;
		return getcanssi;
	}
	public boolean isequal(fensensi p)
	{
		boolean isequal;
		p.setsi();
		setsi();
		while((get().index==p.get().index)&&(!(p.ifeof()))&&(ifeof()))
		{
			next();
			p.next();
		}
		if((get().index==p.get().index)&&(p.ifeof())&&(ifeof()))
		{
			isequal=true;
		}
		else
		{
			isequal=false;
		}
		return isequal;
	}
	public boolean isequal2(fensensi p)
	{
		boolean isequal2;
		if(p.getcount()!=getcount())
		{
			isequal2=false;
			return isequal2;
		}
		p.setsi();
		while(!p.next())
		{
			if(!ifhave(p.now.index))
			{
				isequal2=false;
				return isequal2;
			}
		}
		isequal2=true;
		return isequal2;
	}
	public int getcount()
	{
		int getcount;
		int i;
		setsi();
		i=0;
		while(!next())
		{
			i=i+1;
		}
		getcount=i;
		return getcount;
	}
	public boolean setposition(int p)
	{
		boolean setposition;
		int i;
		setsi();
		i=1;
		while((i<p)&&(!(ifeof())))
		{
			next();
			i=i+1;
		}
		if(i==p)
		{
			setposition=true;
		}
		else
		{
			setposition=false;
		}
		return setposition;
		
	}
	public boolean sub(int index)
	{
		boolean sub;
		mfuhao temp;
		now=wordlist;
		temp=now;
		now=now.link;
		while((now!=null)&&(now.index!=index))
		{
			temp=now;
			now=now.link;
		}
		sub=(now!=null);
		if(now!=null)
		{
			temp.link=now.link;
			now.done();
			now=wordlist;
		}
		return sub;
	}
}
class cansensi
{
	myform form1;
	mfuhao parent;
	fensensi first,fellow;
	fensensi synch;
    fensensi entercan;
	fensensi enternow;
	fensensi scansisi;
	fensensi now;
	int count;
	public void init(String cansi,myform my_form)
	{
		String temp;
		int i;
		char oldch;
		int j;
		form1=my_form;
		scansisi=null;
		now=null;
		oldch='c';
		i=0;
		count=0;
		temp="";
		while((cansi.charAt(i)!='=')&&(i<cansi.length()))
		{
			if(cansi.charAt(i)!=' ')
			{
				temp=temp+cansi.charAt(i);
			}
			i++;
		}
		i++;
		j=form1.findindex(temp);
		parent=new mfuhao();
		parent.init(j);
		first=new fensensi();
		first.init2(j,form1);
		fellow=new fensensi();
		fellow.init2(j,form1);
		synch=new fensensi();
		synch.init2(j,form1);
		temp="";
		while(i<cansi.length())
		{
			switch(cansi.charAt(i))
			{
				case '\\' :
					{
						if(oldch=='\\')
						{
							temp=temp+'\\';
							oldch='a';
						}
						else
						{
							oldch='\\';
						}
						break;
					}
				case '|':
					{
						if(oldch=='\\')
					    {
							temp+='|';
							oldch='|';
						}
						else
						{
							if(temp!="")
							{
								if(scansisi==null)
								{
									scansisi=new fensensi();
									scansisi.init(temp,form1);
									now=scansisi;
									entercan=new fensensi();
									entercan.init2(parent.index,form1);
									enternow=entercan;
									count=1;
								}
								else
								{
									now.link=new fensensi();
									now.link.init(temp,form1);
									now=now.link;
									enternow.link=new fensensi();
									enternow.link.init2(parent.index,form1);
									enternow=enternow.link;
									count++;
								}
								temp="";
							}
						}
						break;
					}
				default:
					{
						temp+=cansi.charAt(i);
						break;
					}
			}
		}
	}
	public void done()
	{
		fensensi temp;
		now=scansisi;
		enternow=entercan;
		if(first!=null)
		{
			first.done();
		}
		if(fellow!=null)
		{
			fellow.done();
		}
		if(parent!=null)
		{
			parent.done();
		}
		if(synch!=null)
		{
			synch.done();
		}
		if(now!=null)
		{
			while(now.link!=null)
			{
				temp=now.link;
				now.done();
				now=temp;
				temp=enternow.link;
				enternow.done();
				enternow=temp;
			}
			now.done();
			enternow.done();
		}
	}
	public void setsi(int index)
	{
		int i;
		now=scansisi;
		enternow=entercan;
		i=index;
		while(i>1)
		{
			now=now.link;
			if(enternow!=null)
			{
				enternow=enternow.link;
				i=i-1;
			}
			now.setsi();
			if(enternow!=null)
			{
				enternow.setsi();
			}
		}
	}
	public sword get()
	{
		sword get;
		get=new sword();
		get.index=now.get().index;
		get.res=now.get().res;
		return get;
	}
	public boolean next()
	{
		boolean next;
		if(now.link!=null)
		{
			now=now.link;
			now.setsi();
			if(enternow!=null)
			{
				enternow=enternow.link;
				enternow.setsi();
			}
			next=false;
		}
		else
		{
			next=true;
		}
		return next;
		
	}
	public boolean sunnext()
	{
		boolean sunnext;
		sunnext=now.next();
		enternow.next();
		return sunnext;
	}
	public boolean sunpre()
	{
		boolean sunpre;
		sunpre=now.pre();
		enternow.pre();
		return sunpre;
	}
	public boolean sunifeof()
	{
		boolean sunifeof;
		sunifeof=now.ifeof();
		return sunifeof;
	}
	public void  addfirst(int index)
	{
		if(first.add(index))
		{
			parent.res=true;
		}
	}
	public void addfellow(int index)
	{
		if(fellow.add(index))
		{
			parent.res=true;
		}
	}
	public void setflag(boolean f)
	{
		now.setflag(f);
	}
	public void sunsetsi()
	{
		now.setsi();
		enternow.setsi();
	}
	public void refreshff()
	{
		first.emtry();
		fellow.emtry();
		synch.emtry();
		setsi(1);
		if(enternow!=null)
		{
			while(enternow.link!=null)
			{
				enternow.emtry();
				enternow=enternow.link;
			}
			enternow.emtry();
			enternow=entercan;
		}
	}
	public String getcanssi()
	{
		String getcanssi;
		String temp;
		String temp1;
		temp="";
		temp=now.getcanssi();
		temp1=form1.findname(parent.index);
		temp=temp1+'='+temp;
		getcanssi=temp;
		return getcanssi;
	
	}
	public boolean ifeof()
	{
		boolean ifeof;
		if (now.link==null)
		{
			ifeof=true;
		}
		else
		{
			ifeof=false;
		}
		return ifeof;
	}
}
class cansenjh
{
	myform form1;
	cansensi cans[];
	int count;
	public void init(myform my_form)
	{
		int i;
		form1=new myform(null);
		form1=my_form;
		cans=new cansensi[501];
		
		for(i=0;i<=500;i++)
		{
			cans[i]=null;
		}
		count=0;
	}
	public void add(String s)
	{
		count=count+1;
		cans[count]=new cansensi();
		cans[count].init(s,form1);
		
	}
	public void delete(int d)
	{
		int i;
		if(d<count)
		{
			cans[d].done();
			for (i=d;i<=count-1;i++)
			{
				cans[i]=cans[i+1];
			}
			count=count-1;
		}
		else
		{
			if(d==count)
			{
				cans[d].done();
				count=count-1;
			}
		}
	}
	public void exchange(int h,String s)
	{
		cans[h].done();
		cans[h]=new cansensi();
		cans[h].init(s,form1);
	}
	public void done()
	{
		int i;
		for(i=1;i<=count;i++)
		{
			cans[i].done();
		}
	}
	public boolean ifhave(int index)
	{
		boolean ifhave;
		int i;
		i=1;
		while((i<=count)&&(index!=cans[i].parent.index))
		{
			i=i+1;
		}
		if(i>count)
		{
			ifhave=false;
		}
		else
		{
			ifhave=true;
		}
		return ifhave;
	}
	public int gofuhao(int index)
	{
		int gofuhao;
		int i;
		i=1;
		while((i<=count)&&(index!=cans[i].parent.index))
		{
			i=i+1;
		}
		if(i>count)
		{
			gofuhao=-1;
		}
		else
		{
			gofuhao=i;
		}
		return gofuhao;
	}
	public int find(int p,fensensi f)
	{
		int find;
		int i,j,k;
		j=0;
		for (i=1;i<=count;i++)
		{
			cans[i].setsi(1);
			k=cans[i].parent.index;
			do
			{
				j=j+1;
				if((cans[i].now.isequal(f))&&(k==p))
			   {
					find=j;
					return find;
				}
			}while (!cans[i].next());
		}
		find=-1;
		return find;
	}
	public String getstring(int index)
	{
		String getstring;
		int i,j;
		String temp;
		j=0;
		for(i=1;i<=count;i++)
		{
			cans[i].setsi(1);
			do
			{
				j++;
				if(j==index)
				{
					temp=form1.findname(cans[i].parent.index);
					getstring=temp+'='+cans[i].now.getcanssi();
					return getstring;
				}
			}while(!cans[i].next());
		}
		getstring="";
		return getstring;
	}
}
class item extends fensensi
{
	myform form1;
	mfuhao parent;
	action act;
	int position;
	public void init(fensensi p,mfuhao par,myform my_form)
	{
		form1=my_form;
		p.setsi();
		super.init3(p,form1);
		parent=new mfuhao();
		parent.init(par.index);
		position=0;
		link=null;
		act.nextfuhao=-1;
		act.act=-1;
	}
	public void init2(item p,int o,myform my_form)
	{
		form1=my_form;
		p.setsi();
		super.init3(p,form1);
		parent=new mfuhao();
		parent.init(p.parent.index);
		position=o;
		link=null;
		act.nextfuhao=p.getaction().nextfuhao;
		act.act=p.getaction().act;
	}
	public void init3(String s,myform my_form)
	{
		int i;
		String temp;
		int p;
		form1=my_form;
		wordlist=null;
		now=null;
		i=0;
		temp="";
		while((i<s.length())&&(s.charAt(i)!=' '))
		{
			temp+=s.charAt(i);
			i++;
		}
		try
		{
			Integer temp_Int=new Integer(temp);
			p=temp_Int.intValue();
		}
		catch(NumberFormatException e)
		{
			act.act=-3;
			return;
		}
		position=p;
		temp="";
		i++;
		while((i<s.length())&&(s.charAt(i)!=' '))
		{
			temp=temp+s.charAt(i);
			i++;
		}
		if(temp=="")
		{
			act.act=-3;
			return;
		}
		if (temp=="@@@@@@@@@@")
		{
			act.nextfuhao=-1;
		}
		else
		{
			p=form1.findindex(temp);
			if(p==-1)
			{
				act.act=-3;
				return;
			}
			act.nextfuhao=p;
		}
		temp="";
		i=i+1;
		while((i<s.length())&&(s.charAt(i)!=' '))
		{
			temp=temp+s.charAt(i);
			i++;
		}
		if(temp=="")
		{
			act.act=-3;
			return;
		}
		try
		{
			Integer temp_Int=new Integer(temp);
			p=temp_Int.intValue();
		}
		catch(NumberFormatException e)
		{
			act.act=-3;
			return;
		}
		act.act=p;
		temp="";
		i++;
		while(i<s.length()&&(s.charAt(i)!=' '))
		{
			temp+=s.charAt(i);
			i++;
		}
		if(temp=="")
		{
			act.act=-3;
			return;
		}
		p=form1.findindex(temp);
		if(p==-1)
		{
			act.act=-3;
			return;
		}
		parent=new mfuhao();
		parent.init(p);
		temp="";
		i++;
		while(i<s.length())
		{
			temp=temp+s.charAt(i);
			i++;
		}
		if(temp=="")
		{
			act.act=-3;
			return;
		}
		super.init(temp,form1);
		if(now==null)
		{
			act.act=-3;
			return;
		}
	}
	public void done()
	{
		parent.done();
	}
	public boolean isequal(item p)
	{
		int i;
		boolean isequal;
		if((parent.index==p.getparent().index)&&(position==p.position)&&(((fensensi)this).isequal(p)))
		{
			isequal=true;
		}
		else
		{
			isequal=false;
		}
		return isequal;
	}
	public item_nextposition nextposition(sword r)
	{
		item_nextposition return_val=new item_nextposition();
		boolean nextposition;
		setsi();
		if(get().index==300)
		{
			nextposition=false;
			return_val.nextposition=nextposition;
			return_val.r=r;
			return return_val;
		}
		if (position==0)
		{
			setsi();
			r=get();
			nextposition=true;
		}
		else
		{
			setposition(position);
			if(ifeof())
			{
				nextposition=false;
			}
			else
			{
				now=now.link;
				nextposition=true;
				r=get();
			}
		}
		return_val.nextposition=nextposition;
		return_val.r=r;
		return return_val;
	}
	public boolean gonext()
	{
		boolean gonext;
		setsi();
		if(get().index==300)
		{
			gonext=false;
			return gonext;
		}
		if(position==0)
		{
			position=1;
			gonext=true;
		}
		else
		{
			if(!ispositioneof())
			{
				position=position+1;
				gonext=true;
			}
			else
			{
				gonext=false;
			}
		}
		return gonext;
	}
	public boolean isnext(int index)
	{
		boolean isnext;
		setsi();
		if(get().index==300)
		{
			isnext=false;
			return isnext;
		}
		if(position==0)
		{
			setsi();
			isnext=(get().index==index);
		}
		else
		{
			setposition(position);
			if(ifeof())
			{
				isnext=false;
			}
			else
			{
				now=now.link;
				isnext=(get().index==index);
			}
		}
		return isnext;
	}
	public boolean ispositioneof()
	{
		boolean ispositioneof;
		setsi();
		if(get().index==300)
		{
			ispositioneof=true;
			return ispositioneof;
		}
		if(position==0)
		{
			ispositioneof=false;
		}
		else
		{
			setposition(position);
			ispositioneof=ifeof();
		}
		return ispositioneof;
	}
	public int getposition()
	{
		int getposition;
		getposition=position;
		return getposition;
	}
	public sword getparent()
	{
		sword getparent=new sword();
		getparent.index=parent.index;
		return getparent;
	}
	public action getaction()
	{
		action getaction=new action();
		getaction=act;
		return getaction;
	}
	public void setaction(action a)
	{
		act=a;
	}
	public String getstring()
	{
		String getstring=new String();
		int i,j;
		String temp;
		now=wordlist;
		i=0;
		temp="";
		temp=form1.findname(parent.index)+'=';
		if(i==position)
		{
			temp=temp+'^';
		}
		do
		{
			i++;
			temp=temp+"  "+form1.findname(now.index);
			if(i==position)
			{
				temp=temp+'^';
			}
		}while(!next());
		getstring=temp;
		return getstring;
	}
}
class state extends cansensi
{
	int count;
	cansenjh ccss;
	state link;
	item scansisi;
	//item now;
	public void init(cansenjh cs,myform my_form)
	{
		form1=my_form;
		count=0;
		scansisi=null;
		now=null;
		link=null;
		ccss=cs;
	}
	public void add(fensensi p,mfuhao par)
	{
		item temp;
		if (scansisi==null)
		{
			scansisi=new item();
			scansisi.init(p,par,form1);
			now=scansisi;
			count=1;
		}
		else
		{
			temp=new item();
			temp.init(p,par,form1);
			setsi(1);
			do
			{
			}while(!((((item)now).isequal(temp))||(next())));
			if(!(((item)now).isequal(temp)))
			{
				setsi(count);
				now.link=temp;
				count++;
			}
			else
			{
				temp.done();
			}
		}
	}
	public void add2(item p,int o)
	{
		item temp;
		if(scansisi==null)
		{
			scansisi=new item();
			scansisi.init2(p,o,form1);
			now=scansisi;
			count=1;
		}
		else
		{
			setsi(1);
			temp=new item();
			temp.init2(p,o,form1);
			do
			{
			}while(!(((item)now).isequal(temp)||next()));
			if(!(((item)now).isequal(temp)))
			{
				setsi(count);
				now.link=temp;
				count++;
			}
			else
			{
				temp.done();
			}
		}
	}
	public boolean ifequal(state p)
	{
		boolean ifequal;
		boolean resb;
		if(count!=p.count)
		{
			ifequal=false;
		}
		else
		{
			p.setsi(1);
			resb=false;
			do
			{
				resb=ifhave(((item)p.now));
			}while((resb)||(p.next()));
			ifequal=resb;
		}
		return ifequal;
	}
	public boolean ifhave(item p)
	{
		boolean ifhave;
		boolean resb;
		setsi(1);
		resb=false;
		do
		{
			resb=(((item)now).isequal(p));
		}while(!(!(resb)||next()));
		ifhave=resb;
		return ifhave;
	}
	public void done()
	{
		item temp;
		if(scansisi!=null)
		{
			now=scansisi;
			temp=(item)now;
			while(now.link!=null)
			{
				now=now.link;
				temp.done();
				temp=(item)now;
			}
			((item)now).done();
		}
		scansisi=null;
		now=null;
		count=0;
	}
	public void spread()
	{
		int i,j;
		item temp;
		sword r;
		r=new sword();
		i=1;
		temp=(item)scansisi;
		while(i<=count)
		{
			item_nextposition return_val;
			return_val=new item_nextposition();
			return_val=temp.nextposition(r);
			r=return_val.r;
			if(return_val.nextposition)
			{
				if (r.index>300)
				{
					j=1;
					while(ccss.cans[j].parent.index!=r.index)
					{
						j=j+1;
					}
					ccss.cans[j].setsi(1);
					do
					{
						add(ccss.cans[j].now,ccss.cans[j].parent);
					}while(!(ccss.cans[j].next()));
				}
			}
			temp=(item)(temp.link);
			i++;
		}
	}
	public state_newstate newstate(state p,int m)
	{
		state_newstate return_val;
		boolean newstate;
		sword s;
		s=new sword();
		return_val=new state_newstate();
		now=scansisi;
		while((((item)now).getaction().nextfuhao!=-1)||(((item)now).ispositioneof())&&(now.link!=null))
		{
			now=now.link;
		}
		if((((item)now).getaction().nextfuhao==-1)&&(!((item)now).ispositioneof()))
		{
			((item)now).nextposition(s);
			m=s.index;
			p.add2(((item)now),((item)now).position+1);
			while(now.link!=null)
			{
				now=now.link;
				if(((item)now).isnext(s.index))
				{
					p.add2(((item)now),((item)now).position+1);
				}
			}
			newstate=true;
		}
		else
		{
			newstate=false;
		}
		return_val.m=m;
		return_val.newstate=newstate;
		return return_val;
	}
	public void fill(int m,int o)
	{
		action a;
		now=scansisi;
		a=new action();
		a.nextfuhao=m;
		a.act=o;
		while(now!=null)
		{
			if(((item)now).isnext(m))
			{
				((item)now).setaction(a);
			}
			now=now.link;
		}
	}
}
class stateset
{
	myform form1;
	state states;
	state nowstate;
	int count;
	cansenjh ccss;
	
	public void init(cansenjh cs,myform my_form)
	{
		form1=my_form;
		states=null;
		nowstate=null;
		count=0;
		ccss=cs;
	}
	public void done()
	{
		state temp;
		int i;
		nowstate=states;
		for(i=1;i<=count;i++)
		{
			temp=nowstate;
			nowstate=nowstate.link;
			temp.done();
		}
	}
	public void add(state p)
	{
		if(count==0)
		{
			states=new state();
			states.init(ccss,form1);
			nowstate=states;
		}
		else
		{
			setsi(count);
			nowstate.link=new state();
			nowstate.link.init(ccss,form1);
			nowstate=nowstate.link;
		}
		p.setsi(1);
		do
		{
			nowstate.add2(((item)(p.now)),((item)(p.now)).position);
		}while(!(p.next()));
		count++;
	}
	public int ifhave(state p)
	{
		int ifhave;
		boolean resb;
		int i;
		nowstate=states;
		resb=false;
		i=0;
		do
		{
			i++;
			resb=nowstate.ifequal(p);
		}while(!((resb)||next()));
		if (resb)
		{
			ifhave=i;
		}
		else
		{
			ifhave=-1;
		}
		return ifhave;
	}
	public void clear()
	{
		state temp;
		int i;
		nowstate=states;
		for(i=1;i<=count;i++)
		{
			temp=nowstate;
			nowstate=nowstate.link;
			temp.done();
		}
		count=0;
		states=null;
		nowstate=null;
	}
	public void setsi(int index)
	{
		int i;
		nowstate=states;
		for(i=2;i<=index;i++)
		{
			nowstate=nowstate.link;
		}
		nowstate.setsi(1);
	}
	public boolean next()
	{
		boolean next;
		if(nowstate.link==null)
		{
			next=true;
		}
		else
		{
			next=false;
			nowstate=nowstate.link;
		}
		return next;
	}
}
class lr1item extends item
{
	myform form1;
	cansenjh ccss;
	fensensi back;
	
	public void init(fensensi p,mfuhao par,fensensi bac,cansenjh cs,myform my_form)
	{
		form1=my_form;
		super.init(p,par,form1);
		ccss=new cansenjh();
		ccss=cs;
		back=new fensensi();
		back.init3(bac,form1);
	}
	public void init2(lr1item p,int o,cansenjh cs,myform my_form)
	{
		form1=my_form;
		super.init2(p,o,form1);
		back=new fensensi();
		back.init3(p.getback(),form1);
		ccss=new cansenjh();
		ccss=cs;
	}
	public void init3(String s,cansenjh cs,myform my_form)
	{
		int i,m;
		String temp;
		form1=my_form;
		ccss=new cansenjh();
		ccss=cs;
		back=null;
		i=0;
		temp="";
		back=new fensensi();
		back.init2(0,form1);
		while(i<s.length())
		{
			temp+=s.charAt(i);
			i++;
		}
		super.init3(temp,form1);
	}
	public void done()
	{
		if(back!=null)
		{
			back.done();
		}
		super.done();
	}
	public boolean addback(int index)
	{
		boolean addback;
		addback=back.add(index);
		return addback;
	}
	public boolean isequal(lr1item p)
	{
		boolean isequal;
		isequal=(back.isequal2(p.back)&&(super.isequal(p)));
		return isequal;
	}
	public String getstring()
	{
		String getstring;
		String temp;
		temp=super.getstring();
		temp=temp+"  , ";
		back.setsi();
		while(!(back.next()))
		{
			temp=temp+form1.findname(back.now.index)+'/';
		}
		getstring=temp;
		return getstring;
	}
	public fensensi getback()
	{
		fensensi getback;
		getback=new fensensi();
		getback=back;
		return getback;
	}
	public fensensi getpfirst(fensensi f)//??????????????????????????????????
	{
		fensensi getpfirst;
		boolean res;
		int i,j;
		now=wordlist;
		i=1;
		while((i<=position)&&(now.link!=null))
		{
			now=now.link;
			i++;
		}
		res=true;
		while((now.link!=null)&&(res))
		{
			now=now.link;
			if(now.index>300)
			{
				j=ccss.gofuhao(now.index);
				ccss.cans[i].first.setsi();
				while(!(ccss.cans[j].first.next()))
				{
					f.add(ccss.cans[j].first.now.index);
				}
				if(!(ccss.cans[j].first.ifhave(300)))
				{
					res=false;
				}
			}
			else
			{
				f.add(now.index);
				res=false;
			}
		}
		if (res)
		{
			back.setsi();
			while(!back.next())
			{
				f.add(back.now.index);
			}
		}
		getpfirst=new fensensi();
		getpfirst=f;
		return getpfirst;
	}
	public void backinit(String s)
	{
		int i;
		String temp;
		i=0;
		temp="";
		while(i<s.length())
		{
			if((s.charAt(i)==' ')&&(temp!=""))
			{
				back.add(form1.findindex(temp));
				temp="";
			}
			else
			{
				temp+=s.charAt(i);
			}
			i++;
		}
		if(temp!="")
		{
			back.add(form1.findindex(temp));
		}
	}
	public void emtryback()
	{
		back.emtry();
	}
	public boolean subback(int index)
	{
		boolean subback;
		subback=back.sub(index);
		return subback;
	}
}
class lr1state extends state
{
	public void init(cansenjh cs,myform my_form)
	{
		form1=my_form;
		super.init(cs,form1);
	}
	public void add(fensensi p,mfuhao par,fensensi bac)
	{
		lr1item temp;
		if(scansisi==null)
		{
			scansisi=new lr1item();
			((lr1item)scansisi).init(p,par,bac,ccss,form1);
			now=scansisi;
			count=1;
		}
		else
		{
			temp=new lr1item();
			temp.init(p,par,bac,ccss,form1);
			super.setsi(1);
			do
			{
			}while(!(((item)now).isequal(temp)||next()));
			if((!((item)now).isequal(temp)))
			{
				setsi(count);
				now.link=temp;
				count++;
			}
			else
			{
				temp.back.setsi();
				while(!(temp.back.next()))
				{
					((lr1item)now).addback(temp.back.get().index);
				}
				temp.done();
			}
		}
	}
	public void add2(lr1item p,int o)
	{
		lr1item temp;
		if(scansisi==null)
		{
			scansisi=new lr1item();
			((lr1item)scansisi).init2(p,o,ccss,form1);
			now=scansisi;
			count=1;
		}
		else
		{
			setsi(1);
			temp=new lr1item();
			temp.init2(p,o,ccss,form1);
			do
			{
			}while(!(((item)now).isequal(temp))||(next()));
			if(!((item)now).isequal(temp))
			{
				setsi(count);
				now.link=temp;
				count++;
			}
			else
			{
				temp.back.setsi();
				while(!(temp.back.next()))
				{
					((lr1item)now).addback(temp.back.get().index);
				}
				temp.done();
			}
		}
	}
	public boolean ifequal(lr1state p)
	{
		boolean ifequal;
		boolean resb;
		if(count!=p.count)
		{
			ifequal=false;
		}
		else
		{
			p.setsi(1);
			resb=false;
			do
			{
			}while(!((!resb)||(p.next())));
			ifequal=resb;
		}
		return ifequal;
	}
	public boolean ifhave(lr1item p)
	{
		boolean ifhave;
		boolean resb;
		setsi(1);
		resb=false;
		do
		{
			resb=((lr1item)now).isequal(p);
		}while ((resb)||(next()));
		ifhave=resb;
		return ifhave;
	}
	public void done()
	{
		lr1item temp;
		if(scansisi!=null)
		{
			now=scansisi;
			temp=((lr1item)now);
			while(now.link!=null)
			{
				now=now.link;
				temp.done();
				temp=((lr1item)now);
			}
			((lr1item)now).done();
		}
		scansisi=null;
		now=null;
		count=0;
		super.done();
	}
	public void spread()
	{
		int i,j;
		lr1item temp;
		sword r;
		r=new sword();
		fensensi f;
		i=0;
		temp=((lr1item)scansisi);
		f=new fensensi();
		f.init2(0,form1);
		while(i<count)
		{
			item_nextposition return_val;
			return_val=new item_nextposition();
			return_val=temp.nextposition(r);
			r=return_val.r;
			if(return_val.nextposition)
			{
				if(r.index>300)
				{
					f.emtry();
					f=temp.getpfirst(f);
					j=1;
					while(ccss.cans[j].parent.index!=r.index)
					{
						j++;
					}
					ccss.cans[j].setsi(1);
					do
					{
						add(ccss.cans[j].now,ccss.cans[j].parent,f);
					}while(!(ccss.cans[j].next()));
				}
			}
			temp=((lr1item)temp.link);
			i++;
		}
	}
	public lr1state_newstate newstate(lr1state p,int m)
	{
		boolean newstate;
		lr1state_newstate return_val;
		return_val=new lr1state_newstate();
		sword s;
		s=new sword();
		now=scansisi;
		while((((lr1item)now).getaction().nextfuhao!=-1)||(((lr1item)now).ispositioneof())&&(now.link!=null))
		{
			now=now.link;
		}
		if((((lr1item)now).getaction().nextfuhao==-1)&&(!((lr1item)now).ispositioneof()))
		{
			((lr1item)now).nextposition(s);
			m=s.index;
			p.add2(((lr1item)now),((lr1item)now).position+1);
			while(now.link!=null)
			{
				now=now.link;
				if(((lr1item)now).isnext(s.index))
				{
					p.add2(((lr1item)now),((lr1item)now).position+1);
				}
			}
			newstate=true;
		}
		else
		{
			newstate=false;
		}
		
		return_val.m=m;
		return_val.newstate=newstate;
		return return_val;
	}
}
class lr1stateset
{
	myform form1;
	lr1state states;
	lr1state nowstate;
	int count;
	cansenjh ccss;
	
	public void init(cansenjh cs,myform my_form)
	{
		states=null;
		nowstate=null;
		count=0;
		ccss=cs;
		form1=my_form;
	}
	public void done()
	{
		state temp;
		int i;
		nowstate=states;
		for(i=1;i<=count;i++)
		{
			temp=nowstate;
			nowstate=((lr1state)(nowstate.link));
			temp.done();
		}
	}
	public void add(lr1state p)
	{
		if(count==0)
		{
			states=new lr1state();
			states.init(ccss,form1);
			nowstate=states;
		}
		else
		{
			setsi(count);
			nowstate.link=new lr1state();
			nowstate.init(ccss,form1);
			nowstate=((lr1state)(nowstate.link));
		}
		p.setsi(1);
		do
		{
			nowstate.add2(((lr1item)(p.now)),((lr1item)(p.now)).position);
		}while(!(p.next()));
		count++;
	}
	public int ifhave(lr1state p)
	{
		int ifhave;
		boolean resb;
		int i;
		nowstate=states;
		resb=false;
		i=0;
		do
		{
			i++;
			resb=nowstate.ifequal(p);
		}while(resb||next());
		if (resb)
		{
			ifhave=i;
		}
		else
		{
			ifhave=-1;
		}
		return ifhave;
	}
	public void clear()
	{
		lr1state temp;
		int i;
		nowstate=states;
		for(i=1;i<=count;i++)
		{
			temp=nowstate;
			nowstate=((lr1state)(nowstate.link));
			temp.done();
		}
		count=0;
		states=null;
		nowstate=null;
	}
	public void setsi(int index)
	{
		int i;
		nowstate=states;
		for(i=2;i<=index;i++)
		{
			nowstate=((lr1state)(nowstate.link));
		}
		nowstate.setsi(1);
	}
	public boolean next()
	{
		boolean next;
		if(nowstate.link==null)
		{
			next=true;
		}
		else
		{
			next=false;
			nowstate=((lr1state)(nowstate.link));
		}
		return next;
	}
}
class pointset
{
	pointrec points;
	pointrec now;
	public void init()
	{
		points=null;
		now=null;
	}
	public void done()
	{
		pointrec temp;
		now=points;
		while(now!=null)
		{
			temp=now.link;
			now.done();
			now=temp;
		}
	}
	public void add(pointer p)
	{
		pointrec temp;
		temp=new pointrec();
		temp.init(p);
		if(points==null)
		{
			points=temp;
		}
		else
		{
			now=points;
			while(now.link!=null)
			{
				now=now.link;
			}
			now.link=temp;
		}
	}
	public boolean ifhave(pointer p)
	{
		boolean ifhave;
		now=points;
		while((!(now.ifequal(p)))&&(now.link!=null))
		{
			next();
		}
		ifhave=now.ifequal(p);
		return ifhave;
	}
	public boolean next()
	{
		boolean next;
		if(now==null)
		{
			next=true;
			return next;
		}
		next=(now.link==null);
		if(now.link!=null)
		{
			now=now.link;
		}
		return next;
	}
	public void setsi()
	{
		now=points;
	}
	public pointer getpoint()
	{
		pointer getpoint;
		getpoint=now.getpoint();
		return getpoint;
	}
	public boolean ifemtry()
	{
		boolean ifemtry;
		ifemtry=(points==null);
		return ifemtry;
	}
}
class lalritem extends lr1item
{
}
class lalrstate extends lr1state
{
}
class lalrstateset
{
}

public class struct
{
}