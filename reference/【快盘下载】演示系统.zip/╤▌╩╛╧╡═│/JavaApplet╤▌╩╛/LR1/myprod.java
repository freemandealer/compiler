import java.awt.*;
import java.awt.event.*;
public class myprod extends Dialog implements KeyListener,ActionListener 
{
	AnalyzerFrame m_Frame;
	int state;
	String leftstring;
	int pressnum;
	int addnum;
	String addfuhao[];
	int mode;
	
	TextField Edit1;
	Button OKBtn;
	Button CancelBtn;
	Button HelpBtn;

	myprod(AnalyzerFrame frame)
	{
		super(frame,"����ʽ",true);
		m_Frame=frame;
		create();
		addfuhao=new String[20];
	}
	public void create()
	{
		setLayout(null);
		setBounds(100,100,300,100);
		
		Edit1=new TextField(null);
		Edit1.addKeyListener(this);
		Edit1.setBounds(10,40,200,20);
		Edit1.setVisible(false);
		
		OKBtn=new Button("ȷ��");
		OKBtn.setBounds(30,70,36,20);
		OKBtn.setVisible(false);
		OKBtn.addActionListener(this);
		
		CancelBtn=new Button("ȡ��");
		CancelBtn.setBounds(100,70,36,20);
		CancelBtn.setVisible(false);
		CancelBtn.addActionListener(this);
		
		HelpBtn=new Button("����");
		HelpBtn.setBounds(170,70,36,20);
		HelpBtn.setVisible(false);
		HelpBtn.addActionListener(this);
	}
	public int anaysis()
	{
		String temp;
		String ss;
		int i;
		int res;
		char oldch;
		boolean sh;
		int j;
		int anaysis;
		
		state=0;
		addnum=0;
		leftstring="";
		ss=Edit1.getText();
		sh=false;
		if(ss=="")
		{
			anaysis=1;
			return anaysis;
		}
		i=0;
		temp="";
		oldch='a';
		anaysis=0;
		while(i<ss.length())
		{
			switch(ss.charAt(i))
			{
			case '=':
				{
					if((state==0)&&(oldch!='\\'))
					{
						if(i==1)
						{
							anaysis=6;
							return anaysis;
						}
						res=find(temp);
						if(res==0)
						{
							addstring(temp);
							temp="";
						}
						if(res==2)
						{
							leftstring=temp;
							anaysis=2;
							return anaysis;
						}
						j=m_Frame.form1.findindex(temp);
						if((j>0)&&(m_Frame.form1.ccss.ifhave(j)))
						{
							anaysis=8;
						}
						state=1;
						temp="";
						oldch='=';
					}
					else
					{
						temp=temp+'=';
						sh=false;
						oldch='a';
					}
					break;
				}
			case '|':
				{
					if(oldch=='\\')
					{
						temp=temp+'|';
						sh=false;
					}
					else
					{
						if(state==0)
						{
							anaysis=3;
							return anaysis;
						}
						else
						{
							if(temp=="")
							{
								if(sh)
								{
									anaysis=7;
									return anaysis;
								}
								sh=true;
							}
							else
							{
								res=find(temp);
								if(res==0)
								{
									addstring(temp);
								}
								sh=true;
								temp="";
							}
						}
						oldch='|';
					}
					break;		
				}
			case ' ':
				{
					if(state==0)
					{
						anaysis=4;
						return anaysis;
					}
					else
					{
						if(temp!="")
						{
							res=find(temp);
							if(res==0)
							{
								addstring(temp);
							}
						}
						temp="";
					}
					oldch=' ';
					break;
				}
			case '\\':
				{
					if(oldch=='\\')
					{
						temp=temp+'\\';
						sh=false;
						oldch='a';
					}
					else 
					{
						oldch='\\';
					}
					break;
				}
			default:
				{
					sh=false;
					temp=temp+ss.charAt(i);
					oldch=ss.charAt(i);
				}
			}
			i++;
		}
		if(state==0)
		{
			anaysis=5;
			return anaysis;
		}
		if((state==1)&&(oldch=='='))
		{
			anaysis=5;
			return anaysis;
		}
		if(temp!="")
		{
			if(find(temp)==0)
			{
				addstring(temp);
			}
		}
		return anaysis;
	}
	public void OKBtnClick()
	{
		int i,j;
		String temp,temp1;
		i=anaysis();
		if((mode==1)&&(i==8))
		{
			i=10;
		}
	//	Edit1.setFocus();
		switch(i)
		{
		case 1:
			{
				m_Frame.application.messagebox("���������ʽ","����!",m_Frame.mb_ok);
				break;
			}
		case 2:
			{
				m_Frame.application.messagebox("����ʽ��ӦΪ���ս����","����!",m_Frame.mb_ok);
				break;
			}
		case 3:
			{
				m_Frame.application.messagebox("�벻Ҫ�ڲ���ʽ������''��''���� ","����!",m_Frame.mb_ok);
				break;
			}
		case 4:
			{
				m_Frame.application.messagebox("�벻Ҫ�ڲ���ʽ�������������������Ϸ���(���󲿲�Ӧ�пո�)","����!",m_Frame.mb_ok);
				break;
			}
		case 5:
			{
				m_Frame.application.messagebox("���������ʽ","����!",m_Frame.mb_ok);
				break;
			}
		case 6:
			{
				m_Frame.application.messagebox("���ڲ���ʽ���������","����!",m_Frame.mb_ok);
				break;
			}
		case 7:
			{
				m_Frame.application.messagebox("��������''��''����֮��������������","����!",m_Frame.mb_ok);
				break;
			}
		case 8:
			{
				m_Frame.application.messagebox("���й����󲿵Ĳ���ʽ,�����޸ĺϲ�֮","����!",m_Frame.mb_ok);
				break;
			}
		default:
			{
				if(addnum>0)
				{
					temp="";
					j=1;
					while(j<=addnum)
					{
						temp+=addfuhao[j];
						temp=temp+' ';
						j++;
					}
					temp1="����ʽ����δ����ķ��ս����,�Ƿ�����'+temp+'�����ս�����б�";
					char x=0;
					temp1=temp1+x;
					if((m_Frame.application.messagebox(temp1,"����!",m_Frame.mb_okcancel)==m_Frame.mb_ok))
				    {
						j=1;
						while(j<=addnum)
						{
							m_Frame.form1.addfzjfuhao(addfuhao[j]);
							j++;
						}
					}
				}
				else
				{
				}
			}
		}
	}
	public int find(String s)
	{
		int find;
		int i;
		i=1;
		while((i<=m_Frame.form1.zjnum)&&(s!=m_Frame.form1.zjfuhao[i].name))
		{
			i++;
		}
		if(i<=m_Frame.form1.zjnum)
		{
			find=2;
			return find;
		}
		i=1;
		while((i<=m_Frame.form1.fzjnum)&&(s!=m_Frame.form1.fzjfuhao[i].name))
		{
			i++;
		}
		if(i<=m_Frame.form1.fzjnum)
		{
			find=1;
			return find;
		}
		find=0;
		return find;
	}
	public void FormActivate()
	{
		Edit1.requestFocus();
		pressnum=0;
	}
	public void Edit1KeyUp()
	{
	}
	public void addstring(String s)
	{
		int i;
		i=1;
		while((i<=addnum)&&(s!=addfuhao[i]))
		{
			i++;
		}
		if(i>addnum)
		{
			addfuhao[i]=s;
			addnum++;
		}
	}
	public  void keyReleased( KeyEvent e ) 
	{
		int i;
		if(e.getSource().equals(Edit1))
		{	
			if((!e.isControlDown())&&(pressnum!=0))
			{
				i=1;
				while((i<=m_Frame.form1.zjnum)&&(m_Frame.form1.zjfuhao[i].index!=pressnum))
				{
					i++;
				}
				if(i<=m_Frame.form1.zjnum)
				{
					Edit1.setText(Edit1.getText()+m_Frame.form1.zjfuhao[i].name);
				}
			}
			pressnum=0;
		}
	}
	public  void keyPressed( KeyEvent e ) 
	{
		if(e.getSource().equals(Edit1))
		{
			if((e.isControlDown())&&(e.getKeyChar()>=48)&&(e.getKeyChar()<=57))
			{
				pressnum=pressnum*10+e.getKeyChar()-48;
			}												  
		}
	}
	public  void keyTyped( KeyEvent e ) 
	{
	}
	public  void actionPerformed( ActionEvent e ) 
	{
		if(e.getSource().equals(OKBtn))
		{
			OKBtnClick();
			setVisible(false);
		}
		else
		{
			if(e.getSource().equals(CancelBtn))
			{
				setVisible(false);
			}
			else
			{
				if(e.getSource().equals(HelpBtn))
				{
					setVisible(false);
				}
			}
		}
	}
}
