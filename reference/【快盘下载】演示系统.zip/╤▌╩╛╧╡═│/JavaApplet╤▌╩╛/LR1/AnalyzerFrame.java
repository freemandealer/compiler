import java.applet.*;
import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.awt.Toolkit;

public class AnalyzerFrame extends Frame implements ItemListener  
{
	myform form1;
	myprod Dprod;
	ErrorDlg application;
	
	
   public static final int ID_Formula				= 0;
   public static final int ID_First_Follow_Set		= 1;
   public static final int ID_Status_Set			= 2;
   public static final int ID_Analysis_Diagram		= 3;
   public static final int ID_Analyzer				= 4;
   
   public static final int mb_ok					=0;
   public static final int mb_okcancel				=1;
   public static final int mb_cancel				=2;
   
 // Button object used to create Frame window
 Button creationButton;
 // Button object displayed in Frame window
 Button exitButton = null;
 String message=null;
 IDR_MENU1 menu=null;
 
 Formula formula=null;
 First_Follow_Set m_FFS=null;
 Status_Set m_Status_Set=null;
 Analysis_Diagram m_Analysis_Diagram=null;
 Analyzer m_Analyzer=null;
 
 int m_Width;
 int m_Height;
 // Constructor
 private void disposeAll()
 {
 }
 
 AnalyzerFrame(Button aButton, String title,int width,int height) 
 {
  super(title);  // Call ancestor constructor
  creationButton = aButton;  // Save reference to button
   m_Width=width;
  m_Height=height;
 setSize(width, height);  // Select frame window size
  // Construct layout for Frame and
  // add a Button object.
  Color lightGray=new Color(192, 192, 192);

  setBackground(lightGray );
  setLayout(null);
  menu = new IDR_MENU1(this);
  menu.CreateMenu();
  
  m_FFS=new First_Follow_Set(this,m_Width,m_Height);
  menu.ID_VIEW_FIRST_FOLLOW_SET.setState(false);
	 
  m_Status_Set=new Status_Set(this,m_Width,m_Height);
  menu.ID_VIEW_STATUS_SET.setState(false);
  
  m_Analysis_Diagram=new Analysis_Diagram(this,m_Width,m_Height);
  menu.ID_VIEW_ANALYSIS_DIAGRAM.setState(false);
  
  m_Analyzer=new Analyzer(this,m_Width,m_Height);
  menu.ID_VIEW_ANALYZER.setState(false);
  
  formula=new Formula(this,m_Width,m_Height);
  formula.setVisible(true);
  menu.ID_VIEW_FORMULA.setState(true); 
  
  form1=new myform(this);
  
  application=new ErrorDlg(this);
  	 
}
    public void m_File_Open() throws IOException
	{ 
			form1.Open1Click();
			
/*		openDlg= new FileDialog(this);
		openDlg.show();
		String fileName=null;
		fileName = openDlg.getFile();
		String pathName=openDlg.getDirectory();
		
        if (fileName!=null) 
		{
            m_FileReader  reader = null;
			reader = new m_FileReader(pathName+fileName);
            String nextLine = reader.readLine();
			formula.m_Text_Not_End_Symbol.setText(null);
            while(nextLine != null) 
			{
				formula.m_Text_Not_End_Symbol.append(nextLine);
				nextLine = reader.readLine();

            }
            reader.close();
			repaint();
        }
		openDlg.dispose();*/
    }
public void m_View(int state)
{
	menu.ID_VIEW_FORMULA.setState(false);
	menu.ID_VIEW_FIRST_FOLLOW_SET.setState(false);
	menu.ID_VIEW_STATUS_SET.setState(false);
	menu.ID_VIEW_ANALYSIS_DIAGRAM.setState(false);
	menu.ID_VIEW_ANALYZER.setState(false);
	
	formula.setVisible(false);
	m_FFS.setVisible(false);
	m_Status_Set.setVisible(false);
	m_Analysis_Diagram.setVisible(false);
	m_Analyzer.setVisible(false);
	
	switch(state)
	{
	case ID_Formula:
		{
			menu.ID_VIEW_FORMULA.setState(true);
			formula.setVisible(true);
			break;
		}
	case ID_First_Follow_Set:
		{
			menu.ID_VIEW_FIRST_FOLLOW_SET.setState(true);
			m_FFS.setVisible(true);
			break;
		}	
	case ID_Status_Set:
		{
			menu.ID_VIEW_STATUS_SET.setState(true);
			m_Status_Set.setVisible(true);
			break;
		}
	case ID_Analysis_Diagram:
		{
			menu.ID_VIEW_ANALYSIS_DIAGRAM.setState(true);
			m_Analysis_Diagram.setVisible(true);
			break;
		}
	case ID_Analyzer:
		{
			menu.ID_VIEW_ANALYZER.setState(true);
			m_Analyzer.setVisible(true);
			break;
		}
	}
	
	repaint();
};

public void itemStateChanged( ItemEvent e ) 
	{
	
	   if("����ʽ".equals(e.getItem()))
	  {	 
	  	  m_View(ID_Formula);
	  }else if("First Follow ��".equals(e.getItem()))
	   {
		   m_View(ID_First_Follow_Set);
	   }
	   else if("״̬��".equals(e.getItem()))
	   {
		   m_View(ID_Status_Set);
	   }
	   else if("������".equals(e.getItem()))
	   {
		   m_View(ID_Analysis_Diagram);
	   }
	   else if("������".equals(e.getItem()))
	   {
		   m_View(ID_Analyzer);
	   }
	}

 // Paint message inside Frame window
 public void paint(Graphics g) {
 }
 public boolean handleEvent(Event evt) {
  if (evt.id == Event.WINDOW_DESTROY) {
   creationButton.setEnabled(true);
   menu.DeleteMenu ();
   dispose();
   return true;
  }
  return super.handleEvent(evt);
 }
	// Handle events intended for this frame window
 public boolean action(Event evt, Object what){
  boolean exitWindow = false;
  if ("New".equals(what)){
	message=new String("New");
  }else if ("Open �ķ�".equals(what)) {
	  try{
			m_File_Open();
	  }catch(IOException e)
	  {
		  
	  }
  } else if ("Save �ķ�".equals(what)) {
   message = new String("Save �ķ�");
  } else if ("Save as �ķ�".equals(what)) {
   message = new String("Save as �ķ�");
  } else if ("Open LR1 �ķ�".equals(what)) {
   message = new String("Open LR1 �ķ�");
  } else if ("Save LR1 �ķ�".equals(what)) {
   message = new String("Save LR1 �ķ�");
  } else if ("Save As LR1 �ķ�".equals(what)) {
   message = new String("Save As LR1 �ķ�");
  } else if ("Save �ķ���".equals(what)) {
   message = new String("Save �ķ���");
  }else if("Exit".equals(what)){
	  message= new String("Exit");
      exitWindow = true;
  } else if("ʹ��˵��".equals(what)){
	  message= new String("ʹ��˵��");
  } else if("����LR1�ķ���������ʾ����".equals(what)){
	  message=new String("����LR1�ķ���������ʾ����");
  }
  if (exitWindow) {
   creationButton.setEnabled(true);
   menu.DeleteMenu();
   dispose();  // "Close" window
   return true;
  }
  repaint();
  return super.action(evt, what);
 }
}
