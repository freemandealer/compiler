#pragma once

#include <vector>
#include "Pair.h"
using namespace std;

class ProjectSet
{
public:
	ProjectSet(void);
	~ProjectSet(void);
	ProjectSet(const ProjectSet & set);
	ProjectSet(Pair pair);
	bool Insert(Pair insert);
	bool Delete(Pair del);
	bool Find(const Pair & find) const;
	int FindPos(const Pair & find) const;
	int Add(const ProjectSet & set);
	int Sub(const ProjectSet & set);
	int Size() const;
	ProjectSet operator + (const ProjectSet & set);
	ProjectSet operator - (const ProjectSet & set);
	const ProjectSet operator = (const ProjectSet & set);
	bool operator == (const ProjectSet & set);
	Pair GetAt(int iPos);
	bool IsEmpty();
private:
	vector <Pair> SetContent;
};
