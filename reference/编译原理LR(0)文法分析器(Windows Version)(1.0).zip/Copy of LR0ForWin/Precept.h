#pragma once
#include <string>
using namespace std;

class Precept
{
public:
	Precept(void);
	Precept(string left, string right);
	~Precept(void);
	string GetLeft();
	string GetRight();
private:
	string strLeft;
	string strRight;
public:
	void Clear(void);
};

