#include "stdafx.h"
#include "ProjectSet.h"

ProjectSet::ProjectSet(void)
{
	SetContent.clear();
}

ProjectSet::~ProjectSet(void)
{
}

ProjectSet::ProjectSet(const ProjectSet & set)
{
	SetContent = set.SetContent;
}

ProjectSet::ProjectSet(Pair pair)
{
	SetContent.push_back(pair);
}

bool ProjectSet::Insert(Pair insert)
{
	bool bFind = Find(insert);
	if (!bFind)
		SetContent.push_back(insert);
	return (!bFind);
}

bool ProjectSet::Delete(Pair del)	
{
	int iPos = FindPos(del);
	if (iPos != -1)
	{
		for (unsigned int i = iPos; i < SetContent.size() - 1; i ++)
		{
			SetContent[i] = SetContent[i+1];
		}
		SetContent.pop_back();
	}
	return (iPos != -1);
}

int ProjectSet::FindPos(const Pair & find) const
{
	bool bFind = false;
	unsigned int iPos;
	for (iPos = 0; iPos < SetContent.size(); iPos ++)
	{
		if (SetContent[iPos] == find)
		{
			bFind = true;
			break;
		}
	}
	if (bFind)
		return iPos;
	else
		return -1;
}

bool ProjectSet::Find(const Pair & find) const
{
	bool bFind = false;
	for (unsigned int iPos = 0; iPos < SetContent.size(); iPos ++)
	{
		if (SetContent[iPos] == find)
		{
			bFind = true;
			break;
		}
	}
	return bFind;
}

int ProjectSet::Add(const ProjectSet & set)
{
	int iCount = 0;
	for(int iPos = 0; iPos < set.Size(); iPos ++)
	{
		if(Insert(set.SetContent[iPos]))
			iCount ++;
	}
	return iCount;
}

int ProjectSet::Sub(const ProjectSet & set)
{
	int iCount = 0;
	for(int iPos = 0; iPos < set.Size(); iPos ++)
	{
		if(Delete(set.SetContent[iPos]))
			iCount ++;
	}
	return iCount;

}

int ProjectSet::Size() const
{
	return (int) SetContent.size();
}

ProjectSet ProjectSet::operator + (const ProjectSet & set)
{
	ProjectSet newSet = * this;
	newSet.Add(set);
	return newSet;
}

ProjectSet ProjectSet::operator - (const ProjectSet & set)
{
	ProjectSet newSet = * this;
	newSet.Sub(set);
	return newSet;
}

const ProjectSet ProjectSet::operator = (const ProjectSet & set)
{
	SetContent = set.SetContent;
	return * this;
}

Pair ProjectSet::GetAt(int iPos)
{
	if (iPos < (int) SetContent.size())
		return SetContent[iPos];
	else
		return Pair(-1, -1);
}

bool ProjectSet::IsEmpty()
{
	return (Size() == 0);
}

bool ProjectSet::operator == (const ProjectSet & set)
{
	for( int i = 0; i < Size(); i++ )
	{
		if (!set.Find(SetContent[i]))
			return false;
	}
	for( int j = 0; j < set.Size(); j++ )
	{
		if (!Find(set.SetContent[j]))
			return false;
	}
	return true;
}