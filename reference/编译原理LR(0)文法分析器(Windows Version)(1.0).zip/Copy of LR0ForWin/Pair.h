#if !defined(AFX_PAIR_H__6DD6E3FB_8A82_4452_A968_2978434726F6__INCLUDED_)
#define AFX_PAIR_H__6DD6E3FB_8A82_4452_A968_2978434726F6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Pair  
{
public:
	Pair();
	Pair(int i, int j);
	int one;
	int two;
	bool operator == (const Pair & pair) const;
};

#endif // !defined(AFX_PAIR_H__6DD6E3FB_8A82_4452_A968_2978434726F6__INCLUDED_)
