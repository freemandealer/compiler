#include "stdafx.h"
#include "Grammar.h"
#include <cassert>
#include <iostream>
using namespace std;

Grammar::Grammar()
{
	cStart = 0;
	P.clear();
	nVn = 0;
	nVt = 0;
	nP = 0;
	nC = 0;
	GoSet.clear();
	pTable = 0;
	iLegal = 0;

}
Grammar::~Grammar()
{
	if (pTable !=0)
		delete []pTable;
}
Grammar::Grammar(const Grammar & g)
{
	if (&g == this)
		return;
	CopyGrammar(g);	
}
const Grammar Grammar::operator = (const Grammar & g)
{
	if (&g != this)
		CopyGrammar(g);
	return *this;
}
void Grammar::CopyGrammar(const Grammar & g)
{
	Vt = g.Vt;
	Vn = g.Vn;
	cStart = g.cStart;
	P = g.P;
	C = g.C;
	GoSet = g.GoSet;
	nVt = g.nVt;
	nVn = g.nVn;
	nP = g.nP;
	nC = g.nC;
	iLegal = g.iLegal;
	if (g.pTable != 0)
	{
		pTable = new Pair[C.size() * (nVt + 1 + nVn)];
		for( int i = 0; i < C.size() * (nVt + 1 + nVn); i++ )
			pTable[i] = g.pTable[i];
	}
}

void Grammar::SetVt(string vt)
{
	for(unsigned int i = 0; i < vt.length(); i ++)
		Vt.Insert(vt[i]);
	nVt = Vt.Size();	
}

void Grammar::SetVn(string vn)
{
	for(unsigned int i = 0; i < vn.length(); i ++)
		Vn.Insert(vn[i]);
	nVn = Vn.Size();
}

void Grammar::SetStart(char start)
{
	if (Vn.Find(start))
		cStart = start;
}

void Grammar::AddPrecept(string p)
{
	string strLeft, strRight;
	char cTemp;
	int iPos = 0;
	for(unsigned int i = 0; i < p.length(); i ++)
	{
		cTemp = p[i];		
		if (cTemp == '-')
		{
			iPos = i;
			break;
		}
		strLeft += cTemp;
		
	}
	cTemp = p.at(++iPos);
	for(i = iPos + 1; i < p.length(); i ++)
	{
		cTemp = p[i];
		strRight += cTemp;
	}
	Precept precept(strLeft,strRight);
	P.push_back(precept);
	nP = (int) P.size();
}

bool Grammar::IsGrammarLegal()
{
	bool flag = false;
	if (!Vn.Find(cStart))
		return false;
	if (P.empty())
		return false;
	for(int i = 0; i < Vn.Size(); i ++)
	{
		if(Vt.Find(Vn.GetAt(i)))
			return false;
	}
	for(i = 0; i < Vt.Size(); i ++)
	{
		if(Vn.Find(Vt.GetAt(i)))
			return false;
	}
	for(i = 0; i < P.size(); i ++)
	{
		string strTest;
		strTest = P[i].GetLeft();
		for(unsigned int j = 0; j < strTest.length(); j ++)
		{
			if ((!Vn.Find(strTest[j]))&&(!Vt.Find(strTest[j])))
				return false;
			if ((j==0)&&(strTest[j] == cStart))
				flag = true;
		}
		strTest = P[i].GetRight();
		for(j = 0; j < strTest.length(); j ++)
		{
			if ((!Vn.Find(strTest[j]))&&(!Vt.Find(strTest[j])))
				return false;
		}
	}
	return flag;
}

bool Grammar::IsInVn(char cChar)
{
	return Vn.Find(cChar);
}

bool Grammar::IsInVt(char cChar)
{
	return Vt.Find(cChar);
}

char Grammar::GetStart()
{
	return cStart;
}

void Grammar::GenerateLR0Table()
{
	EnlargeGrammar();
	MakeProjects();
	if (IsLegalLR0Grammar())
		GenerateTable();
}


void Grammar::EnlargeGrammar()
{
	string strRight;
	strRight = cStart;
	P.insert(P.begin(), Precept("$", strRight));
	Vn.Add('$');
	nP++;
}

void Grammar::MakeProjects()
{
	ProjectSet ps = GetClosure(Pair(0, 0));
	AddProject(ps);
	assert(nC == C.size());
	int iPos = 0;
	while (iPos < nC)
	{
		ps = C[iPos];
		for (int i = 0; i < ps.Size(); i++)
		{
			Precept p = GetProject(ps.GetAt(i));
			string strRight = p.GetRight();
			assert(strRight[ps.GetAt(i).two] == '.');
			if (ps.GetAt(i).two < strRight.length() - 1)
			{
				ProjectSet tempSet = MakeGoSet(iPos, strRight[ps.GetAt(i).two + 1]);
				GoData gd;
				gd.iFrom = iPos;
				gd.cChar = strRight[ps.GetAt(i).two + 1];
				if(AddProject(tempSet))
				{
					gd.iTo = nC - 1;
				}
				else
				{
					int j;
					for (j = 0; j < nC; j++)
						if (C[j] == tempSet)
							break;
					assert(j != nC);
					gd.iTo = j;
				}
				GoSet.push_back(gd);
			}
		}
		iPos++;
	}
	for (int i = 0; i < nC; i++)
	{
		ProjectSet ps = C[i];
		int iP = 0;
		int iR = 0;
		for (int j = 0; j < ps.Size(); j++)
		{
			Pair p = ps.GetAt(j);
			string strRight = P[p.one].GetRight();
			if (p.two == strRight.size())
			{
				if (strRight.at(p.two - 1) != cStart)
					iR++;
			}
			else
			{
				if (p.one > 0)
					if (Vt.Find(strRight[p.one - 1]))
						iP++;
			}
		}
		assert(iLegal == 0);
		if (((iP != 0) && (iR !=0 )) || (iR >= 2))
		{
			iLegal = 2;
			break;
		}
	}
	if (iLegal == 0)
		iLegal = 1;
}

void Grammar::GenerateTable()
{
	bool bLegal = true;
	pTable = new Pair[C.size() * (nVt + 1 + nVn)];
	int i;
	for (i = 0; i < C.size() * (nVt + 1 + nVn); i++ )
		pTable[i] = Pair(0, 0);
	assert (nC == C.size());
	for( i = 0; i < nC; i++ )
	{
		ProjectSet ps = C[i];
		for( int j = 0; j < ps.Size(); j++)
		{
			Pair p = ps.GetAt(j);
			string strRight = P[p.one].GetRight();
			if (p.two < strRight.length())
			{
				if (Vt.Find(strRight[p.two]))
				{
					int t = GetGoSet(i, strRight[p.two]);
					assert (t != -1);
					bLegal &= FillTable(i, strRight[p.two], Pair('S', t));
				}
				else
				{
					if (Vn.Find(strRight[p.two]))
					{
						int t;
						t =	GetGoSet(i, strRight[p.two]);
						assert (t != -1);
						bLegal &= FillTable(i, strRight[p.two], Pair(t,0));
					}
					else
					{
						assert(false);
					}
				}
			}
			else
			{
				if (p == Pair(0, 1))
				{
					bLegal &= FillTable(i, '#', Pair('a', 0));
				}
				else
				{
					for( int x = 0; x < nVt + 1; x++ )
					{
						bLegal &= FillTable(i, ((x != nVt)?Vt.GetAt(x):'#'), Pair('R', p.one));
					}
				}
			}
		}
	}
	assert(bLegal);
}

Precept Grammar::GetProject(const Pair & pair1)
{
	Precept temp;
	if (pair1.one >= nP)
		return temp;
	string strRight = P[pair1.one].GetRight();
	if (strRight.length() < pair1.two)
		return temp;
	return Precept(P[pair1.one].GetLeft(), strRight.substr(0, pair1.two) + "." + strRight.substr(pair1.two));
}

ProjectSet Grammar::GetClosure(const Pair & pair1)
{
	int iNum = pair1.one;
	int iPos = pair1.two;
	ProjectSet temp;
	temp.Insert(Pair(iNum, iPos));
	int iCount = 0;
	while (iCount < temp.Size())
	{
		iNum = temp.GetAt(iCount).one;
		iPos = temp.GetAt(iCount).two;
		string strRight = P[iNum].GetRight();
		if (iPos < strRight.length())
		{
			if (Vn.Find(strRight[iPos]))
			{
				for (int j = 0; j < nP; j++)
				{
					if (P[j].GetLeft()[0] == strRight[iPos])
						temp.Insert(Pair(j,0));
				}
			}
		}
		iCount++;
	}
	return temp;
}

ProjectSet Grammar::MakeGoSet(int iI, char cChar)
{
	ProjectSet rtn;
	ProjectSet ps = C[iI];
	for (int i = 0; i < ps.Size(); i++)
	{
		Pair p = ps.GetAt(i);
		string strRight = P[p.one].GetRight();
		if (p.two < strRight.length())
		{
			if(strRight[p.two] == cChar)
			{
				rtn.Add(GetClosure(Pair(p.one, p.two + 1)));
			}
		}
	}
	return rtn;
}
int Grammar::GetGoSet(int iI, char cChar)
{
	GoData gd;
	for(int i = 0; i < GoSet.size(); i++)
	{
		gd = GoSet[i];
		if ((gd.iFrom == iI) && (gd.cChar == cChar))
			return gd.iTo;
	}
	assert(false);
	return -1;
}

bool Grammar::AddProject(const ProjectSet & ps)
{
	assert(nC == C.size());
	for (int i = 0; i < nC; i++)
	{
		if (C[i] == ps)
			return false;
	}
	C.push_back(ps);
	nC++;
	return true;
}

bool Grammar::FillTable(int nLine, char cChar, Pair p)
{
	int iPos;
	if (cChar == '#')
		iPos = nLine * (nVt + 1 + nVn) + nVt;
	else
		if ((iPos = Vn.FindPos(cChar)) != -1)
			iPos += (nLine * (nVt + 1 + nVn) + nVt + 1);
		else
			if ((iPos = Vt.FindPos(cChar)) != -1)
				iPos += (nLine * (nVt + 1 + nVn));
			else
				assert(false);

	if (pTable[iPos] == Pair(0,0))
		pTable[iPos] = p;
	else
	{
		if(!(pTable[iPos] == p))
			return false;
	}
	return true;
}


string Grammar::OutputHTML()
{
	char szTempPath[MAX_PATH]; 
	char szTempName[MAX_PATH]; 
	::GetTempPath(100,szTempPath);
	::GetTempFileName(szTempPath,"LR0",0,szTempName);
	
	CStdioFile out;
	CString temp;	
	out.Open(szTempName, CFile::modeCreate | CFile::modeWrite);
	out.WriteString("<html>\n");
	out.WriteString("<head>\n");
	out.WriteString("<title>Untitled Document</title>\n");
	out.WriteString("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\">\n");
	out.WriteString("</head>\n");
	out.WriteString("<body bgcolor=\"#FFFFFF\" text=\"#000000\">\n");
	out.WriteString("��������������ķ�G��<br>\n");
	temp = "���ս���ż���Ϊ��{ ";
	for(int i = 0; i < nVn -1; i++)
	{
		temp += Vn.GetAt(i);
		temp += ", ";
	}
	temp += Vn.GetAt(nVn-1);
	temp += " }<br>\n";
	out.WriteString(temp);
	temp = "�ս�����ż���Ϊ��{ ";
	for(i = 0; i < nVt -1; i++)
	{
		temp += Vt.GetAt(i);
		temp += ", ";
	}
	temp += Vt.GetAt(nVt-1);
	temp += " }<br>\n";
	out.WriteString(temp);
	temp = "G[";
	temp += cStart;
	temp += "]:<br>\n";
	out.WriteString(temp);
	for(i = 1; i < nP; i ++)
	{
		temp.Format("(%d)&nbsp;", i);
		out.WriteString(temp);
		out.WriteString(P[i].GetLeft().c_str());
		out.WriteString("->");
		out.WriteString(P[i].GetRight().c_str());
		out.WriteString("<br>\n");
	}
	out.WriteString("<br>���������ɵ��ع��ķ�G'��<br>\n");
	temp = "���ս���ż���Ϊ��{ $, ";
	for(i = 0; i < nVn -1; i++)
	{
		temp += Vn.GetAt(i);
		temp += ", ";
	}
	temp += Vn.GetAt(nVn-1);
	temp += " }<br>\n";
	out.WriteString(temp);
	temp = "�ս�����ż���Ϊ��{ ";
	for(i = 0; i < nVt -1; i++)
	{
		temp += Vt.GetAt(i);
		temp += ", ";
	}
	temp += Vt.GetAt(nVt-1);
	temp += " }<br>\n";
	out.WriteString(temp);
	temp = "G'[";
	temp += cStart;
	temp += "]:<br>\n";
	out.WriteString(temp);
	for(i = 0; i < nP; i ++)
	{
		temp.Format("(%d)&nbsp;", i);
		out.WriteString(temp);
		out.WriteString(P[i].GetLeft().c_str());
		out.WriteString("->");
		out.WriteString(P[i].GetRight().c_str());
		out.WriteString("<br>\n");
	}
	out.WriteString("<br>���ķ�����Ŀ���£�<br>\n");
	int nCount = 1;
	for(i = 0; i < nP; i++)
	{
		for(int j = 0; j < P[i].GetRight().length() + 1 ; j++)
		{
			temp.Format("(%d)&nbsp;", nCount);
			temp += (GetProject(Pair(i, j)).GetLeft() + "->" + GetProject(Pair(i, j)).GetRight()).c_str();
			temp += "<br>";
			out.WriteString(temp);
			nCount++;
		}
	}
	out.WriteString("<br>LR(0)��Ŀ�淶�����£�<br>\n");
	for (i = 0; i < nC; i++)
	{
		temp.Format("I<font size=\"1\">%d</font> = { ", i);
		out.WriteString(temp);
		for (int j = 0; j < C[i].Size() - 1; j++)
		{
//			temp = CString(GetProject(C[i].GetAt(j)).GetLeft().c_str()) + "->" + GetProject(C[i].GetAt(j)).GetRight().c_str() + ", ";
//			out.WriteString(temp);
			temp.Format("%d, ", GetProjectNum(C[i].GetAt(j)) + 1);
			out.WriteString(temp);
		}
//		temp = CString(GetProject(C[i].GetAt(j)).GetLeft().c_str()) + "->" + GetProject(C[i].GetAt(j)).GetRight().c_str() + " }<br>\n";
//		out.WriteString(temp);
		temp.Format("%d }<br>\n", GetProjectNum(C[i].GetAt(j)) + 1);
		out.WriteString(temp);		
	}
	if (IsLegalLR0Grammar())
	{
		out.WriteString("<Br>�ķ���LR(0)������<br>\n");
		out.WriteString("<table border=\"1\"  cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse\" bordercolor=\"#111111\">\n");
		temp.Format("<tr> \n <td nowrap rowspan=\"2\">&nbsp;״̬&nbsp;</td><td nowrap colspan=\"%d\">\n", nVt +1);
		out.WriteString(temp);
		out.WriteString("<div align=\"center\">ACTION</div>\n");
		out.WriteString("</td>\n");
		temp.Format("<td nowrap colspan=\"%d\">\n", nVn);
		out.WriteString(temp);  
		out.WriteString("<div align=\"center\">GOTO</div>\n</td>\n</tr>\n<tr>\n");
		for (i = 0; i < nVt; i++)
			out.WriteString(CString("<td nowrap>&nbsp;") + Vt.GetAt(i) + "&nbsp;</td>\n");
		out.WriteString("<td nowrap>&nbsp;#&nbsp;</td>\n");
		for (i = 0; i < nVn; i++)
			out.WriteString(CString("<td nowrap>&nbsp;") + Vn.GetAt(i) + "&nbsp;</td>\n");
		out.WriteString("</tr>\n");
		for (int x = 0; x < nC; x++)
		{
			out.WriteString("<tr>\n<td>");
			temp.Format("%3d", x);
			temp.Replace(" ","&nbsp;");
			temp += "</td>\n";
			out.WriteString(temp);
			for (int y = 0; y < nVt; y++)
			{
				int iPos = x * (nVt + 1 + nVn) + y;
				if (pTable[iPos].one != 0)
				{
					temp.Format("%c<font size=\"1\">%d</font>", pTable[iPos].one, pTable[iPos].two);
					temp = "<td nowrap>&nbsp;" + temp + "&nbsp;</td>\n";
				}
				else
				{
					temp = "<td nowrap>&nbsp;&nbsp;&nbsp;</td>\n";
				}
				out.WriteString(temp);
			}
			int iPos = x * (nVt + 1 + nVn) + nVt;
			if (pTable[iPos].one != 'a')
				temp.Format("%c<font size=\"1\">%d</font>", pTable[iPos].one, pTable[iPos].two);
			else
				temp = "acc";
			temp = "<td nowrap>&nbsp;" + temp + "&nbsp;</td>\n";
			out.WriteString(temp);
			for (y = 0; y < nVn; y++)
			{
				int iPos = x * (nVt + 1 + nVn) + nVt + 1 + y;
				if (pTable[iPos].one != 0)
					temp.Format("%d", pTable[iPos].one);
				else
					temp = "&nbsp;";
				temp = "<td nowrap>&nbsp;" + temp + "&nbsp;</td>\n";
				out.WriteString(temp);
			}
			out.WriteString("</tr>\n");
		}
		out.WriteString("</table>\n");
	}
	else
	{
		out.WriteString("<br><font color= \"#ff0000\"<b>������ķ�����LR(0)�ķ�����������Ԥ�������<b></font><br>\n");
	}
	out.WriteString("</body>\n");
	out.WriteString("</html>");
	out.Close();
	return szTempName;
}

void Grammar::Output(char * pFilename)
{
	if (pFilename == 0)
		return;
	CStdioFile OutFile;
	OutFile.Open(pFilename, CFile::modeCreate | CFile::modeWrite);
	CString t;
	OutFile.WriteString("[Terminator]\n");
	for(int i = 0; i < nVt; i++)
	{
		t.Format("%c\n", Vt.GetAt(i));
		OutFile.WriteString(t);
		
	}
	OutFile.WriteString("\n[NonTerminator]\n");
	for(i = 0; i < nVn; i++)
	{
		t.Format("%c\n", Vn.GetAt(i));
		OutFile.WriteString(t);
	}
	OutFile.WriteString("\n[Starter]\n");
	t.Format("%c", cStart);
	t += "\n\n[Precept]\n";
	OutFile.WriteString(t);
	for(i = 1; i < nP; i++)
	{
		t.Format("%s->%s\n", P[i].GetLeft().c_str(), P[i].GetRight().c_str());
		OutFile.WriteString(t);
	}
	OutFile.WriteString("\n[Projects]\n");
	
	for(i = 0; i < nP; i++)
	{
		for(int j = 0; j < P[i].GetRight().length() + 1 ; j++)
		{
			OutFile.WriteString((GetProject(Pair(i, j)).GetLeft() + "->" + GetProject(Pair(i, j)).GetRight() + "\n").c_str());
		}
	}
	if (IsLegalLR0Grammar())
	{
		OutFile.WriteString("\n[AnalyzeTable]\n");
		{
			for (int x = 0; x < nC; x++)
			{
				for (int y = 0; y < nVt; y++)
				{
					int iPos = x * (nVt + 1 + nVn) + y;
					if (pTable[iPos].one != 0)
					{
						t.Format("ACTION, %d, %c = %c, %d\n", x, Vt.GetAt(y), pTable[iPos].one, pTable[iPos].two);
						OutFile.WriteString(t);
					}
				}
				int iPos = x * (nVt + 1 + nVn) + nVt;
				if (pTable[iPos].one != 0)
				{
					if (pTable[iPos].one != 'a')
					{
						t.Format("ATCION, %d, # = %c, %d\n", x, pTable[iPos].one, pTable[iPos].two);
						OutFile.WriteString(t);
					}
					else
					{
						t.Format("ACTION, %d, # = Accept\n", x);
						OutFile.WriteString(t);
					}
				}
				for (y = 0; y < nVn; y++)
				{
					int iPos = x * (nVt + 1 + nVn) + nVt + 1 + y;
					if (pTable[iPos].one != 0)
					{
						t.Format("GOTO, %d, %c = %d\n", x, Vn.GetAt(y), pTable[iPos].one);
						OutFile.WriteString(t);
					}
				}
			}
		}
	}
	OutFile.Close();
}

Precept Grammar::GetPrecept(int n)
{
	if (n < nP)
		return P[n];
	else
		return Precept();
}

Pair Grammar::GetAction(int iStatus, char cNext)
{
	if (pTable == 0)
		return Pair(0, 0);
	int iPos;
	if (cNext == '#')
		iPos = iStatus * (nVt + 1 + nVn) + nVt;
	else
		if ((iPos = Vt.FindPos(cNext)) != -1)
			iPos += (iStatus * (nVt + 1 + nVn));
		else
			assert(false);
	return pTable[iPos];
}

int Grammar::GetGoTo(int iStatus, char cChar)
{
	if (pTable == 0)
		return -1;
	int iPos;
	if ((iPos = Vn.FindPos(cChar)) != -1)
		iPos += (iStatus * (nVt + 1 + nVn) + nVt + 1);
	else
		assert(false);
	return pTable[iPos].one;
}

bool Grammar::IsLegalLR0Grammar()
{
	return (iLegal == 1);
}

int Grammar::GetProjectNum(const Pair &p)
{
	int iPos = 0;
	for(int i = 0; i < p.one; i++)
	{
		iPos += (P[i].GetRight().length() + 1);
	}
	iPos += p.two;
	return iPos;
}
