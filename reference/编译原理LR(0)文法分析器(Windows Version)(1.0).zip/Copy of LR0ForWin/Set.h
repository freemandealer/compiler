#pragma once

#include <vector>
using namespace std;

class Set
{
public:
	Set(void);
	~Set(void);
	Set(const Set & set);
	Set(char cChar);
	bool Insert(char cInsert);
	bool Delete(char cDelete);
	bool Find(char cFind);
	int FindPos(char cFind);
	int Add(const Set & set);
	int Sub(const Set & set);
	int Size() const;
	Set operator + (const Set & set);
	Set operator - (const Set & set);
	const Set operator = (const Set & set);
	char GetAt(int iPos);
	bool IsEmpty();
private:
	vector <char> SetContent;
};
