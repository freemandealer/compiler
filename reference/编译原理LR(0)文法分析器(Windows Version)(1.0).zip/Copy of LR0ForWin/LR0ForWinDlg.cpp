// LR0ForWinDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LR0ForWin.h"
#include "LR0ForWinDlg.h"
#include "TableDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLR0ForWinDlg dialog

CLR0ForWinDlg::CLR0ForWinDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLR0ForWinDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLR0ForWinDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CLR0ForWinDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLR0ForWinDlg)
	DDX_Control(pDX, IDC_VTLIST, m_vtlist);
	DDX_Control(pDX, IDC_VTEDIT, m_vtedit);
	DDX_Control(pDX, IDC_VNLIST, m_vnlist);
	DDX_Control(pDX, IDC_VNEDIT, m_vnedit);
	DDX_Control(pDX, IDC_STARTEDIT, m_startedit);
	DDX_Control(pDX, IDC_PLIST, m_plist);
	DDX_Control(pDX, IDC_PEDIT, m_pedit);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CLR0ForWinDlg, CDialog)
	//{{AFX_MSG_MAP(CLR0ForWinDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_VNADD, OnVnadd)
	ON_BN_CLICKED(IDC_CLEAR, OnClear)
	ON_BN_CLICKED(IDC_GTABLE, OnGtable)
	ON_BN_CLICKED(IDC_IMPORT, OnImport)
	ON_BN_CLICKED(IDC_PADD, OnPadd)
	ON_BN_CLICKED(IDC_PDEL, OnPdel)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_BN_CLICKED(IDC_VNDEL, OnVndel)
	ON_BN_CLICKED(IDC_VTADD, OnVtadd)
	ON_BN_CLICKED(IDC_VTDEL, OnVtdel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLR0ForWinDlg message handlers

BOOL CLR0ForWinDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CLR0ForWinDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CLR0ForWinDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CLR0ForWinDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CLR0ForWinDlg::OnOK() 
{
	// TODO: Add extra validation here
	
//	CDialog::OnOK();
}

void CLR0ForWinDlg::OnVnadd() 
{
	CString string;
	m_vnedit.GetWindowText(string);
	if(string.GetLength()!=1)
		MessageBox("������ķ��ս���������飡","����", MB_OK | MB_ICONSTOP);
	else
	{
		if((m_vnlist.FindStringExact(-1, string) == LB_ERR) && (string!=""))
			m_vnlist.AddString(string);
	}
	m_vnedit.SetFocus();
	m_vnedit.SetSel(0, -1);	
}

void CLR0ForWinDlg::OnClear() 
{
	m_vtlist.ResetContent();
	m_vnlist.ResetContent();
	m_plist.ResetContent();
	m_vtedit.SetWindowText("");
	m_vnedit.SetWindowText("");
	m_pedit.SetWindowText("");
	m_startedit.SetWindowText("");		
}

void CLR0ForWinDlg::OnGtable() 
{
	CTableDlg dlg;
	dlg.SetControlInfo(IDC_EXPLORER1, RESIZE_BOTH);
	dlg.SetControlInfo(IDOK, ANCHORE_BOTTOM | ANCHORE_RIGHT);
	dlg.SetControlInfo(IDC_EXPORT, ANCHORE_BOTTOM | ANCHORE_RIGHT);
	dlg.SetControlInfo(IDC_ANALYZE, ANCHORE_BOTTOM | ANCHORE_RIGHT);
	string temp = "";
	CString t;
	for(int i = 0; i < m_vtlist.GetCount(); i++)
	{
		m_vtlist.GetText(i,t);
		//temp.push_back(t.GetAt(0));
		temp += t.GetAt(0);
	}
	dlg.g.SetVt(temp);
	temp = "";
	for(i = 0; i < m_vnlist.GetCount(); i++)
	{
		m_vnlist.GetText(i,t);
		//temp.push_back(t.GetAt(0));
		temp += t.GetAt(0);
	}
	dlg.g.SetVn(temp);
	m_startedit.GetWindowText(t);
	if (t == "")
	{
		MessageBox("������ķ��������飡", "����",MB_OK | MB_ICONSTOP);
		return;
	}
	dlg.g.SetStart(t.GetAt(0));
	temp = "";
	for(i = 0; i < m_plist.GetCount(); i++)
	{
		temp = "";
		m_plist.GetText(i,t);
		for(int j = 0; j < t.GetLength(); j ++)
			//temp.push_back(t.GetAt(j));
			temp += t.GetAt(j);
		dlg.g.AddPrecept(temp);
	}
	if(dlg.g.IsGrammarLegal())
	{
		dlg.g.GenerateLR0Table();
		dlg.DoModal();
	}
	else
	{
		MessageBox("������ķ��������飡", "����",MB_OK | MB_ICONSTOP);
	}		
}

void CLR0ForWinDlg::OnImport() 
{
   char szFilters[]=
      "�ķ��ļ� (*.txt)|*.txt|All Files (*.*)|*.*||";

	CFileDialog fdlg (TRUE, "txt", "*.txt",
      OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);

	if(fdlg.DoModal() == IDOK)
	{
		OnClear();
		CString pathName = fdlg.GetPathName();
		CStdioFile InFile;
		InFile.Open(pathName,CFile::modeRead);
		CString temp;
		InFile.ReadString(temp);
		if (temp != "[Terminator]")
		{
			MessageBox("�ķ��ļ�����","����",MB_OK|MB_ICONSTOP);
			InFile.Close();
			return;
		}
		do
		{
			InFile.ReadString(temp);
			if(temp=="") 
				break;
			m_vtlist.AddString(temp);
		}while(true);
		InFile.ReadString(temp);
		if (temp != "[NonTerminator]")
		{
			MessageBox("�ķ��ļ�����","����",MB_OK|MB_ICONSTOP);
			InFile.Close();
			return;
		}
		do
		{
			InFile.ReadString(temp);
			if(temp=="") 
				break;
			m_vnlist.AddString(temp);
		}while(true);
		InFile.ReadString(temp);
		if (temp != "[Starter]")
		{
			MessageBox("�ķ��ļ�����","����",MB_OK|MB_ICONSTOP);
			InFile.Close();
			return;
		}
		InFile.ReadString(temp);
		m_startedit.SetWindowText(temp);
		InFile.ReadString(temp);
		InFile.ReadString(temp);
		if (temp != "[Precept]")
		{
			MessageBox("�ķ��ļ�����","����",MB_OK|MB_ICONSTOP);
			InFile.Close();
			return;
		}
		do
		{
			InFile.ReadString(temp);
			if(temp == "") 
				break;
			m_plist.AddString(temp);
		}while((true)&&(InFile.GetPosition()!=InFile.GetLength()));
		InFile.Close();
			
	}		
}

void CLR0ForWinDlg::OnPadd() 
{
	CString string;
	m_pedit.GetWindowText(string);
	if(string.Find("->") == -1)
		MessageBox("�����������ʽ���Ϸ������飡","����", MB_OK | MB_ICONSTOP);
	else
	{
		if((m_plist.FindStringExact(-1, string) == LB_ERR)&&(string!=""))
			m_plist.AddString(string);
		m_pedit.SetFocus();
		m_pedit.SetSel(0, -1);
	}		
}

void CLR0ForWinDlg::OnPdel() 
{
	int iPos;
	if ((iPos = m_plist.GetCurSel()) != LB_ERR) 
	m_plist.DeleteString(iPos);
	m_pedit.SetFocus();
	m_pedit.SetSel(0, -1);		
}

void CLR0ForWinDlg::OnSave() 
{
	char szFilters[]=
      "�ķ��ļ� (*.txt)|*.txt|All Files (*.*)|*.*||";

	CFileDialog fdlg (FALSE, "txt", "*.txt",
       OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilters, this);
	if(fdlg.DoModal()==IDOK)
	{
		CString pathName = fdlg.GetPathName();
		CStdioFile OutFile;
		OutFile.Open(pathName,CFile::modeCreate | CFile::modeWrite);
		CString t;
		OutFile.WriteString("[Terminator]\n");
		
		for(int i = 0; i < m_vtlist.GetCount(); i++)
		{
			m_vtlist.GetText(i,t);
			t += "\n";
			OutFile.WriteString(t);
			
		}
		OutFile.WriteString("\n[NonTerminator]\n");
		for(i = 0; i < m_vnlist.GetCount(); i++)
		{
			m_vnlist.GetText(i,t);
			t += "\n";
			OutFile.WriteString(t);
		}
		OutFile.WriteString("\n[Starter]\n");
		m_startedit.GetWindowText(t);
		t += "\n\n[Precept]\n";
		OutFile.WriteString(t);
		for(i = 0; i < m_plist.GetCount(); i++)
		{
			m_plist.GetText(i,t);
			t += "\n";
			OutFile.WriteString(t);
		}
		OutFile.Close();
	}		
}

void CLR0ForWinDlg::OnVndel() 
{
	int iPos;
	if ((iPos = m_vnlist.GetCurSel()) != LB_ERR) 
	m_vnlist.DeleteString(iPos);
	m_vnedit.SetFocus();
	m_vnedit.SetSel(0, -1);	
}

void CLR0ForWinDlg::OnVtadd() 
{
	CString string;
	m_vtedit.GetWindowText(string);
	if(string.GetLength()!=1)
		MessageBox("��������ս���������飡","����", MB_OK | MB_ICONSTOP);
	else
	{
		if((m_vtlist.FindStringExact(-1, string) == LB_ERR) && (string!=""))
			m_vtlist.AddString(string);
	}
	m_vtedit.SetFocus();
	m_vtedit.SetSel(0, -1);	
}

void CLR0ForWinDlg::OnVtdel() 
{
	int iPos;
	if ((iPos = m_vtlist.GetCurSel()) != LB_ERR) 
	m_vtlist.DeleteString(iPos);
	m_vtedit.SetFocus();
	m_vtedit.SetSel(0, -1);	
}
