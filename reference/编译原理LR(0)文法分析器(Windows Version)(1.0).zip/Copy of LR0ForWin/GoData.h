// GoData.h: interface for the GoData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GODATA_H__22BA72EA_F4C6_48B1_84C1_812EB1EC5059__INCLUDED_)
#define AFX_GODATA_H__22BA72EA_F4C6_48B1_84C1_812EB1EC5059__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class GoData  
{
public:
	GoData();
	~GoData();
	int iFrom;
	char cChar;
	int iTo;
};

#endif // !defined(AFX_GODATA_H__22BA72EA_F4C6_48B1_84C1_812EB1EC5059__INCLUDED_)
