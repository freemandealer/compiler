#include "stdafx.h"
#include "Precept.h"

Precept::Precept(void)
{
	strLeft = "";
	strRight = "";
}

Precept::~Precept(void)
{
}

Precept::Precept(string left, string right)
{
	strLeft = left;
	strRight = right;
}

string Precept::GetLeft()
{
	return strLeft;
}

string Precept::GetRight()
{
	return strRight;
}

void Precept::Clear(void)
{
	strLeft = "";
	strRight = "";
}
