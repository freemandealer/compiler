#include "stdafx.h"
#include "GoData.h"

GoData::GoData()
{
	iFrom = -1;
	cChar = '\0';
	iTo = -1;
}

GoData::~GoData()
{

}
