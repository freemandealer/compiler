// LR0ForWinDlg.h : header file
//

#if !defined(AFX_LR0FORWINDLG_H__69496360_D0C7_4707_86C3_B243D64199C5__INCLUDED_)
#define AFX_LR0FORWINDLG_H__69496360_D0C7_4707_86C3_B243D64199C5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CLR0ForWinDlg dialog

class CLR0ForWinDlg : public CDialog
{
// Construction
public:
	CLR0ForWinDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CLR0ForWinDlg)
	enum { IDD = IDD_LR0FORWIN_DIALOG };
	CListBox	m_vtlist;
	CEdit	m_vtedit;
	CListBox	m_vnlist;
	CEdit	m_vnedit;
	CEdit	m_startedit;
	CListBox	m_plist;
	CEdit	m_pedit;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLR0ForWinDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CLR0ForWinDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnVnadd();
	afx_msg void OnClear();
	afx_msg void OnGtable();
	afx_msg void OnImport();
	afx_msg void OnPadd();
	afx_msg void OnPdel();
	afx_msg void OnSave();
	afx_msg void OnVndel();
	afx_msg void OnVtadd();
	afx_msg void OnVtdel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LR0FORWINDLG_H__69496360_D0C7_4707_86C3_B243D64199C5__INCLUDED_)
