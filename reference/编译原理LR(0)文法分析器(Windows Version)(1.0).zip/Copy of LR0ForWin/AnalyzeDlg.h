//{{AFX_INCLUDES()
#include "explorer1.h"
//}}AFX_INCLUDES
#if !defined(AFX_ANALYZEDLG_H__276AC162_D42E_4648_B57B_84D4066C6FA8__INCLUDED_)
#define AFX_ANALYZEDLG_H__276AC162_D42E_4648_B57B_84D4066C6FA8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AnalyzeDlg.h : header file
//
#include "ResizingDialog.h"
#include "Grammar.h"
#include "TreeDlg.h"
#include <vector>
#include <stack>
using namespace std;
/////////////////////////////////////////////////////////////////////////////
// CAnalyzeDlg dialog

class CAnalyzeDlg : public CResizingDialog
{
// Construction
public:

	CString GetStepInfo(int iStep, const vector <int> & Status, const vector <char> & Symbol, CString sInput, Pair Action, int Goto);
	CAnalyzeDlg(CWnd* pParent = NULL);   // standard constructor
	~CAnalyzeDlg();
	void SetGrammar(const Grammar & g);
// Dialog Data
	//{{AFX_DATA(CAnalyzeDlg)
	enum { IDD = IDD_DIALOG2 };
	CEdit	m_edit1;
	CExplorer1	m_web;
	CString	m_input;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnalyzeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	Grammar m_g;
	CTreeDlg * m_pTree;
	string m_strTempFilename;
	// Generated message map functions
	//{{AFX_MSG(CAnalyzeDlg)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnButton1();
	virtual BOOL OnInitDialog();
	afx_msg void OnButton2();
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void MakeTree();
	stack <int> TreeStack;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANALYZEDLG_H__276AC162_D42E_4648_B57B_84D4066C6FA8__INCLUDED_)
