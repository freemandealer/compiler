// TableDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LR0ForWin.h"
#include "TableDlg.h"
#include "ResizingDialog.h"
#include "AnalyzeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTableDlg dialog


CTableDlg::CTableDlg(CWnd* pParent /*=NULL*/)
	: CResizingDialog(CTableDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTableDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_strTempFilename = "";
}


void CTableDlg::DoDataExchange(CDataExchange* pDX)
{
	CResizingDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTableDlg)
	DDX_Control(pDX, IDC_EXPLORER1, m_web);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTableDlg, CResizingDialog)
	//{{AFX_MSG_MAP(CTableDlg)
	ON_BN_CLICKED(IDC_EXPORT, OnExport)
	ON_BN_CLICKED(IDC_ANALYZE, OnAnalyze)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTableDlg message handlers

void CTableDlg::OnOK() 
{
	// TODO: Add extra validation here
	if (m_strTempFilename != "")
		DeleteFile(m_strTempFilename.c_str());
	CResizingDialog::OnOK();
}

void CTableDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	if (m_strTempFilename != "")
		DeleteFile(m_strTempFilename.c_str());
	CResizingDialog::OnCancel();
}

BOOL CTableDlg::OnInitDialog() 
{
	CResizingDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	if (!g.IsLegalLR0Grammar())
		(GetDlgItem(IDC_ANALYZE))->EnableWindow(FALSE);
	m_strTempFilename = g.OutputHTML();
	m_web.Navigate(m_strTempFilename.c_str(), NULL, NULL, NULL, NULL);
	SetIcon(LoadIcon(::AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME)),FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTableDlg::OnExport() 
{
	// TODO: Add your control notification handler code here
	char szFilters[]=
      "�ķ��ļ� (*.txt)|*.txt|All Files (*.*)|*.*||";

	CFileDialog fdlg (FALSE, "txt", "*.txt",
       OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilters, this);
	if(fdlg.DoModal()==IDOK)
	{
		CString pathName = fdlg.GetPathName();
		g.Output(pathName.GetBuffer(0));
	}	
}

void CTableDlg::OnAnalyze() 
{
	// TODO: Add your control notification handler code here
	CAnalyzeDlg dlg;
	dlg.SetGrammar(g);
	dlg.SetControlInfo(IDC_EDIT1,RESIZE_HOR );
	dlg.SetControlInfo(IDC_BUTTON1, ANCHORE_RIGHT | ANCHORE_TOP);
	dlg.SetControlInfo(IDCANCEL , ANCHORE_BOTTOM | ANCHORE_RIGHT);
	dlg.SetControlInfo(IDC_EXPLORER1, RESIZE_BOTH);
	dlg.SetControlInfo(IDC_BUTTON2, ANCHORE_RIGHT | ANCHORE_BOTTOM);
	dlg.DoModal();		
}
