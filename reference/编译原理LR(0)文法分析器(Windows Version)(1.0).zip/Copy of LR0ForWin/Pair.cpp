#include "stdafx.h"
#include "Pair.h"

Pair::Pair()
{
	one = 0;
	two = 0;
}

Pair::Pair(int i, int j)
{
	one = i;
	two = j;
}

bool Pair::operator == (const Pair & pair) const
{
	return ((one == pair.one) && (two == pair.two));
}
