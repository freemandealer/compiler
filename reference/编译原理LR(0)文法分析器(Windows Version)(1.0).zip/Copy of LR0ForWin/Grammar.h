#if !defined(AFX_GRAMMAR_H__00D40BED_BB43_462E_ADF0_8354C265C84E__INCLUDED_)
#define AFX_GRAMMAR_H__00D40BED_BB43_462E_ADF0_8354C265C84E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Set.h"
#include "Precept.h"
#include "ProjectSet.h"
#include "GoData.h"
#include "Pair.h"
#include <vector>
using namespace std;

class Grammar  
{
public:
	int GetGoTo(int iStatus, char cChar);
	Pair GetAction(int iStatus, char cNext);
	Precept GetPrecept(int n);
	Grammar(void);
	~Grammar(void);
	Grammar(const Grammar & g);
	const Grammar operator = (const Grammar & g);
	void SetVt(string vt);
	void SetVn(string vn);
	void SetStart(char start);
	void AddPrecept(string p);
	bool IsGrammarLegal();
	bool IsInVn(char cChar);
	bool IsInVt(char cChar);
	char GetStart();
	void GenerateLR0Table();
	string OutputHTML();
	void Output(char * pFilename);
	bool IsLegalLR0Grammar();
private:
	Set Vt;
	Set Vn;
	char cStart;
	vector <Precept> P;
	vector <ProjectSet> C;
	Pair * pTable;
	vector <GoData> GoSet;

	int nVt;
	int nVn;
	int nP;
	int nC;

	void EnlargeGrammar();
	void MakeProjects();
	void GenerateTable();
	
	Precept GetProject(const Pair & pair1);
	ProjectSet GetClosure(const Pair & pair1);
	ProjectSet MakeGoSet(int iI, char cChar);
	int GetGoSet(int iI, char cChar);
	bool AddProject(const ProjectSet & ps);
	bool FillTable(int nLine, char cChar, Pair p);
	int iLegal;
	
	void CopyGrammar(const Grammar & g);

protected:
	int GetProjectNum(const Pair & p);
};

#endif // !defined(AFX_GRAMMAR_H__00D40BED_BB43_462E_ADF0_8354C265C84E__INCLUDED_)
