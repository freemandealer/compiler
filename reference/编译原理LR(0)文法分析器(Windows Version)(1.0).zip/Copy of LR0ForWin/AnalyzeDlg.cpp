// AnalyzeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LR0ForWin.h"
#include "AnalyzeDlg.h"
#include <vector>
#include <cassert>
#include "Pair.h"
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAnalyzeDlg dialog


CAnalyzeDlg::CAnalyzeDlg(CWnd* pParent /*=NULL*/)
	: CResizingDialog(CAnalyzeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAnalyzeDlg)
	m_input = _T("");
	//}}AFX_DATA_INIT
	m_strTempFilename = "";
	m_pTree = new CTreeDlg;
	m_pTree->Create(IDD_DIALOG3, this);
	m_pTree->SetControlInfo(IDC_TREE1, RESIZE_BOTH);
	m_pTree->SetControlInfo(IDOK, ANCHORE_BOTTOM | ANCHORE_RIGHT);
}

CAnalyzeDlg::~CAnalyzeDlg()
{
	m_pTree->DestroyWindow();
	delete m_pTree;
}

void CAnalyzeDlg::DoDataExchange(CDataExchange* pDX)
{
	CResizingDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAnalyzeDlg)
	DDX_Control(pDX, IDC_EDIT1, m_edit1);
	DDX_Control(pDX, IDC_EXPLORER1, m_web);
	DDX_Text(pDX, IDC_EDIT1, m_input);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAnalyzeDlg, CResizingDialog)
	//{{AFX_MSG_MAP(CAnalyzeDlg)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_WM_ACTIVATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAnalyzeDlg message handlers

void CAnalyzeDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	//CDialog::OnOK();
}

void CAnalyzeDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	if (m_strTempFilename != "")
		DeleteFile(m_strTempFilename.c_str());
	CResizingDialog::OnCancel();
}

void CAnalyzeDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pTree->m_tree.DeleteAllItems();

	for(int i = 0; i < m_input.GetLength(); i ++)
	{
		if (!m_g.IsInVt(m_input.GetAt(i)))
		{
			MessageBox("����ľ��Ӳ�ȫ�����ս�����", "����", MB_OK | MB_ICONSTOP);
			return;
		}
	}
	assert(TreeStack.empty());
	m_input += "#";
	char szTempPath[MAX_PATH]; 
	char szTempName[MAX_PATH]; 
	if (m_strTempFilename != "")
		::DeleteFile(m_strTempFilename.c_str());
	::GetTempPath(100,szTempPath);
	::GetTempFileName(szTempPath,"LR0",0,szTempName);
	m_strTempFilename = szTempName;
	CStdioFile out;
	out.Open(szTempName, CFile::modeCreate | CFile::modeWrite);
	out.WriteString("<html>\n");
	out.WriteString("<head>\n");
	out.WriteString("<title>Untitled Document</title>\n");
	out.WriteString("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\">\n");
	out.WriteString("</head>\n");
	out.WriteString("<body bgcolor=\"#FFFFFF\" text=\"#000000\">\n");
	out.WriteString("<table border=\"1\"  cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse\" bordercolor=\"#111111\">\n");
	out.WriteString("<tr>\n<td nowrap>&nbsp;����&nbsp;</td>\n<td nowrap>&nbsp;״̬ջ</td>\n<td nowrap>&nbsp;����ջ&nbsp;</td>\n<td nowrap>&nbsp;���봮&nbsp;</td>\n<td nowrap>&nbsp;ACTION&nbsp;</td>\n<td nowrap >&nbsp;GOTO&nbsp;</td>\n </tr>\n");
	vector <int> Status;
	vector <char> Symbol;
	int iStep = 1;
	int iPos = 0;
	Status.push_back(0);
	Symbol.push_back('#');
	Pair ToDo;
	bool bErrorFlag = false;
	bool bGoOn = true;
	while ((bGoOn) && (!bErrorFlag))
	{
		assert(iPos < m_input.GetLength());
		assert(Status.size() == Symbol.size());
		ToDo = m_g.GetAction(Status.back(), m_input.GetAt(iPos));
		int i, j;
		switch (ToDo.one)
		{
		case 'S':
			out.WriteString(GetStepInfo(iStep, Status, Symbol, m_input.Right(m_input.GetLength() - iPos), ToDo, -1));
			Symbol.push_back(m_input.GetAt(iPos));
			Status.push_back(ToDo.two);
			iPos++;
			break;
		case 'R':
			j = m_g.GetGoTo(Status[Status.size()-m_g.GetPrecept(ToDo.two).GetRight().length()-1], m_g.GetPrecept(ToDo.two).GetLeft()[0]);
			assert(j != -1);
			out.WriteString(GetStepInfo(iStep, Status, Symbol, m_input.Right(m_input.GetLength() - iPos), ToDo, j));
			for(i = 0; i < m_g.GetPrecept(ToDo.two).GetRight().length(); i++)
			{
				Status.pop_back();
				Symbol.pop_back();
			}
			Symbol.push_back(m_g.GetPrecept(ToDo.two).GetLeft()[0]);
			Status.push_back(j);
			TreeStack.push(ToDo.two);
			break;
		case 'a':
			if (m_input.GetAt(iPos) == '#')
			{
				out.WriteString(GetStepInfo(iStep, Status, Symbol, m_input.Right(m_input.GetLength() - iPos), ToDo, -1));
				bGoOn = false;
			}
			else
				bErrorFlag = true;
			break;
		case 0:
			bErrorFlag = true;
			break;
		default:
			assert(false);
		}
		iStep++;
	}
	out.WriteString("</table>");
	if (bErrorFlag)
	{
		out.WriteString("<p><font color=\"#FF3300\">����ʧ�ܣ�������ַ����ǲ�����Ԥ���ķ��ģ�</font></p>\n");
		//m_pTree->m_tree.DeleteAllItems();
		while(!TreeStack.empty())
			TreeStack.pop();
	}
	else
	{
		out.WriteString("<p><font color=\"#009900\">������ɣ�������ַ�����Ԥ���ķ��ľ���</font></p>\n");
		//HTREEITEM h = m_pTree->m_tree.GetRootItem();
		//ExpandTree(h);
		MakeTree();

	}

	out.WriteString("</body>\n</html>");
	out.Close();
	m_web.Navigate(szTempName,NULL,NULL,NULL,NULL);
	m_edit1.SetFocus();
	m_edit1.SetSel(0, -1);

}

BOOL CAnalyzeDlg::OnInitDialog() 
{
	CResizingDialog::OnInitDialog();
	
	SetIcon(LoadIcon(::AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME)),FALSE);
	// TODO: Add extra initialization here
	m_web.Navigate("about:blank",NULL,NULL,NULL,NULL);	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAnalyzeDlg::SetGrammar(const Grammar & g)
{
	m_g = g;
}

CString CAnalyzeDlg::GetStepInfo(int iStep, const vector<int> & Status, const vector<char> & Symbol, CString sInput, Pair Action, int Goto)
{
	CString rtn;
	rtn.Format("<tr><td nowrap>&nbsp;&nbsp;%d&nbsp;&nbsp;</td>\n",iStep);
	CString t2 = "";
	CString t;
	int nCount = 0;
	for (int i = 0; i < Status.size(); i++)
	{
		if (nCount % 2)
			t.Format("%d", Status[i]);
		else
			t.Format("<u>%d</U>", Status[i]);
		t2 += t;
		nCount++;
	}
	rtn = rtn + "<td nowrap>&nbsp;&nbsp;" +  t2 + "&nbsp;&nbsp;</td>\n<td nowrap>&nbsp;&nbsp;";
	t2 = "";
	for(i = 0; i < Symbol.size(); i++)
	{
		t.Format("%c", Symbol[i]);
		t2 += t;
	}

	rtn = rtn + t2 + "&nbsp;&nbsp;</td>\n";
	rtn = rtn + "<td nowrap>&nbsp;&nbsp;" + sInput + "&nbsp;&nbsp;</td>\n";
	if (Action.one != 'a')
		t2.Format("%c<font size=\"1\">%d</font>", Action.one, Action.two);
	else
		t2 = "acc";
	rtn = rtn + "<td nowrap>&nbsp;&nbsp;" + t2 + "&nbsp;&nbsp;</td>\n";
	if (Goto == -1)
		rtn += "<td nowrap>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
	else
	{
		t2.Format("<td nowrap>&nbsp;&nbsp;%d&nbsp;&nbsp;&nbsp;</td>\n", Goto);
		rtn += t2;
	}
	rtn += "</tr>\n";
	return rtn;
}

void CAnalyzeDlg::MakeTree()
{
	HTREEITEM hRoot = m_pTree->m_tree.InsertItem(CString(m_g.GetStart()));
	CString temp;
	HTREEITEM hItem = hRoot;
	stack <HTREEITEM> s;
	s.push(hItem);
	while (!TreeStack.empty())
	{
		temp = m_g.GetPrecept(TreeStack.top()).GetRight().c_str();
		hItem = s.top();
		s.pop();
		TreeStack.pop();
		for(int i = 0; i < temp.GetLength(); i++)
		{
			HTREEITEM hItem2;
			hItem2 = m_pTree->m_tree.InsertItem(CString(temp.GetAt(i)), hItem);
			if(m_g.IsInVn(temp.GetAt(i)))
			{
				s.push(hItem2);
			}
		}
		m_pTree->m_tree.Expand(hItem, TVE_EXPAND);
	}
	assert(s.empty());
	assert(TreeStack.empty());
}

void CAnalyzeDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	CRect rect;
	GetWindowRect(rect);
	//int iWidth = GetSystemMetrics(SM_CXSCREEN) - rect.right;
	//if (iWidth < 200)
	//	iWidth = 200;
	if(!m_pTree->IsWindowVisible())
		m_pTree->SetWindowPos(&wndTopMost,GetSystemMetrics(SM_CXSCREEN) - 280, 0, 250, 350, SWP_SHOWWINDOW);
	m_pTree->SetFocus();
}

void CAnalyzeDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CResizingDialog::OnActivate(nState, pWndOther, bMinimized);
	if (nState == WA_INACTIVE)
		m_pTree->SetWindowPos(&wndNoTopMost,0,0,0,0, SWP_NOMOVE | SWP_NOSIZE |SWP_NOACTIVATE );
	else
		m_pTree->SetWindowPos(&wndTopMost,0,0,0,0,SWP_NOSIZE | SWP_NOMOVE |SWP_NOACTIVATE );	
}
