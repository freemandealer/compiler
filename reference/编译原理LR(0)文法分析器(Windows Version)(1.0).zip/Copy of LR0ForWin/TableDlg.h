//{{AFX_INCLUDES()
#include "explorer1.h"
//}}AFX_INCLUDES
#if !defined(AFX_TABLEDLG_H__294F0723_AB75_4C82_88D8_1901B3AFBC18__INCLUDED_)
#define AFX_TABLEDLG_H__294F0723_AB75_4C82_88D8_1901B3AFBC18__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TableDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTableDlg dialog
#include <string>
#include "Grammar.h"
#include "ResizingDialog.h"
using namespace std;

class CTableDlg : public CResizingDialog
{
// Construction
public:
	CTableDlg(CWnd* pParent = NULL);   // standard constructor
	Grammar g;
	string m_strTempFilename;
// Dialog Data
	//{{AFX_DATA(CTableDlg)
	enum { IDD = IDD_DIALOG1 };
	CExplorer1	m_web;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTableDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTableDlg)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnExport();
	afx_msg void OnAnalyze();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABLEDLG_H__294F0723_AB75_4C82_88D8_1901B3AFBC18__INCLUDED_)
